#!/usr/bin/env bash
source /opt/ros/humble/setup.bash
[ -f /home/duzhong/dzrobot/dzros.env ] && source /home/duzhong/dzrobot/dzros.env
PID=$(cat /home/duzhong/robot_logs/pids/7_path.pid 2>/dev/null)
echo "7_path pid=[$PID]"
if [ -n "$PID" ] && kill -0 "$PID" 2>/dev/null; then echo "ALIVE"; else echo "DEAD"; fi
echo "--- install/dzbrain ---"
find /home/duzhong/dzrobot/install/dzbrain -maxdepth 3 -type f -o -type l 2>/dev/null | head -12
echo "--- ps all python/ros nodes ---"
ps -eo pid,comm,args --sort=pid | grep -Ei 'dzbrain|7_path|main|ros2' | grep -v grep | head -15
