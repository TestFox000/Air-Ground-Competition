#!/usr/bin/env bash
source /opt/ros/humble/setup.bash
[ -f /home/duzhong/dzrobot/dzros.env ] && source /home/duzhong/dzrobot/dzros.env
echo "DOMAIN=$ROS_DOMAIN_ID"
echo "--- procs ---"
ps -eo pid,comm,args | grep -Ei 'dzbrain|dzrobot|main\.py|det_node|judgment' | grep -v grep | head -10
echo "--- offset echo once ---"
timeout 6 ros2 topic echo /offset_center --once 2>&1 | head -20
echo "--- offset field test ---"
timeout 6 ros2 topic echo /offset_center --once --field data 2>&1 | head -10
echo "--- offset stream 3s ---"
timeout 3 ros2 topic echo /offset_center 2>&1 | head -40
echo "--- hp echo ---"
timeout 6 ros2 topic echo /HpAndHitmsg --once 2>&1 | head -30
echo "--- hp hz 5s ---"
timeout 6 ros2 topic hz /HpAndHitmsg 2>&1 | tail -5
echo "--- offset hz 5s ---"
timeout 6 ros2 topic hz /offset_center 2>&1 | tail -5
echo "--- waypoint info ---"
timeout 10 ros2 topic info /nav/waypoint 2>&1
echo "--- image hz ---"
timeout 8 ros2 topic hz /image_raw 2>&1 | tail -4
echo "--- log ---"
grep -E '安全OK|开火策略' /home/duzhong/robot_logs/7_path.log 2>&1 | tail -3
