#!/usr/bin/env bash
set -u
source /opt/ros/humble/setup.bash 2>/dev/null || echo "ROS_SETUP_FAIL"
if [ -f /home/duzhong/dzrobot/dzros.env ]; then source /home/duzhong/dzrobot/dzros.env; echo "DZROS_SOURCED"; else echo "DZROS_MISSING"; fi
DOM="$ROS_DOMAIN_ID"
[ -n "$DOM" ] || DOM=unset
echo "DOMAIN=[$DOM]"
echo "--- procs ---"
pgrep -af 'dzbrain|ros2 launch|main.py|det_node' | head -10
echo "--- nodes ---"
timeout 10 ros2 node list 2>&1 | head -20
echo "--- offset hz ---"
timeout 8 ros2 topic hz /offset_center 2>&1 | tail -6
echo "--- offset echo ---"
timeout 6 ros2 topic echo /offset_center --once 2>&1 | head -20
echo "--- hp hz ---"
timeout 8 ros2 topic hz /HpAndHitmsg 2>&1 | tail -6
echo "--- hp echo ---"
timeout 6 ros2 topic echo /HpAndHitmsg --once 2>&1 | head -20
echo "--- image hz (expect fail) ---"
timeout 8 ros2 topic hz /image_raw 2>&1 | tail -6
echo "--- waypoint info ---"
timeout 10 ros2 topic info /nav/waypoint 2>&1
echo "--- aim/status echo ---"
timeout 6 ros2 topic echo /aim/status --once 2>&1 | head -8
echo "--- log last ---"
grep -E '安全OK|开火策略' /home/duzhong/robot_logs/7_path.log 2>&1 | tail -5
