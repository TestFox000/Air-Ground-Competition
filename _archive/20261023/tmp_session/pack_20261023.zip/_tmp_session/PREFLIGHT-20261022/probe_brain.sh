#!/usr/bin/env bash
source /opt/ros/humble/setup.bash
[ -f /home/duzhong/dzrobot/dzros.env ] && source /home/duzhong/dzrobot/dzros.env
echo "--- pids dir ---"
ls -l /home/duzhong/robot_logs/pids 2>&1 | head -12
echo "--- pids content ---"
for f in /home/duzhong/robot_logs/pids/*; do echo "== $f"; head -3 "$f" 2>/dev/null; done
echo "--- main.py / brain procs ---"
pgrep -af 'main.py' | head -5
pgrep -af 'brain' | head -5
echo "--- install dirs ---"
ls /home/duzhong/dzrobot/install 2>&1
echo "--- 7_path fire policy ---"
grep -c '开火策略' /home/duzhong/robot_logs/7_path.log
grep -n '开火策略' /home/duzhong/robot_logs/7_path.log | tail -2
