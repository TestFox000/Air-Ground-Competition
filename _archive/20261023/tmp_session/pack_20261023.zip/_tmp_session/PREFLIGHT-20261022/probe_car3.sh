#!/usr/bin/env bash
source /opt/ros/humble/setup.bash
[ -f /home/duzhong/dzrobot/dzros.env ] && source /home/duzhong/dzrobot/dzros.env
echo "--- brain proc ---"
ps -eo pid,args | grep -i dzbrain | grep -v grep | head -5
echo "RC=$?"
echo "--- node list ---"
timeout 10 ros2 node list 2>&1
echo "--- offset field stream ---"
timeout 2 ros2 topic echo /offset_center --field data 2>&1 | head -6
echo "--- log files ---"
ls -lt /home/duzhong/robot_logs/ 2>&1 | head -12
echo "--- fire policy search ---"
grep -n '开火策略' /home/duzhong/robot_logs/*.log 2>/dev/null | tail -5
echo "--- safety last ---"
grep -n '安全OK' /home/duzhong/robot_logs/7_path.log 2>/dev/null | tail -3
