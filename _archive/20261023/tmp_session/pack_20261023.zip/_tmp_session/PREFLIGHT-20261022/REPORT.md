# PREFLIGHT-20261022 · 打靶预检板（开跑前 60 秒自检）

> 执行者：implementer · 2026-10-22 20:3x · 车端 `duzhong@192.168.0.4` · **只读，未发任何 cmd 话题**

## 0. 交付

- 脚本：`_tmp_session/PREFLIGHT-20261022/preflight.sh`（7505 B，SHA256 `b99988cc1dd0b9cb064dd275f1724814e8789ddc60c8d32010e049167b9e42bf`，LF/UTF-8）
- 用法（本机）：`ssh duzhong@192.168.0.4 'bash -s' < preflight.sh`；退出码 = 失败项数。
- 脚本自带：`source /opt/ros/humble/setup.bash` → 若存在再 `source /home/duzhong/dzrobot/dzros.env`；全 bash + `timeout`，无交互。
- 本轮实测耗时 **31 s**（≤60 s 目标），退出码 **2**。

## 1. 检查项（全部只读）

| # | 检查 | 判据 | 本轮结果 |
|---|---|---|---|
| 1 | 7 个话题在线 | `/image_raw /offset_center /aim/status /HpAndHitmsg /imu_data /odom/localization /nav/waypoint` 全在 `ros2 topic list` | **PASS 7/7** |
| 2 | 相机 | `/dev/video0` 存在 + `/image_raw` 实测 ≥25 Hz（`ros2 topic hz`，8 s 超时） | **FAIL**：device missing、0 Hz（相机物理掉线，符合预期） |
| 3 | det 输出 | `/offset_center` ≥20 Hz；连取 10 条；`cls>0` 时 `bbox w/h > 0` | **PASS**：30.304 Hz、10/10 帧、样本 cls=0 |
| 4 | 裁判 | `/HpAndHitmsg` ≥0.9 Hz；原始 data 原样打印 | **PASS**：11.056 Hz，data=[10,10,16,1,9] |
| 5 | 脑 | dzbrain 进程/节点在线；`/nav/waypoint` 订阅数 ≥1；打印 banner 关键行 | **FAIL**：dzbrain 未起（7_path pid 24060 已死），订阅数=1；banner 行已打印 |
| 6 | 命令通道 | 只打印“连发 5 次 + 校验”建议，**不真的发** | **PASS**（只打印建议） |

## 2. 车上真实输出（原文，2026-10-22 20:34:58）

```text
==================================================================
 打靶预检板 preflight  2026-10-22 20:34:58  host=duzhong
==================================================================
[INFO] ROS_DOMAIN_ID=118  ROS_LOCALHOST_ONLY=0
[PASS] 1/6  话题在线：7/7 全在（/image_raw /offset_center /aim/status /HpAndHitmsg /imu_data /odom/localization /nav/waypoint）
[FAIL] 2/6  相机：/dev/video0=missing，/image_raw 0 Hz（要求 ≥25；掉线/未出帧）
[PASS] 3/6  det：/offset_center 30.304 Hz，10/10 帧解析，cls>0 帧 bbox 有效（样本 [cls=0 w=0 h=0]）
[PASS] 4/6  裁判：/HpAndHitmsg 11.056 Hz（≥0.9），原始 data=[ 10 10 16 1 9 ]（队名/弹药/命中，原样不解析）
[FAIL] 5/6  脑：dzbrain 进程=missing 节点=missing path_pid=dead(24060)，/nav/waypoint 订阅=1（要求进程/节点在线）
[INFO] banner 安全OK（7_path.log 最后一条）：[T] N10 IDLE (0.525,0.175) yaw92.3 v0.000 st+0.0 | 段-1 s0.00/0 | 瞄TRACK 靶s1.00v+0.0 发0/中0 弹10 | 安全OK | 无人机offline
[INFO] banner 开火策略（7_path.log）：  开火策略 : moving_lead（提前量 0.27s）
[PASS] 6/6  命令通道自检（只读）：建议发车前对 /nav/waypoint 连发 5 次 + 回读校验（本脚本未 publish 任何话题）
[INFO] 做法：发车脚本里每 0.2s 发 1 次（共 5 次），随后 ros2 topic echo /nav/waypoint --once 确认收到；
[INFO]       若 5 次里只到 1~2 次，先查 WiFi/网桥与 ROS_DOMAIN_ID，不要直接发车。
------------------------------------------------------------------
ELAPSED: 31s
SUMMARY: PASS=4/6  FAIL=2  （退出码=2）
只读声明：本脚本只执行 ros2 topic list/type/hz/echo/info 与 node list；未 publish 任何话题。
LOCAL_SSH_EXIT=2
```

## 3. 结果解读（对今晚排障的意义）

1. **相机 FAIL 已抓到（预期）**：`/dev/video0` 不存在、`/image_raw` 0 Hz；若发车前跑本脚本，相机掉线会在 8 s 内暴露，不必等发车后才发现。
2. **额外抓到脑未起（真实故障，非脚本误报）**：`ps` 无 dzbrain、`ros2 node list` 无 `/dzbrain`、`~/robot_logs/pids/7_path.pid=24060` 已死 ⇒ 决策层当前没在线；这与“5 趟里 4 趟被可预检故障吃掉”的复盘一致，建议发车前必须先过第 5 项。
3. 其余链路健康：det 30.3 Hz、裁判 11.06 Hz、`/nav/waypoint` 已有 1 个订阅者、banner 有 `安全OK` 与 `开火策略 : moving_lead（提前量 0.27s）`。

## 4. 无副作用证明

- 脚本内 **没有任何** `ros2 topic pub` / `ros2 action send` / `ros2 service call`：

```text
40: TOPICS="$(timeout -k 2 15 ros2 topic list 2>/dev/null)"
53: CAM_OUT="$(timeout -k 2 8 ros2 topic hz /image_raw 2>&1)"
62: DET_OUT="$(timeout -k 2 8 ros2 topic hz /offset_center 2>&1)"
82: done < <(timeout -k 2 6 ros2 topic echo /offset_center --field data 2>/dev/null | head -40)
90: REF_OUT="$(timeout -k 2 8 ros2 topic hz /HpAndHitmsg 2>&1)"
92: REF_RAW="$(timeout -k 2 6 ros2 topic echo /HpAndHitmsg --once 2>/dev/null)"
103: if timeout -k 2 10 ros2 node list 2>/dev/null | grep -qx '/dzbrain'; then BRAIN_NODE="ok"; fi
109: NAV_SUBS="$(timeout -k 2 10 ros2 topic info /nav/waypoint 2>/dev/null | awk '/Subscription count:/ {print $3}')"
```

- 只有 `list/hz/echo/node list/topic info`（echo 是订阅，不发布）；`topic info` 发车前/后均为 `Publisher count: 0 / Subscription count: 1`，未被本脚本改变。
- 未写车端仓库/config；只清理了探针临时文件 `/tmp/pf_probe.sh`、`/tmp/pf_out.txt`（均为本次测试用，已删）。

## 5. 边界与说明

1. 本轮 `/offset_center` 的 10 条全是 `cls=0`（现场无目标），所以“cls>0 且 bbox=0 要判坏”的分支无法在真实现场触发；已用合成行自测覆盖：

```text
cls=1 bbox=0/0     -> msgs=1 bad=1   （判坏 ✅）
cls=1 bbox=40/50   -> msgs=1 bad=0   （判好 ✅）
cls=0 bbox=0/0     -> msgs=1 bad=0   （无目标不判坏 ✅）
```

2. 相机物理掉线时 `/image_raw` 无帧，`ros2 topic hz` 只会空转超时（脚本按 0 Hz 判 FAIL）——这正是期望行为。
3. **环境坑（已规避）**：ROS `setup.bash` 内部会引用未定义变量，脚本**不能先 `set -u` 再 source**；本脚本在 source 之后不启用 `set -u`。
4. 本机（Windows/PowerShell）把非 ASCII 脚本直接管道给 `ssh` 会破坏编码，因此本次实机执行用 `base64 -d | bash -s` 传入**逐字节相同**的脚本（等价于 `ssh ... 'bash -s' < preflight.sh`；Lead 在 bash/cmd 下用 `<` 重定向即可）。
5. 退出码语义：失败项数（本轮 2 = 相机 + 脑）。CI/发车脚本可直接 `if ! ssh ... < preflight.sh; then 停发车; fi`。
