#!/usr/bin/env bash
echo "=== host ==="
hostname; uptime
echo "=== vnc/X procs ==="
ps -eo pid,user,comm,args | grep -Ei 'vnc|vino|xrdp|Xorg|Xwayland' | grep -v grep
echo "=== listen 5900-5910 ==="
ss -ltnp 2>/dev/null | grep -E ':(590[0-9]|5910)'
echo "=== who ==="
who
loginctl list-sessions 2>/dev/null
echo "=== X11 sockets ==="
ls -l /tmp/.X11-unix/ 2>/dev/null
echo "=== ~/.vnc ==="
ls -lt ~/.vnc/ 2>/dev/null | head -10
echo "=== x11vnc logs tail ==="
for f in ~/.vnc/*.log; do [ -f "$f" ] && { echo "-- $f"; tail -12 "$f"; }; done
echo "=== recent journal vnc ==="
journalctl --since '40 min ago' --no-pager 2>/dev/null | grep -iE 'vnc|vino|x11vnc|xrdp' | tail -20
