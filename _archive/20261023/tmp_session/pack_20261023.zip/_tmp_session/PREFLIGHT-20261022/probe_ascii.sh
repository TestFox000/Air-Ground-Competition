echo START
source /opt/ros/humble/setup.bash
echo ROS_OK
hostname
