#!/usr/bin/env bash
# 预检脚本第 3 项解析逻辑的离线自测（不连 ROS，只喂合成行）
parse() {
  DET_MSGS=0; DET_BAD=0
  while IFS= read -r line; do
    case "$line" in
      *"array("*)
        vals="$(echo "$line" | sed -E 's/.*\[//; s/\].*//; s/,/ /g')"
        set -- $vals
        if [ $# -lt 5 ]; then DET_BAD=$((DET_BAD + 1)); continue; fi
        DET_MSGS=$((DET_MSGS + 1))
        cls="$3"; w="$4"; h="$5"
        case "$cls$w$h" in *[!0-9-]*) DET_BAD=$((DET_BAD + 1)); continue;; esac
        if [ "$cls" -gt 0 ]; then
          if [ "$w" -le 0 ] || [ "$h" -le 0 ]; then DET_BAD=$((DET_BAD + 1)); fi
        fi
        ;;
    esac
  done
  echo "msgs=$DET_MSGS bad=$DET_BAD"
}
echo -n "cls=1 bbox=0/0 -> "; printf "array('i', [1, 2, 1, 0, 0, 0, 0, 0])\n" | parse
echo -n "cls=1 bbox=40/50 -> "; printf "array('i', [1, 2, 1, 40, 50, 0, 0, 0])\n" | parse
echo -n "cls=0 bbox=0/0 -> "; printf "array('i', [0, 0, 0, 0, 0, 0, 0, 0])\n" | parse
