#!/usr/bin/env bash
# =============================================================================
#  打靶预检板 · 开跑前 60 秒自检（只读，不发任何 cmd 话题）
#  用法（本机执行）：ssh duzhong@192.168.0.4 'bash -s' < preflight.sh
#  退出码 = 失败项数（0 = 全过）
#  设计约束：全 bash + timeout；不依赖交互；不改配置；不 publish 任何话题。
# =============================================================================
TOTAL=6
FAILS=0
T0=$SECONDS

pass() { echo "[PASS] $1/$TOTAL  $2"; }
fail() { echo "[FAIL] $1/$TOTAL  $2"; FAILS=$((FAILS + 1)); }
info() { echo "[INFO] $*"; }

echo "=================================================================="
echo " 打靶预检板 preflight  $(date '+%F %T')  host=$(hostname)"
echo "=================================================================="

# ---- 环境（车端唯一真相源：ROS + dzros.env）--------------------------------
if [ -f /opt/ros/humble/setup.bash ]; then
  # 注意：必须在 set -u 之前 source（ROS setup 会引用未定义变量）
  source /opt/ros/humble/setup.bash
else
  echo "[FATAL] /opt/ros/humble/setup.bash 不存在：ROS 环境不可用"
  exit 255
fi
if [ -f /home/duzhong/dzrobot/dzros.env ]; then
  source /home/duzhong/dzrobot/dzros.env
else
  info "WARN: /home/duzhong/dzrobot/dzros.env 不存在（ROS_DOMAIN_ID 使用默认 0）"
fi
info "ROS_DOMAIN_ID=$ROS_DOMAIN_ID  ROS_LOCALHOST_ONLY=$ROS_LOCALHOST_ONLY"
if [ "$ROS_DOMAIN_ID" != "118" ]; then
  info "WARN: 期望 ROS_DOMAIN_ID=118，实际=$ROS_DOMAIN_ID（跨机看不到节点）"
fi

# ---- 1. 节点/话题在线 -------------------------------------------------------
EXPECTED="/image_raw /offset_center /aim/status /HpAndHitmsg /imu_data /odom/localization /nav/waypoint"
TOPICS="$(timeout -k 2 15 ros2 topic list 2>/dev/null)"
MISSING=""
for t in $EXPECTED; do
  echo "$TOPICS" | grep -qx "$t" || MISSING="$MISSING $t"
done
if [ -z "$MISSING" ]; then
  pass 1 "话题在线：7/7 全在（/image_raw /offset_center /aim/status /HpAndHitmsg /imu_data /odom/localization /nav/waypoint）"
else
  fail 1 "话题缺失：$MISSING"
fi

# ---- 2. 相机：设备 + 实测帧率 ≥25Hz ----------------------------------------
DEV="missing"; [ -e /dev/video0 ] && DEV="ok"
CAM_OUT="$(timeout -k 2 8 ros2 topic hz /image_raw 2>&1)"
CAM_RATE="$(echo "$CAM_OUT" | awk '/average rate:/ {r=$3} END {if (r=="") r=0; print r}')"
if [ "$DEV" = "ok" ] && awk "BEGIN{exit !($CAM_RATE >= 25)}"; then
  pass 2 "相机：/dev/video0 存在，/image_raw $CAM_RATE Hz（≥25）"
else
  fail 2 "相机：/dev/video0=$DEV，/image_raw $CAM_RATE Hz（要求 ≥25；掉线/未出帧）"
fi

# ---- 3. det 输出：≥20Hz + 连取 10 条校验 cls/bbox ---------------------------
DET_OUT="$(timeout -k 2 8 ros2 topic hz /offset_center 2>&1)"
DET_RATE="$(echo "$DET_OUT" | awk '/average rate:/ {r=$3} END {if (r=="") r=0; print r}')"
DET_MSGS=0; DET_CLS_POS=0; DET_BAD=0; DET_SAMPLE=""
while IFS= read -r line; do
  case "$line" in
    *"array("*)
      vals="$(echo "$line" | sed -E 's/.*\[//; s/\].*//; s/,/ /g')"
      set -- $vals
      if [ $# -lt 5 ]; then DET_BAD=$((DET_BAD + 1)); continue; fi
      DET_MSGS=$((DET_MSGS + 1))
      cls="$3"; w="$4"; h="$5"
      case "$cls$w$h" in *[!0-9-]*) DET_BAD=$((DET_BAD + 1)); continue;; esac
      [ "$DET_MSGS" = "1" ] && DET_SAMPLE="[cls=$cls w=$w h=$h]"
      if [ "$cls" -gt 0 ]; then
        DET_CLS_POS=$((DET_CLS_POS + 1))
        if [ "$w" -le 0 ] || [ "$h" -le 0 ]; then DET_BAD=$((DET_BAD + 1)); fi
      fi
      [ "$DET_MSGS" -ge 10 ] && break
      ;;
  esac
done < <(timeout -k 2 6 ros2 topic echo /offset_center --field data 2>/dev/null | head -40)
if awk "BEGIN{exit !($DET_RATE >= 20)}" && [ "$DET_MSGS" -ge 10 ] && [ "$DET_BAD" -eq 0 ]; then
  pass 3 "det：/offset_center $DET_RATE Hz，10/10 帧解析，cls>0 帧 bbox 有效（样本 $DET_SAMPLE）"
else
  fail 3 "det：/offset_center $DET_RATE Hz（要求 ≥20），取到 $DET_MSGS/10 帧，异常帧=$DET_BAD，样本=$DET_SAMPLE"
fi

# ---- 4. 裁判：≥0.9Hz + 原样打印队名/弹药/命中 ------------------------------
REF_OUT="$(timeout -k 2 8 ros2 topic hz /HpAndHitmsg 2>&1)"
REF_RATE="$(echo "$REF_OUT" | awk '/average rate:/ {r=$3} END {if (r=="") r=0; print r}')"
REF_RAW="$(timeout -k 2 6 ros2 topic echo /HpAndHitmsg --once 2>/dev/null)"
REF_DATA="$(echo "$REF_RAW" | awk '/^data:/{f=1;next} f && /^- /{printf "%s ", $2} END{print ""}')"
if awk "BEGIN{exit !($REF_RATE >= 0.9)}" && [ -n "$REF_DATA" ]; then
  pass 4 "裁判：/HpAndHitmsg $REF_RATE Hz（≥0.9），原始 data=[ $REF_DATA]（队名/弹药/命中，原样不解析）"
else
  fail 4 "裁判：/HpAndHitmsg $REF_RATE Hz（要求 ≥0.9），原始 data=[ $REF_DATA]"
fi

# ---- 5. 脑：dzbrain 进程 + /nav/waypoint 订阅 + banner 关键行 --------------
BRAIN_PROC="missing"; BRAIN_NODE="missing"; BRAIN_PID="missing"
if pgrep -af 'dzbrain' >/dev/null 2>&1; then BRAIN_PROC="ok"; fi
if timeout -k 2 10 ros2 node list 2>/dev/null | grep -qx '/dzbrain'; then BRAIN_NODE="ok"; fi
P7=/home/duzhong/robot_logs/pids/7_path.pid
if [ -f "$P7" ]; then
  P7PID="$(cat "$P7" 2>/dev/null)"
  if [ -n "$P7PID" ] && kill -0 "$P7PID" 2>/dev/null; then BRAIN_PID="alive($P7PID)"; else BRAIN_PID="dead($P7PID)"; fi
fi
NAV_SUBS="$(timeout -k 2 10 ros2 topic info /nav/waypoint 2>/dev/null | awk '/Subscription count:/ {print $3}')"
[ -n "$NAV_SUBS" ] || NAV_SUBS=0
SAFETY_LINE="$(grep '安全OK' /home/duzhong/robot_logs/7_path.log 2>/dev/null | tail -1)"
FIRE_LINE="$(grep '开火策略' /home/duzhong/robot_logs/7_path.log 2>/dev/null | tail -1)"
FIRE_SRC="7_path.log"
if [ -z "$FIRE_LINE" ] && [ -f /home/duzhong/robot_logs/7_path_step.log ]; then
  FIRE_LINE="$(grep '开火策略' /home/duzhong/robot_logs/7_path_step.log 2>/dev/null | tail -1)"
  FIRE_SRC="7_path_step.log（7_path.log 无此行）"
fi
BRAIN_OK=0
if [ "$BRAIN_PROC" = "ok" ] || [ "$BRAIN_NODE" = "ok" ] || [ "$BRAIN_PID" = "alive" ]; then BRAIN_OK=1; fi
case "$BRAIN_PID" in alive*) BRAIN_OK=1;; esac
if [ "$BRAIN_OK" = "1" ]; then
  if [ "$NAV_SUBS" -ge 1 ] 2>/dev/null; then
    pass 5 "脑：dzbrain 进程=$BRAIN_PROC 节点=$BRAIN_NODE pid7path=$BRAIN_PID，/nav/waypoint 订阅=$NAV_SUBS（≥1）"
  else
    fail 5 "脑：dzbrain 在线但 /nav/waypoint 订阅=$NAV_SUBS（要求 ≥1）"
  fi
else
  fail 5 "脑：dzbrain 进程=$BRAIN_PROC 节点=$BRAIN_NODE path_pid=$BRAIN_PID，/nav/waypoint 订阅=$NAV_SUBS（要求进程/节点在线）"
fi
[ -n "$SAFETY_LINE" ] && info "banner 安全OK（7_path.log 最后一条）：$SAFETY_LINE"
[ -n "$FIRE_LINE" ] && info "banner 开火策略（$FIRE_SRC）：$FIRE_LINE"

# ---- 6. 命令通道自检（只打印建议，不真的发） -------------------------------
pass 6 "命令通道自检（只读）：建议发车前对 /nav/waypoint 连发 5 次 + 回读校验（本脚本未 publish 任何话题）"
info "做法：发车脚本里每 0.2s 发 1 次（共 5 次），随后 ros2 topic echo /nav/waypoint --once 确认收到；"
info "      若 5 次里只到 1~2 次，先查 WiFi/网桥与 ROS_DOMAIN_ID，不要直接发车。"

echo "------------------------------------------------------------------"
echo "ELAPSED: $((SECONDS - T0))s"
echo "SUMMARY: PASS=$((TOTAL - FAILS))/$TOTAL  FAIL=$FAILS  （退出码=$FAILS）"
echo "只读声明：本脚本只执行 ros2 topic list/type/hz/echo/info 与 node list；未 publish 任何话题。"
exit "$FAILS"
