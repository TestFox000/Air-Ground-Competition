# -*- coding: utf-8 -*-
import pathlib,re
f=r"D:/User/Desktop/比赛存档/v1/docs/_work/TRACK-DAY-20261022/evidence/d11_1834/7_dzbrain_1834.log"
L=pathlib.Path(f).read_text(encoding="utf-8",errors="replace").splitlines()
# split sessions
idx=[i for i,l in enumerate(L) if l.startswith("=== SESSION START")]
idx.append(len(L))
for a,b in zip(idx[:-1],idx[1:]):
    head=L[a]
    ys=[]; blocks=[]; states=[]; faults=[]
    for l in L[a:b]:
        m=re.search(r"\[T\]\s+(\S+)\s+(\S+)\s+\(([-\d.]+),([-\d.]+)\)\s+yaw([+-]?[\d.]+)",l)
        if m:
            ys.append(float(m.group(5))); blocks.append(m.group(1)); states.append(m.group(2))
        if "heading_untrusted" in l: faults.append(l)
    if not ys: continue
    print(head)
    print("  T",len(ys),"yaw",ys[0],"->",ys[-1],"delta",round(ys[-1]-ys[0],1),"est_s@5Hz",round(len(ys)/5,1),"block",blocks[0],blocks[-1],"state",states[0],states[-1],"faults",len(faults))
    if faults: print("  first fault",faults[0][:220])
    # find -0.9 and -43.4 within session
    if any(abs(y+0.9)<0.05 for y in ys) and any(abs(y+43.4)<0.05 for y in ys):
        print("  *** contains -0.9 and -43.4; indexes", [i for i,y in enumerate(ys) if abs(y+0.9)<0.05][:3], [i for i,y in enumerate(ys) if abs(y+43.4)<0.05][:3])
