# -*- coding: utf-8 -*-
import pathlib,re
f=r"D:/User/Desktop/比赛存档/v1/docs/_work/TRACK-DAY-20261022/evidence/d11_1834/7_dzbrain_1834.log"
L=pathlib.Path(f).read_text(encoding="utf-8",errors="replace").splitlines()
start=[i for i,l in enumerate(L) if l.startswith("=== SESSION START 2026-10-22")][0]
seg=L[start:]
# find T lines
rows=[]
for i,l in enumerate(seg):
    m=re.search(r"\[T\]\s+(\S+)\s+(\S+)\s+\(([-\d.]+),([-\d.]+)\)\s+yaw([+-]?[\d.]+)",l)
    if m: rows.append((i+start+1, i, float(m.group(5)), m.group(1), m.group(2), l))
print("start line",start+1,"T",len(rows),"first",rows[0][2],"last",rows[-1][2])
for i,(ln,idx,y,blk,st,l) in enumerate(rows):
    if abs(y+0.9)<0.06 or abs(y+43.4)<0.06:
        print("hit",i,"line",ln,"yaw",y,"t_est_2Hz",round(i/2,1),"t_est_5Hz",round(i/5,1))
# print around first -0.9
idxs=[i for i,r in enumerate(rows) if abs(r[2]+0.9)<0.06]
if idxs:
    a=max(0,idxs[0]-5); b=min(len(rows),idxs[0]+15)
    for i in range(a,b): print("A",i,"line",rows[i][0],"yaw",rows[i][2],"t2",round(i/2,1))
# check session header frequency
for j in range(start,min(start+30,len(L))):
    print("H",j+1,repr(L[j][:180]))
