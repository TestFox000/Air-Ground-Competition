# -*- coding: utf-8 -*-
import csv, math, pathlib, re, statistics
base = pathlib.Path(r"D:/User/Desktop/比赛存档/v1")
csvp = base/"_tmp_session/LEAD-FIELD-20261022/lead_yaw_probe_2000.csv"
rows=[]
with csvp.open(encoding="utf-8",errors="replace") as f:
    for r in csv.DictReader(f):
        try:
            rows.append({k:float(v) for k,v in r.items()})
        except Exception:
            pass
print("rows",len(rows),"cols",list(rows[0].keys()))
def regress(xs,ys):
    n=len(xs); mx=sum(xs)/n; my=sum(ys)/n
    sxx=sum((x-mx)**2 for x in xs); sxy=sum((x-mx)*(y-my) for x,y in zip(xs,ys))
    b=sxy/sxx; a=my-b*mx
    ss_res=sum((y-(a+b*x))**2 for x,y in zip(xs,ys))
    ss_tot=sum((y-my)**2 for y in ys)
    r2=1-ss_res/ss_tot if ss_tot else float("nan")
    return a,b,r2,math.sqrt(ss_res/n)
def series(key):
    return [(r["t_s"],r[key]) for r in rows if r.get(key) is not None and not math.isnan(r[key])]
for key in ["yaw_loc_deg","yaw_odom_deg","imu_yaw_deg","gyro_z_dps"]:
    s=series(key)
    if not s: print(key,"NO DATA"); continue
    a,b,r2,rmse=regress([x for x,y in s],[y for x,y in s])
    vals=[y for x,y in s]
    print(key,"n",len(s),"first",vals[0],"last",vals[-1],"slope",round(b,6),"R2",round(r2,6),"rmse",round(rmse,5),"min",min(vals),"max",max(vals))
# offset
off=[r["yaw_loc_deg"]-r["imu_yaw_deg"] for r in rows if not math.isnan(r.get("yaw_loc_deg",float("nan"))) and not math.isnan(r.get("imu_yaw_deg",float("nan")))]
print("offset loc-imu n",len(off),"mean",round(statistics.mean(off),3),"std",round(statistics.pstdev(off),3),"min",round(min(off),3),"max",round(max(off),3))
# imu rate from n_imu
ns=[r for r in rows if r.get("n_imu") is not None]
if len(ns)>=2:
    d=[ns[i]["n_imu"]-ns[i-1]["n_imu"] for i in range(1,len(ns))]
    dt=[ns[i]["t_s"]-ns[i-1]["t_s"] for i in range(1,len(ns))]
    rates=[dd/dd_t for dd,dd_t in zip(d,dt) if dd_t>0]
    print("imu rate median",statistics.median(rates),"mean",statistics.mean(rates))
# derived raw mean under two-call model: slope_rad = 0.5*(gz_raw+gz_filtered) (because two calls at 50Hz dt=1/100)
slope_imu=regress([x for x,y in series("imu_yaw_deg")],[y for x,y in series("imu_yaw_deg")])[1]
mean_gz=statistics.mean([y for x,y in series("gyro_z_dps")])
slope_rad=math.radians(slope_imu)
gz_raw=2*slope_rad-mean_gz
print("slope_imu_deg_s",round(slope_imu,6),"mean_gz_rad_s",round(mean_gz,6),"mean_gz_deg_s",round(math.degrees(mean_gz),6),"ratio",round(slope_rad/mean_gz,4))
print("inferred raw gz rad/s",round(gz_raw,6),"deg/s",round(math.degrees(gz_raw),4),"bias rad/s",round(gz_raw-mean_gz,6),"deg/s",round(math.degrees(gz_raw-mean_gz),4))
# BCD T parse
p=base/"docs/_work/TRACK-DAY-20261022/evidence/cam/7_path_BCD_1938.log"
L=p.read_text(encoding="utf-8",errors="replace").splitlines()
T=[]
for i,l in enumerate(L,1):
    m=re.search(r"\[T\]\s+(\S+)\s+(\S+)\s+\(([-\d.]+),([-\d.]+)\)\s+yaw([+-]?[\d.]+)\s+v([-\d.]+)",l)
    if m: T.append((i,float(m.group(5)),float(m.group(6)),m.group(1),m.group(2)))
print("BCD T",len(T),"first",T[0],"last",T[-1])
# overall slope vs index
a,b,r2,rmse=regress(list(range(len(T))),[x[1] for x in T])
print("BCD slope per T",round(b,5),"R2",round(r2,6),"rmse",round(rmse,4))
print("BCD slope /420s",round((T[-1][1]-T[0][1])/420,6),"delta",round(T[-1][1]-T[0][1],2))
# find line 2777 index
idx=[i for i,x in enumerate(T) if x[0]>=2777][0]
print("idx line2777",idx,T[idx])
# 30s at 2Hz = 60 samples; also 1.63Hz = 49 samples
for n in [49,60]:
    j=min(len(T)-1,idx+n)
    print("window",n,"from",T[idx][0],T[idx][1],"to",T[j][0],T[j][1],"delta",round(T[j][1]-T[idx][1],2),"slope",round((T[j][1]-T[idx][1])/30,4))
# local slope around stop (30s) and first/last 100
for name,lo,hi in [("first100",0,100),("stop",max(0,idx-20),min(len(T),idx+80)),("last100",len(T)-100,len(T))]:
    a,b,r2,rmse=regress(list(range(lo,hi)),[T[i][1] for i in range(lo,hi)])
    print(name,"n",hi-lo,"slope/T",round(b,5),"R2",round(r2,4),"delta",round(T[hi-1][1]-T[lo][1],2))
# max jumps
jumps=[(T[i][0],round(T[i][1]-T[i-1][1],2)) for i in range(1,len(T)) if abs(T[i][1]-T[i-1][1])>=0.3]
print("jumps>=0.3",len(jumps),jumps[:20])
# px/m
px_rail=140.0; ref=0.70; dist=1.41
pxm=px_rail*ref/dist
for deg in [0.7,43.0]:
    lat=dist*math.tan(math.radians(deg))
    print("deg",deg,"lat_m",round(lat,4),"px@",round(pxm,1),round(lat*pxm,2))
