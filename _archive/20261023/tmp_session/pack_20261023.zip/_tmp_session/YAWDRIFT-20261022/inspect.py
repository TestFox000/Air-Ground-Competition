# -*- coding: utf-8 -*-
import json, re, collections, pathlib
base = pathlib.Path(r"D:/User/Desktop/比赛存档/v1/docs/_work/TRACK-DAY-20261022/evidence/cam")
for name in ["7_path_A.log","7_path_B.log"]:
    p = base/name
    raw = p.read_bytes()
    print("==", name, "bytes", len(raw))
    for enc in ["utf-8","gbk"]:
        try:
            txt = raw.decode(enc)
            print(enc, "ok", repr(txt[:60]))
            break
        except Exception as e:
            print(enc, "fail", e)
    txt = raw.decode("utf-8", errors="replace")
    lines = txt.splitlines()
    print("lines", len(lines))
    tlines = [(i,l) for i,l in enumerate(lines,1) if l.lstrip().startswith("[T]")]
    print("T count", len(tlines))
    for i,l in tlines[:2]+tlines[-2:]: print("T", i, repr(l[:200]))
    ts = [(i,l) for i,l in enumerate(lines,1) if re.search(r"2026-10-22|\d{2}:\d{2}:\d{2}", l)]
    print("ts lines", len(ts))
    for i,l in ts[:3]: print("TS", i, repr(l[:180]))
for name in ["aim_rec_A.jsonl","aim_rec_B.jsonl"]:
    p = base/name
    keys = collections.Counter(); samples = {}
    with p.open(encoding="utf-8", errors="replace") as f:
        for line in f:
            try: d = json.loads(line)
            except Exception: continue
            k = d.get("k","?"); keys[k]+=1
            if k not in samples: samples[k]=d
    print("==", name, "records", sum(keys.values()))
    print(keys.most_common(20))
    for k,d in list(samples.items())[:12]: print(k, repr(d)[:220])
