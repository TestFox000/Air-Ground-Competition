# -*- coding: utf-8 -*-
import pathlib,re
p=pathlib.Path(r"D:/User/Desktop/比赛存档/v1/docs/_work/TRACK-DAY-20261022/evidence/cam/7_path_BCD_1938.log")
L=p.read_text(encoding="utf-8",errors="replace").splitlines()
print("lines",len(L))
for i in range(min(20,len(L))): print("H",i+1,repr(L[i][:200]))
T=[]
for i,l in enumerate(L,1):
    m=re.search(r"\[T\]\s+(\S+)\s+(\S+)\s+\(([-\d.]+),([-\d.]+)\)\s+yaw([+-]?[\d.]+)\s+v([-\d.]+)",l)
    if m: T.append((i,float(m.group(5)),float(m.group(6)),m.group(1),m.group(2)))
print("T",len(T),"first",T[0],"last",T[-1])
print("first 10",T[:10]); print("last 10",T[-10:])
# find -0.9 and -43.4
for i,r in enumerate(T):
    if abs(r[1]+0.9)<0.08 or abs(r[1]+43.4)<0.08: print("hit",i,r)
# timestamps anywhere
ts=[(i+1,l) for i,l in enumerate(L) if re.search(r"\d{2}:\d{2}:\d{2}|2026-10-22",l)]
print("ts",len(ts),ts[:5])
