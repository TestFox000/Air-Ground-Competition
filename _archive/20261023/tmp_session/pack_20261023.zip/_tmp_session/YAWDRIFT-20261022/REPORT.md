# 静置 yaw 漂移归因（R0，2026-10-22）
> 卡：YAWDRIFT-20261022｜owner：motion-auditor｜只读分析；不改 src/config；未 git/SSH。
> 台账：D-024（信号坏时调参=开倒车）、D-027（阿克曼硬件、守卫差速前提、先量测再改代码）
> 见 dzrobot_v2/docs/决策台账.md:41,76-85；D-027 明令不重开 0.157/守卫阈值。

## 0 结论（先看）
1. **漂移在 /imu_data.orientation 里已经存在**；serial_reader 只做 IMU yaw 转发 + 固定偏移，不做陀螺积分。
2. **主因（高置信）：dzactuator 的同一个 Mahony 四元数被两条路径各更新一次**：
   Publish_ImuSensor（原始陀螺，dzactuator.cpp:591）与 Publish_ImuSensor_filter（零偏校正+滤波，:534）
   都调用 Quaternion_Solution，更新同一组全局 q0..q3（Quaternion_Solution.cpp:212-270）。
   最终 imu_data yaw 是 raw 与 filtered 两路增量的平均，不是 filtered 单独积分。
   实测：filtered gz 均值 −0.1702°/s；orientation 斜率 −0.0705°/s；由两点反推 raw gz ≈ **+0.0292°/s**，
   两者平均 = −0.0705°/s。零偏估计 ≈ **0.1993°/s**；即零偏被 raw 路抵消了一大半。
3. **/odom yaw 恒 71.866°，不是漂移源**。dzactuator 的 Robot_Pos.Z 只在 abs(linear_Speed)>0 时更新
   （dzactuator.cpp:1298-1304），静止时不积分；且 serial_reader 选 IMU yaw、不用 /odom yaw（:197-210）。
4. **49.8° 是固定偏移，不是漂移**：/odom/localization yaw = (raw_imu_yaw − imu_yaw_init) + 90°
   （serial_reader.py:146-154,236-244；contract.py:133；geometry.py:45）。实测偏移 −49.831°±0.001°（全程恒定）。
   按当前源码，reset 只改 dr_yaw_off（DR 位置方向，:156-187,221），**不改发布四元数**；不能靠 reset 消这个偏移。
5. **30 s 停站窗口的漂移增量只有 0.7~0.8°**（[T] 2777→2848：−42.6→−43.4），
   对 1.41 m 目标横向 1.7~2.0 cm，按 69.5 px/m 仅 **1.2~1.4 px**；**不能解释 dx 中位 140 px**。
   绝对 43° 的静态航向误差在 1.41 m 处横向 1.31 m（约 91 px@69.5），它可能贡献大，但它是累计/帧误差，
   不是 30 s 窗口内的漂移，不能混为一谈。

## 1 证据与 yaw(t) 提取
| 证据 | 内容 | 用途 |
|---|---|---|
| _tmp_session/LEAD-FIELD-20261022/lead_yaw_probe_2000.csv | 118 s，1 Hz；列 t_s,yaw_loc_deg,yaw_odom_deg,imu_yaw_deg,gyro_z_dps,n_loc,n_odom,n_imu | 静置斜率/偏移/速率 |
| docs/_work/TRACK-DAY-20261022/evidence/cam/7_path_BCD_1938.log | 685 条 [T]，−0.9→−43.4，v=0，D11 IDLE/STOP/FINISH；**无时间戳** | 8 min 累计 + 停站窗口 |
| docs/_work/TRACK-DAY-20261022/evidence/cam/aim_rec_D.jsonl | FIRE 窗口 dx 中位 140 px（卡面 §10） | dx 对照 |
| _tmp_session/YAWDRIFT-20261022/analyze_probe.py | 本次回归/分段脚本 | 复跑 |
命令：

    python _tmp_session/YAWDRIFT-20261022/analyze_probe.py

结果（完整 CSV，线性回归）：

| 量 | 起点→终点 | 斜率 | R² | 备注 |
|---|---|---|---|---|
| /odom/localization yaw | −142.890→−150.992 | **−0.07049°/s** | 0.999967 | n=116 |
| /imu_data orientation yaw | −92.922→−101.163 | **−0.070492°/s** | 0.999969 | n=118 |
| /odom yaw | 71.866→71.866 | 0 | — | 恒定，50 Hz |
| /imu_data gz（列名 gyro_z_dps 实为 rad/s） | −0.00280→−0.00291 | 均值 −0.002970 | — | = −0.17015°/s |
| loc−imu 偏移 | — | **−49.831°** | std 0.001° | 固定，不是漂移 |

- /imu_data 与 /odom/localization 的斜率差 <0.00001°/s；漂移在 serial_reader 之前已存在。
- /imu_data 速率：n_imu 每秒 +50（50 Hz）；n_odom 也是 50 Hz；[T] 是 2 Hz 遥测但会丢行（BCD 685 行/约 420 s≈1.63 Hz）。
- 无阶跃：BCD 相邻 [T] yaw 差全部 <0.3°；整体对 T 序号 R²=0.999824，delta=−42.5°。

## 2 代码链与恒速漂移候选
链路：STM32 BMI088 → dzactuator（零偏/滤波/Mahony）→ /imu_data → serial_reader（减 imu_yaw_init，发四元数）
→ contract.py（+90°）→ /odom/localization → localization.py（不改 yaw，只加 yaw_trim/守卫）→ [T]。

| 候选 | 若为真的预期斜率/算式 | 判定 |
|---|---|---|
| Mahony 陀螺零偏积分 | yaw_rate ≈ gz_bias（rad/s→°/s×57.2958） | **部分真**：filtered gz −0.170°/s，但被 raw 路平均成 −0.0705 |
| 双路 q 更新（raw+filtered） | yaw_rate ≈ 0.5(gz_raw+gz_filtered)（两路各 0.5·dt；50 Hz×2×1/100=1） | **主因**：反推 raw=+0.0292，平均=−0.0705 |
| 编码器差速/ticksPer2PI | yaw_rate = (ΔR−ΔL)·360/ticksPer2PI per s | **否**：/odom yaw 恒 71.866；且 serial_reader 不用 odom yaw |
| 积分 dt 误差 | 若单路调用：rate=gz·f/100；50 Hz 单路=0.5×gz | 次要/结构性：两路 50 Hz 时因子=1，恰好抵消；若少一路/改 dt 就会变 |
| 发布斜坡/量化 | [T] 0.1° 量化；静置 0.07°/s 对应 0.7°/10 s | **弱**：probe 0.001° 分辨率，斜率仍稳定；[T] 只影响停站窗口精度 |
| 坐标系/符号 | 固定偏移 49.8°、符号翻转 | **否**：偏移恒定；斜率为负与 gz 负同向 |
| 时间基准 | BCD 无时间戳；8 min 是估计值 | **对“8 min 更快”是主不确定性**：见 §3 |

关键行号：
- orientation 是 dzactuator **自己算的 Mahony**，不是转发下位机 AHRS：dzactuator.cpp:534（imu_data）、:591（raw）；Quaternion_Solution.cpp:214-279。
- gz 单位：:997-999 的 *1000/32768/57.2957795 → **rad/s**；imu_data 发布 :528。负号=顺时针/右转，使 map yaw 减小。
- 上电零偏：imu_bias_correction :451-499，BIAS_CALIBRATION_SAMPLES=200（dzactuator.h:294）；
  只用于 filtered 路 :509,515-517；raw 路 :582-592 用未校正 gz，且两路共享 q。
- Mahony 积分硬编码 dt=1/100：Quaternion_Solution.cpp:255-257；IMU_SAMPLING_FREQ=50（:10）。
  两路×50 Hz×1/100=1.0，所以 dt 不是本次 2.4× 的直接原因；但它是“少一路/改频率就错”的结构性风险。
- /odom yaw 静止不更新：dzactuator.cpp:1298-1304；serial_reader 选 IMU：:197-210。
- 固定偏移：serial_reader.py:146-154,236-244；contract.py:133；geometry.py:45。

## 3 判别：reset、同源、B 轮、8 min 斜率
- **reset 后是否从偏移量起步**：BCD 起点 −0.9°（B 轮先 reset 再起 brain），接近 0 但**不是 0**。
  按当前源码 reset 只改 dr_yaw_off（DR 位置方向，:156-187,221），不改发布四元数；因此它不能消除 §0-4 的 49.8° 偏移。
  若现场 reset 后 [T] yaw 确实跳到 0，说明车端运行版/链路与本地源码不一致，需核对安装副本（本卡无车端访问）。
- **同源**：probe 中 loc 与 imu 同斜率（差 <1e-5°/s），偏移恒定 ±0.001°；漂移在 serial_reader 之前。
- **B 轮也漂**：7_path_B 起点 −0.9→−22.3（339 条 [T]），BCD 继续到 −43.4；不是 A 轮独有。
- **8 min 斜率更快（−0.089 vs −0.070）**：BCD **无时间戳**，685 条 [T] 的时长只能假设：
  | 假设时长 | 斜率 |
  |---:|---:|
  | 342.5 s（2 Hz 满帧） | −0.124°/s |
  | 420 s（7 min） | −0.101°/s |
  | 480 s（8 min） | −0.089°/s |
  | 600 s（10 min） | −0.071°/s |
  ⇒ 仅凭 BCD 不能证明“运行期更快”；**时间基准/丢行**是首要解释，温度/上电时长是第二解释。
  可判别数据：同一时段带 t_s 的 1 Hz probe（含 /raw 与 /imu_data 的 gz/orientation），以及 [T] 行原始时间戳；当前 probe 是 19:56、BCD 是 19:38，不是同一时段。
- **停站 30 s 变慢**（−0.027°/s）：可能来自 T 行稀疏（30 s 只有 12 条）、0.1° 量化、或 gimbal/aim 停止后振动减小；单凭现有数据不能定因。

## 4 现场最小实验（5 min，不动车；只读）
1. **同时录 /raw、/imu_data、/odom/localization、/odom** 3 min，1 Hz CSV，列含 t_s、yaw、gz、n_*；
   命令示例（车端）：

       ros2 topic hz /imu_data /raw /odom/localization /odom
       python3 /tmp/lead_yaw_probe.py > /tmp/yaw_5min.csv

   判据：/imu_data 50±2 Hz；两路 yaw 斜率差 <0.005°/s；n_imu 与 n_raw 均 50±2。
2. **加 /raw 对比**：若 /raw 的 gz 均值 ≈+0.03°/s、/imu_data ≈−0.17°/s，
   且 orientation 斜率≈两者平均 ⇒ **双路 q 更新确认**（主因）。
3. **手转 90° 已知角**：记录 /imu_data orientation 变化 vs 外部角度。
   若 orientation 只变 ~45° ⇒ dt/单路权重问题；若变 90° 但静置仍漂 ⇒ 零偏/温漂。
4. **阈值**：静置 60 s 斜率 >0.02°/s 且 R²>0.99 判真漂；abs(gz_filtered−gz_raw)>0.1°/s 判零偏/双路失配；
   orientation_slope / mean_gz <0.7 判权重/双路优先；n_imu 偏离 50±2 判时间基准。
5. **停机条件**：任何 topic 断流、yaw 跳变 >5°/s、车被碰到、命令异常 → 停采，不改阈值。

## 5 对 1.41 m 瞄准的量化
- px/m：px_per_m_rail=140 以 0.70 m 轨道标定（robot.yaml:838-840）；1.41 m 处 ≈140×0.70/1.41=**69.5 px/m**。
- 30 s 停站：0.7~0.8° → 1.41×tan(0.7~0.8°)=**1.72~1.97 cm** → **1.2~1.4 px**（69.5 px/m）；即使按 140 px/m 也只有 2.4~2.8 px。
  **不能解释 140 px**（贡献 ≤2%）。
- 绝对 43°：1.41×tan43°=**1.31 m** → **91 px**（69.5 px/m；140 px/m 时 184 px）。
  这可能是 140 px 的大头，但它是**静态累计/初始化帧误差**，不是 30 s 漂移；且 aim 视觉伺服会部分闭环，不能直接判因果。
- 结论：**30 s 停站漂移不是 dx 140 px 的原因**；要查 140 px，优先查目标运动/lead/云台控制/帧延迟，以及 43° 静态 map yaw 误差。

## 6 结论排序 / 置信度 / 边界
1. **双路 Mahony q 更新（raw+filtered）**：高置信；代码行号 + 定量反推（raw +0.029、filtered −0.170、平均 −0.0705、bias 0.199°/s）。
2. **上电零偏 200 样本残差/温漂**：中置信；只校 filtered、只 200 帧、无 ZUPT，温度/上电时长可解释 8 min 差异的一部分。
3. **8 min 更快**：中低置信；BCD 无时间戳，时间基准/丢行足以解释 −0.089 vs −0.070；需同时段 timed probe。
4. **编码器差速/坐标系符号/发布斜坡**：否；/odom yaw 恒定、偏移恒定、probe 高 R²。
5. **对 dx 140 px**：30 s 漂移仅 1~3 px，不能解释；43° 静态误差可到 91 px，但需目标相对证据，不能当已证因果。
6. 本轮未改任何 src/config；修复建议（单路 q、统一 gz、连续静态零偏/ZUPT、dt 用实际频率）属生产改动，需另卡/登记/复测；不得用放宽守卫阈值代替。
