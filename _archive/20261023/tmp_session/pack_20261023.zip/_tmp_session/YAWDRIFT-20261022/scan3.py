# -*- coding: utf-8 -*-
import pathlib,re
files=[
 r"D:/User/Desktop/比赛存档/v1/docs/_work/TRACK-DAY-20261022/evidence/d11_1834/7_dzbrain_1834.log",
 r"D:/User/Desktop/比赛存档/v1/docs/_work/TRACK-DAY-20261022/evidence/d11_1900/7_path_diag.log",
]
for f in files:
    p=pathlib.Path(f); L=p.read_text(encoding="utf-8",errors="replace").splitlines()
    print("=====",p.name,"lines",len(L))
    for i in range(min(18,len(L))): print("H",i+1,repr(L[i][:200]))
    print("LAST")
    for i in range(max(0,len(L)-6),len(L)): print("L",i+1,repr(L[i][:200]))
    ts=[(i+1,l) for i,l in enumerate(L) if re.search(r"\d{4}-\d{2}-\d{2}|\d{2}:\d{2}:\d{2}",l)]
    print("timestamped lines",len(ts))
    for i,l in ts[:3]: print("TS",i,repr(l[:200]))
    hits=[(i+1,l) for i,l in enumerate(L) if "-43.4" in l]
    print("hits -43.4",len(hits))
    for i,l in hits[:3]:
        for j in range(max(0,i-4),min(len(L),i+3)): print("CTX",j+1,repr(L[j][:220]))
