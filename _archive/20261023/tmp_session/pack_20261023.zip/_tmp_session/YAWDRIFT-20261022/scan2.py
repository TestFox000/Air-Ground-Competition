# -*- coding: utf-8 -*-
import pathlib,re
files=[
 r"D:/User/Desktop/比赛存档/v1/docs/_work/TRACK-DAY-20261022/evidence/d11_1834/7_dzbrain_1834.log",
 r"D:/User/Desktop/比赛存档/v1/docs/_work/TRACK-DAY-20261022/evidence/d11_1900/7_path_diag.log",
]
for f in files:
    p=pathlib.Path(f); L=p.read_text(encoding="utf-8",errors="replace").splitlines()
    print("==",p.name,"lines",len(L))
    for i,l in enumerate(L):
        if l.lstrip().startswith("[T]"):
            print("firstT",i+1,repr(l[:220])); break
    for i,l in enumerate(L):
        if "-43.4" in l or "43.4" in l:
            print("hit",i+1,repr(l[:260]))
    for i,l in enumerate(L):
        if "漂移" in l or "零偏" in l or "yaw" in l and ("drift" in l.lower() or "untrusted" in l):
            print("drift",i+1,repr(l[:220]))
            if i>0: pass
    # last T
    ts=[(i+1,l) for i,l in enumerate(L) if l.lstrip().startswith("[T]")]
    print("lastT",ts[-1][0],repr(ts[-1][1][:220]))
    # context around hit
    for i,l in enumerate(L):
        if "-43.4" in l or "43.4" in l:
            for j in range(max(0,i-3),min(len(L),i+4)):
                print("ctx",j+1,repr(L[j][:220]))
            break
