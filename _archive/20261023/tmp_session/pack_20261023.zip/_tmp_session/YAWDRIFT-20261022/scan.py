# -*- coding: utf-8 -*-
import pathlib,re
root=pathlib.Path(r"D:/User/Desktop/比赛存档/v1/docs/_work/TRACK-DAY-20261022")
for p in sorted(root.rglob("*.log")):
    try: txt=p.read_text(encoding="utf-8",errors="replace")
    except Exception: continue
    ts=[l for l in txt.splitlines() if l.lstrip().startswith("[T]")]
    if not ts: continue
    ys=[]
    for l in ts:
        m=re.search(r"yaw([+-]?[\d.]+)",l)
        if m: ys.append(float(m.group(1)))
    if len(ys)>=2:
        print(p.relative_to(root), "T",len(ts),"yaw",ys[0],"->",ys[-1],"delta",round(ys[-1]-ys[0],1))
print("--- search -43.4 / -0.9 ---")
for p in sorted(root.rglob("*")):
    if p.is_file() and p.suffix in (".log",".txt",".jsonl",".json"):
        try: txt=p.read_text(encoding="utf-8",errors="replace")
        except Exception: continue
        hits=[]
        for pat in ["-43.4","-0.9","43.4","yaw -0.9"]:
            if pat in txt: hits.append(pat)
        if hits: print(p.relative_to(root),hits)
