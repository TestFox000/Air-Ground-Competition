import json, sys, time, rclpy
from rclpy.node import Node
from std_msgs.msg import Int32MultiArray

DUR = float(sys.argv[1]) if len(sys.argv) > 1 else 25.0
OUT = sys.argv[2] if len(sys.argv) > 2 else "/tmp/det1022/oc.jsonl"
rclpy.init()
n = Node("oc_rec")
rows = []
t0 = time.time()
n.create_subscription(Int32MultiArray, "/offset_center", lambda m: rows.append([round(time.time()-t0, 4)] + list(m.data)), 30)
stop = time.time() + DUR
while time.time() < stop:
    rclpy.spin_once(n, timeout_sec=0.05)
n.destroy_node(); rclpy.shutdown()
with open(OUT, "w") as f:
    for r in rows:
        f.write(json.dumps(r) + "\n")
print("rows", len(rows), "dur", round(rows[-1][0]-rows[0][0], 2) if rows else 0)
