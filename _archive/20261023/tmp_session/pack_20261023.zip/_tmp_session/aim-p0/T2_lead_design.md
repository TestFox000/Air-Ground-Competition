# T2 · 「提前量并进控制环」：车端已完成，真正的缺口是【速度前馈在稳态失效】

- 卡号 T2 ｜ 作者 aim-engineer ｜ 2026-10-22 ｜ 状态：**只读设计稿（未改任何源码/配置，未跑车）**
- 设计基准 = **车端源码快照**：_tmp_session/aim-p0/car_src/（captain 10-22 只读拉取，2026-10-19 21:46 版）
  - dzrknn_dataprocess.cpp 1971 行 / include/dzrknn_dataprocess.h 403 行
  - 本地 dzrobot_v2 那份是 **10-18 旧版**（1725 行，无 smooth_track）⇒ **本卡不再引用它的行号**（对照见附录 A）
- 车端 yaml 关键值（横幅 + T1 核对）：px_per_tick 0.940 / vision_latency_ms 267 / k_sp 5.00 / ff 1.00 / slew 800 tick/s / EKF α/β 0.60/0.20 / lead_apply_gain 1.0 / smooth_track=true / 动态开火框 18~26 px / aim.lead_time_s 0.27
- 【10-22 追加】captain 要求聚焦 (a) /aim/lead_x 与 44.1 px 限幅、(b) lead_apply_gain 配置实验、(c) 仅残差项 C++ 改动；并显式标注 px/m 冲突 ⇒ **见 §10**（结论：控制环通道已存在，根因是 px_per_m 被低估 + 前馈输入源是画面系残差）

---

## 0. 结论先行

### F1（**否决档案的 P0 表述**）：lead 进环这件事，车端 10-19 就做完了

车端 cpp:121-167 的注释与代码是本卡最重要的一条证据：

| 证据 | 车端源码位置 |
|---|---|
| 结构修正注释 | cpp:121-127：「旧行为：lead 只进下面的开火判据，控制环仍把目标拉回画面中心 ⇒ 稳态 dx→0，而判据要求 abs(dx+lead) ≤ fire_dz ⇒ 只要 lead > fire_dz 就永远不开火；新行为：控制环与开火判据共用同一个瞄准误差 aim = dx + lead - laser_offset … fire_dz 可收回 14/26」 |
| 实现 | cpp:129-147：lead 超时归零(300 ms) → 增益 → 限幅 ±60 px → 一阶低通(0.25/帧) + 斜率限幅 4 px/帧 → aim_x = dx_filt_ + lead_ctrl_ - laser_offset_x_ |
| 死区作用在 aim 上 | cpp:155-167：abs(aim_x) > dz ⇒ eff_x = aim_x ∓ dz |
| 判据同源 | cpp:346-353：aim_err_x = abs(aim_x)；in_fire_zone = aim_err_x ≤ fire_dz |

⇒ **档案 03 §5「P0 结构项（约 4 行）」已在车端落地。本卡不重复它**，也不再按本地旧版给 4 行 patch。
（本地旧版那份 patch 作为「回退/移植参考」留在 T2_patch.diff 的附录，不主张实施。）

### F2（**本卡核心发现**）：两条延迟补偿**都在稳态自动归零**——因为控制环把它们的输入消掉了

| 补偿通道 | 输入 | 稳态行为 |
|---|---|---|
| C++ EKF 预测（vision_latency_ms=267） | updateSmoothTarget(aim_x,…)（cpp:149-153、996-1037）：EKF 吃的是 **aim = dx + lead − laser** | 环把 aim 拉向 0 ⇒ ekf_v = d(aim)/dt → 0 ⇒ 预测项 ekf_v·T → 0 |
| C++ 速度前馈 ff_gain=1.0 | v_ff_x = ff_gain·ekf_v/k_pt（cpp:1064） | 同上 ⇒ **v_ff → 0：唯一能给速率的通道在需要它时是 0** |
| Python 提前量 lead_time_s=0.27 | aim.py:890 lead = est.v·T，est.v = **画面系** dx 的 0.4 s 端点斜率 | 环把 dx 拉成常数 ⇒ est.v → 0 ⇒ lead → 0 |

**结构性结论：任何「用画面系残差速度算提前量/前馈」的实现，环收敛后都会自己消失；环越准，提前量越小。**
这不是参数问题，是输入源选错：**画面系速度 = 目标世界速度 − 云台自身角速度**，而控制环存在的意义正是把前者压成 0。

### F3（**量化，且与 px/tick 争议无关**）：稳态滞后 = ω·p_cfg/k_sp

环路（cpp:1079-1088）：step = (v_ff + ff_gyro)·dt + k_sp·(yaw_des − yaw_sp)·dt，限幅 slew_max·dt。
稳态（v_ff=0、ekf_v=0）⇒ ω = k_sp·(des−sp)，而 des−sp = aim_px/k_pt ⇒

    aim_ss = ω_tick · p_cfg / k_sp        （单位 px，**不含 p_true**）

代入车端参数（1 m/s、0.875 m：ω = 745 tick/s，见 §2）：
**aim_ss = 745 × 0.94 / 5 = 140 px**；环路增益 K = k_sp·p_true/p_cfg = 1.0 /s ⇒ τ = 1 s；
靶单程 0.70 m / 1 m/s = 0.7 s ≈ 0.7τ ⇒ 中段滞后 ≈ 140×(1−e^−0.7) = **70 px**。

**T1 实测中段 dx 均值 −63.9 px（G3 跟踪组）。70 vs 64，误差 9% ⇒ 模型自洽。**
⇒ 「1 m/s 跟踪不上」的主因不是视觉 0.26 s，而是**没有可用的速率前馈 + 环路增益只有 1 /s**。

### F4（**重复补偿**）：同一个 267 ms 被补了两遍

- Python：aim.lead_time_s = 0.27（robot.yaml:814/831）→ /aim/lead_x
- C++：vision_latency_ms = 267（h:122、cpp:1030-1032）→ EKF 预测到「指令生效时刻」
- 同一段延迟的两次补偿。稳态下两者都自动为 0（F2），所以平时看不出来；但**只要速度估计变准就会 2× 超前**（0.53 s）。
- ⇒ 必须**单一 owner**。建议留 C++（它有环、100 Hz、自转速），Python lead_time_s → 0。

### F5（**口径裁决**：0.27 / 267 ms / 0.5~0.9 s 三者关系）

| 量 | 值 | 是什么 | 谁在用 |
|---|---|---|---|
| T_pipe | **266.7 ms** = 8 帧×33.3 ms | 「光子进传感器 → /offset_center 出来」的**测量年龄** | vision_latency_ms=267（车端已采纳）、lead_time_s=0.27 |
| T_loop | 0.5~0.9 s | 「给一个位置阶跃 → 云台到位」的**闭环响应**（EMA 41 ms + 伺服 + 串口） | 只该进 PID/k_sp 带宽，**不是提前量** |
| 反证 | — | 0.9 s 当 T_lead ⇒ 口径 A：0.9×140 = 126 px；口径 B：0.9×700 = 630 px —— 两者都 ≥ 靶 0.70 m 行程的成像长度 | 物理不可行 |

⇒ **0.27 / 267 ms 是对的（=测量年龄）；0.5~0.9 s 是另一个量，不能当提前量。** 车端把 vision_latency_ms 设成 267，本身已证明这个口径被采纳。
（与 T4 分歧见 §9 Q1 的 30 s 判别实验。）

---

## 1. 车端控制链现状（快照行号，全部 [实]）

| 环节 | 位置 | 要点 |
|---|---|---|
| 视觉回调（唯一喂数据处） | cpp:24… | EMA(0.45) → cpp:118 |
| **瞄准误差 = dx + lead − laser 零点** | cpp:121-147 | lead 低通 0.25 + 斜率 4 px/帧 + 超时 300 ms 归零 + 限幅 ±60 px |
| EKF（α-β 0.6/0.2）吃 aim | cpp:996-1037 | 预测到 ekf + ekf_v·T，T = vision_latency_ms |
| **绝对设定值（相对当前反馈）** | cpp:1034-1036 | yaw_des = Position_1_now + px_x/k_pt（每帧按当时位置重算 ⇒ 本质是「一帧前瞻的位置目标」） |
| 100 Hz 平滑下发（单写者） | cpp:1041-1107 | step = (v_ff+gyro)·dt + k_sp·(des−sp)·dt，限幅 slew_max·dt；Position_* = yaw_sp |
| 旧增量伺服（smooth_track=false 才跑） | cpp:200-312 | 逐字保留的旧 PID/位置台阶，回退开关 |
| 开火判据 | cpp:346-353 | aim_err = abs(aim_x)；动态框 18~26 px |
| 7 条 AND | cpp:411 | in_fire_zone && aim_ready_effective && ammo && cooldown && target_confirmed |
| 两键替换 aim_ready | cpp:343-344 | in_fire_zone **不可绕过** |
| 参数声明 / 读取 / 横幅 | cpp:1598-1604 / 1739-1750 / 1879-1884 | 新键三处都要动，否则静默失效 |
| 电机反馈 Speed_1（tick/s） | cpp:1105-1116（本地同构） | **本卡修法的关键输入** |

### 1.1 车端 yaml 与本地仓库不一致（部署前必须对齐，否则一次 all 冲掉现场整定）

| 键 | 本地仓库 | 车端 |
|---|---|---|
| pid_kp / ki / kd | 12 / 0.5 / 2.4 | **10 / 0.5 / 2.0** |
| fire_dz_far / near | 25 / 26 | **18 / 26** |
| aim.lead_time_s | 0.27（:831） | 0.27（:814，行号漂移） |
| lead_apply_gain | 0.5（:228） | **1.0** |
| predict_gain | 0.5 | **0.2** |
| smooth_track / px_per_tick / k_sp / slew | **不存在** | true / 0.94 / 5.0 / 800 |

---

## 2. 数字推导（两个像素口径都给；正确性不依赖谁对）

**世界几何（与像素无关，最可靠）**：0.875 m 处 1 m/s ⇒ 1/0.875 = 1.143 rad/s = **65.5°/s**；yaw_ticks_per_deg = 11.378（=4096/360，硬件常数）⇒ **745 tick/s**。1.41 m ⇒ 40.6°/s ⇒ **462 tick/s**。
（与档案 03 §4 的 745/462 独立复现；车端 slew 800 ⇒ 0.875 m 占 **93%**、1.41 m 占 **58%**。）

**像素口径 A**（px_per_m_rail = 140，robot.yaml:840，yaml 自称「只是估值」）：
1 px = 1/140 m = 7.14 mm ⇒ θ = 7.14mm/0.875m = 0.4677°/px ⇒ **5.32 tick/px = 0.188 px/tick**；1 m/s ⇒ 140 px/s ⇒ 0.267 s 走 37.4 px。

**像素口径 B**（车端 px_per_tick = 0.94，h:121 注释称「本车实测」）：
1 px = 0.94 tick = 0.0826° ⇒ px_per_m ≈ **700**；1 m/s ⇒ **700 px/s** ⇒ 0.267 s 走 187 px（超 max_lead_apply_px=60 限幅 3 倍）。

**两口径比值 5.0**。但由 F3，**稳态滞后（px）只依赖 p_cfg 与 k_sp**：aim_ss = ω_tick·p_cfg/k_sp = 140 px，**与 A/B 谁对无关** ⇒ 所以「先修速率前馈」这条改动**不需要先解决 px/tick 争议**。

---

## 3. px_per_tick 的 5× 争议（改速率前馈之前 3 分钟测掉；它决定 k_sp 的稳定性余量）

| 锚点 | 结论 | 可信度 |
|---|---|---|
| 编码器 4096/360（h，硬件）+ px_per_m=140 + 0.875 m | 0.188 px/tick | 链条最后一步 px_per_m 是估值 |
| box_w_far=30 / near=120 px 与靶面 0.25~0.35 m | 若 near 端 120 px 对应 0.3 m 靶面 ⇒ 400 px/m ⇒ 折回 0.875 m ≈ 137 px/m ⇒ 0.19 px/tick | 依赖 near 端距离（未知） |
| h:121 注释「本车实测 ≈0.94」 | 0.94 ⇒ 0.875 m 处靶面应 210 px 宽，与 box_w 30~120 严重不符 | **可能是闭环下量的**（跟踪环开着时量 Δdx/Δtick，量到的是闭环响应，不是开环增益） |

**两种独立测法（各 1 分钟，只读）**
1. **开环**：让视觉看不到靶（或 manual_gimbal=1），手工把 Position_1 从 A 走到 B（Δ tick = D），同时录 /offset_center[0]（Δdx）⇒ **p = Δdx / D**。必须闭环关闭，否则测到的是 1/(1+K)。
2. **轨道法测 px_per_m**（robot.yaml:837-838 现成方法）：靶放 0.70 m 轨道两端读 Δdx ⇒ px_per_m = Δdx/0.70；再 p = 0.4677 / (px_per_m × 0.875 / 57.3)。

**结果怎么用**

| 测得 p | 含义 | 对策 |
|---|---|---|
| ≈0.19 | px_per_tick 写大 5× ⇒ 环路增益只有 1 /s（设计 5 /s） | 改 px_per_tick: 0.19（**yaml，不重编**）+ 保持 k_sp ≤ 5（稳定性上界 π/(2T) = 5.9 /s） |
| ≈0.94 | 标定没错 ⇒ 滞后真实（140 px） | **不要动 px_per_tick**，只做 §4 |

---

## 4. 推荐改动：**世界系速率 v_th（tick/s）** —— 一处定义、两处使用（4 行 + 2 参数）

### 4.1 物理

    dx[px] = (θ_tick − g_tick)·p
    d(dx)/dt = (ω_θ − ω_g)·p
    ⇒ 目标世界角速度 ω_θ = d(dx)/dt / p + ω_g

- d(dx)/dt / p ≈ ekf_v / k_pt（代码已有，tick/s）
- ω_g = 电机反馈 curYuntai_feedback_data.Speed_1（tick/s，代码已订阅）

⇒ **v_th = ekf_v/k_pt + s_self·Speed_1**（tick/s，s_self = ±1 现场定符号）
单位自检：(px/s)/(px/tick) = tick/s；tick/s + tick/s = tick/s —— **不含任何标定常数**。

### 4.2 两处使用（都在 100 Hz）

| 用途 | Before | After |
|---|---|---|
| 速率前馈 | cpp:1064 v_ff_x = ff_gain·ekf_v/k_pt | v_ff_x = ff_gain·v_th |
| 预测到指令生效时刻 | cpp:1031 px_x = ekf_x + ekf_v·T | px_x = ekf_x + (v_th·T)·k_pt（tick 域预测再换 px） |

**Before / After（smoothTrackStep，cpp:1063-1066）**

    -  const double v_ff_x = ff_gain_ * ekf_v_ / k_pt;   // tick/s  ← 稳态为 0
    -  const double v_ff_y = ff_gain_ * ekf_vy_ / k_pt;
    +  const double self_rate_x =
    +      ff_self_gain_ * ff_self_sign_ * (double)curYuntai_feedback_data.Speed_1;  // tick/s
    +  const double v_th_x = ekf_v_ / k_pt + self_rate_x;   // ★世界系目标角速度(tick/s)
    +  const double v_ff_x = ff_gain_ * v_th_x;             // 稳态不再归零
    +  const double v_ff_y = ff_gain_ * ekf_vy_ / k_pt;      // 俯仰本轮不动（靶只水平移动）

（预测项同理，见 T2_patch.diff 正文。）

### 4.3 为什么这样就对了（且不用改判据）

- 前馈能供出 745 tick/s ⇒ P 项只剩残差 ⇒ **aim_ss → 0** ⇒ 判据 abs(aim_x) ≤ fire_dz 自然成立（这正是 10-19 那次结构修正想达到的效果，当时缺的就是这一步）。
- aim_x 仍 = dx + lead − laser：环把 aim 压到 0 ⇒ **云台物理上停在「预测落点 + 激光零点」** ⇒ lead 的语义第一次真正生效。
- lead（位置量，补测量年龄）与 v_th·T（位置量，补指令生效前的位移）**是同一件事的两种写法** ⇒ §4.4 必须二选一。

### 4.4 单一 owner（配合 F4）

| 方案 | 做法 | 评价 |
|---|---|---|
| **A（推荐）** | C++ 内做预测（v_th·T），Python aim.lead_time_s → 0 | 环/预测/速率同处一地；Python 判据变 abs(dx) ≤ box，而环把 dx 压到 ≈0 ⇒ 一致 |
| B | Python 保留 0.27，C++ vision_latency_ms → 0 | 也能一致，但 Python 的 est.v 仍是画面系（F2）⇒ 稳态无语义 |

两方案都必须把 lead_apply_gain 保持 1.0（三消费者一致性，见附录 B）。

---

## 5. 影响面

| 项 | 影响 | 处置 |
|---|---|---|
| in_fire_zone（cpp:353） | 修好后 = 环路残差（≈dz）⇒ 门**恒开** | 需要 T4 的「预测命中误差」当安全带（本卡不做） |
| fire_dz_far/near | 不再需要吸收 lead ⇒ 可从 18~26 收到 12~14（不变量：track_deadzone < far、far > 机械精度 ~12 px） | 第三段再调（一次一变量） |
| aim_stable（cpp:332-334） | use_external_fire_gate=true 时**被旁路** ⇒ 「1.5 px/帧 恒假」不是当前阻塞项 | 修正档案口径（写进 T5） |
| slew_max 800 | 0.875 m 需 745 ⇒ 93%（无余量）；1.41 m 58% | 站距优先 1.41 m |
| 折返 | lead_ctrl_ 低通(0.25)+斜率 4 px/帧(=120 px/s) ⇒ 37 px 反向需 ~0.6 s 走完 ⇒ **折返后 0.6 s 内 aim 仍指旧方向** | 现场须知：折返窗 0.6 s = 禁开火区 |
| max_lead_apply_px=60 | 口径 B 需 187 px ⇒ 被夹到 60（欠 127 px） | 口径 B 成立时必须抬到 200（yaml 键） |
| Python 9 道硬门 | abs(dx+lead) ≤ box：方案 A 下 lead=0、环把 dx 压到 0 ⇒ 一致 | 无额外改动 |
| 观感 | 修好后靶心会偏画面一侧 ~lead px（口径 A 37 px；B 60 px 夹后） | 提前告知现场：偏才是对的 |

---

## 6. 现场验证（先 3 分钟标定，再 30 分钟 A/B）

### 6.1 标定（只读，决定走哪条路）
1. p = Δdx/Δtick（开环，见 §3）→ 期望 0.19 或 0.94
2. px_per_m（轨道两端法）→ 期望 ~140（A）或 ~700（B）
3. s_self：靶静止、手动给云台右转指令，看 dx 变化方向 ⇒ Speed_1 > 0 时 dx 减小 ⇒ s_self = +1（反之 −1）

### 6.2 A/B（每次只改一个变量）
| 步 | 改动 | 通过判据（数字） |
|---|---|---|
| S0 | 现状基线 | 靶 1 m/s：中段 abs(dx) ≈ **60~80 px**（F3 预测 70）；pub_LaserShot 计数（预期 0 或极少） |
| S1 | ff_self_gain: 0 → 0.5（新键默认 0 = 零回归） | 中段 abs(dx) **≤40 px**；无自激振荡 |
| S2 | ff_self_gain → 1.0 | 中段 **≤20 px**；aim_ss 与 abs(dx+lead) 都 ≤ 2×dz |
| S3 | aim.lead_time_s → 0（方案 A 单一 owner） | /aim/lead_x = 0；云台领先量由 v_th·T 提供 ⇒ 命中点前移；门仍开 |
| S4（仅当 §3 测得 p≈0.19） | px_per_tick: 0.94 → 0.45 → 0.19（分两步） | 中段 abs(dx) 再降；**出现等幅振荡/啸叫 ⇒ 回退一级并把 k_sp 5→3** |
| S5 | fire_dz_far: 18 → 14 | 命中率不降（裁判 HpAndHitmsg 对方 HP 下降计数） |

**失败即回滚**：任一步 abs(dx) 反而变大 / 10 s 内 3 次以上过零振荡 / pub_LaserShot 与命中明显脱钩 ⇒ 回退该步。

---

## 7. 回滚点 / 冻结区登记 / 重编部署

### 7.1 回滚（三层，都不依赖 git）
| 层 | 手段 | 生效 |
|---|---|---|
| 参数 | ff_self_gain: 0（默认关）⇒ 与原行为**逐位一致** | 重启 20 s，不重编 |
| 参数 | smooth_track: false ⇒ 整个新律关掉，回旧增量 PID | 重启 20 s |
| 部署 | deploy_to_car.py 自动 backup 到 ~/dzrobot/_backups/<ts>/（BACKUP_PATHS），回拷 + colcon build | ~2 min |

### 7.2 冻结区登记建议（tools/wf/frozen.json 的 in_flight）
    {"path": "src/dzrknn_dataprocess/src/dzrknn_dataprocess.cpp",   "card": "AIM-VTH-20261023", "owner": "aim-engineer", "reason": "T2：世界系速率 v_th = ekf_v/k_pt + Speed_1，用于速率前馈与 T=267ms 预测（ff_self_gain 默认 0）", "expires": "2026-10-30"},
    {"path": "src/dzrknn_dataprocess/include/dzrknn_dataprocess.h", "card": "AIM-VTH-20261023", "owner": "aim-engineer", "reason": "T2：新增 ff_self_gain_/ff_self_sign_ 成员", "expires": "2026-10-30"},
    {"path": "config/robot.yaml",                                   "card": "AIM-VTH-20261023", "owner": "aim-engineer", "reason": "T2：ff_self_gain/ff_self_sign/aim.lead_time_s→0/可选 px_per_tick（逐个上，先对齐车端值）", "expires": "2026-10-30"}

（现有 2 条在途：tracker.py 至 10-27、planner.py 至 11-04；本卡 3 条不冲突。）

### 7.3 编译/部署（唯一入口）
    python dzrobot_v2/tools/deploy_to_car.py probe
    python dzrobot_v2/tools/deploy_to_car.py all --dry-run
    python dzrobot_v2/tools/deploy_to_car.py all        # backup→push(dzbrain/cpp/h/robot.yaml)→colcon build
    python dzrobot_v2/tools/deploy_to_car.py verify     # 云台补丁符号检查
    ssh duzhong.local '~/dzrobot/tools/restart_node.sh gimbal'

⚠️ **部署会覆盖车端 robot.yaml**（§1.1 的 6 处差异）⇒ 先把车端 yaml 拷回仓库对齐，再 all。
收口门禁：cd dzrobot_v2 && python tools/wf/check.py；新文档另跑 python docs/_工具/check_doc_policy.py。

---

## 8. 风险清单

| # | 风险 | 触发 | 后果 | 缓解 |
|---|---|---|---|---|
| R1 | Speed_1 符号反 | s_self 未测 | 前馈变正反馈（越追越快直到 slew 限幅） | §6.1-3 先测符号；增益从 0.5 起 |
| R2 | 类型 2 化振荡 | 前馈满增益 + 267 ms 延迟 | 等幅摆动、丢靶 | S1/S2 分级；出振荡回退一级，必要时 k_sp 5→3 |
| R3 | px_per_tick 争议未决就改 | 直接写 0.19 | 环路增益 5×，吃光稳定性余量（上界 5.9 /s） | 必须先测（§3），分两步改 |
| R4 | 双重补偿 | 未做 §4.4 就同时保留 0.27 与 267 | 瞬态 2× 超前 | 单一 owner |
| R5 | 前馈稳态漂移 | 前馈供出全部速率、P 只剩残差 | 长时间恒速后设定值缓慢漂 | clampYawToScan（cpp:1091）兜边界 |
| R6 | 部署冲掉车端 yaml | 直接 all | kp/框宽/px_per_tick 被仓库值覆盖 | 先对齐（§7.3） |
| R7 | lead 幅值仍不可信 | 方案 A 下 Python lead=0，若 C++ 预测也未生效 | 回退到「欠 37 px」老状态 | S3 明确验「领先量」 |
| R8 | 观感误判 | 靶不居中 | 被当成云台坏了 | 现场先讲清 |

---

## 9. 是否建议本轮实施 + 待裁决

### 9.1 结论：**不建议照档案「4 行」实施（车端已完成）；建议实施 §4 的「世界系速率」两段式（代码 4 行 + 2 参数 + 2 yaml 键），前置 §6.1 的 3 分钟标定**

| 场景 | 建议 | 理由 |
|---|---|---|
| 有 30 min 现场 | **S0→S1→S2（速率前馈世界系）**，先不动 px_per_tick | 唯一**不需要标定**就能把中段滞后从 ~70 px 压到 ≤20 px 的改动；ff_self_gain=0 即零回归 |
| 只有 10 min | 只做 §6.1 标定 + S0 基线录数 | 标定结果决定后面所有数字（尤其 px_per_tick 与 max_lead 60 是否要抬） |
| 车端源码无法再取 | **什么都别改** | 横幅/参数/行号只对 10-19 快照有效 |

### 9.2 待裁决（每条带推荐）
| # | 问题 | 推荐 |
|---|---|---|
| Q1 | T_lead 口径：0.267（测量年龄）vs 0.55~0.95（T4 的闭环响应） | **0.267**（车端实现已如此；0.9 s 会超靶行程成像长度）；用 S3 直接量领先量 |
| Q2 | 单一 owner 放 C++ 还是 Python | **C++**（有环/100 Hz/Speed_1），Python lead_time_s → 0 |
| Q3 | px_per_tick 是否本轮改 | **先测，测得 0.19 再改**，分两步，k_sp 同步降到 ≤4 |
| Q4 | 明天打哪站距 | **1.41 m**（slew 58%、提前量 23 px、max_lead 60 不夹） |

---

## 附录 A：本地旧版 vs 车端新版（为什么不能再用本地行号）

| 项 | 本地 dzrobot_v2（10-18，1725 行） | 车端快照（10-19，1971 行） |
|---|---|---|
| lead 进环 | **没有**：lead_applied 只进 aim_err_x | **有**：aim = dx + lead − laser 进环 + 判据 |
| 跟踪律 | 增量 PID / v1 / tuned（30 Hz 台阶） | + smooth_track（EKF + 100 Hz 插值 + 绝对设定值） |
| px_per_tick / vision_latency_ms | 不存在 | 0.94 / 267 |
| lead 平滑/超时/限幅 | 无 | 低通 0.25 + 斜率 4 px/帧 + 300 ms 超时 + ±60 px |

T2_patch.diff 正文按**车端快照**写；本地旧版实现作为「要回退 smooth_track 时才需要」的附录保留。

## 附录 B：三消费者一致性（任何实现都要满足，与版本无关）

设环内施加 L（px），稳态 dx ≈ −L ± dz。三者必须同源：
1. C++ 判据 abs(aim_x = dx_filt + L_ctrl − laser) ≤ fire_dz
2. Python 判据 abs(dx + lead_py) ≤ box
3. 环：把 aim_x 拉到 ±dz

⇒ 一致性条件：L_ctrl = lead_apply_gain·lead_px = lead_py，即 **gain = 1.0**（车端已满足）。
⇒ 若 gain ≠ 1：残差 abs(1−gain)·L；gain=0.5、L=37 px ⇒ 18.7 px（18 px 框仍关）。

## 附录 C：行号总表（车端快照 2026-10-19 21:46）

| 用途 | 位置 |
|---|---|
| 瞄准误差构造（lead 进环） | cpp:121-147 |
| 死区作用在 aim | cpp:155-167 |
| 旧增量伺服（回退用） | cpp:200-312 |
| 开火判据 / 7 条 AND | cpp:346-353 / cpp:411 |
| EKF 预测（T = vision_latency_ms） | cpp:996-1037（T:1030，des:1034-1036） |
| 100 Hz 平滑下发 + 前馈 | cpp:1041-1107（前馈:1063-1066，step:1079-1088） |
| /aim/lead_x 回调（±400 守 + 时间戳） | cpp:1372-1381 |
| 参数声明 / 读取 / 横幅 | cpp:1598-1604 / 1739-1750 / 1879-1884 |
| 头文件成员 | h:112 lead_ctrl_ / 121 px_per_tick_ / 122 vision_latency_ms_ / 125 k_sp_ / 126 ff_gain_ / 127 slew_max_ / 128 ekf_x_,ekf_v_ |
| Python lead 源（与本地同构） | car_src/.../tasks/aim.py:528 / 593 / 883-892 |
| 冻结区 / 部署 | tools/wf/frozen.json:3-8 / deploy_to_car.py:55-74,89 |

---

## 10. 【10-22 追加】按 captain 要求聚焦 (a)(b)(c)，并显式标注 px/m 冲突

### 10.0 先确认：控制环通道已存在（与 captain 核对一致）

- cpp:139 lead_target = lead_apply_gain_ × lead_px_；cpp:142 lead_step = 0.25×(target−lead_ctrl_)（一阶低通+斜率限幅）；cpp:146 aim_x = dx_filt_ + lead_ctrl_ − laser_offset_x_；cpp:1499 订阅 /aim/lead_x —— 与 captain 核对完全一致。
- ⇒ 本卡**全部撤回**「把 lead 加进控制环」的设计（§0-F1 已先行给出同一结论）；C++ 部分只剩 §4 的「前馈输入源」这一处残差项。

### 10.1 (a) /aim/lead_x 的产出与 44.1 px 限幅：**根因是 px_per_m 被低估，不是限幅本身**

**产出链**：RailEstimator 的 est.v（画面系 px/s，aim.py:332-340）→ lead = est.v × 0.27（aim.py:890）→ 限幅 _max_lead_px = 0.45 × rail_span(0.70) × px_per_m(140) = **44.1 px**（aim.py:591-592）→ /aim/lead_x（aim.py:757-758）→ C++ 低通 0.25 + 斜率 4 px/帧 + 超时 300 ms + ±60 px 限幅（cpp:139-146）。

**自洽性定理（本卡推导，可复算）**：

    限幅   = 0.45 × 0.70 m × px_per_m = 0.315 s × (px_per_m × 1 m/s)
    需要   = T_lead × v_px_s = 0.267 s × (真实 px/s)
    只要两者同一套单位 ⇒ 限幅/需要 = 0.315/0.267 = 1.18  ⇒ 永不截断

⇒ **只要出现截断（T3 观测到需 93 px > 44.1），就证明「算限幅用的 px_per_m」与「est.v 量到的真实 px/s」不是同一套单位**：限幅按 140 算，而 est.v 按真实尺度（≈300~500）量。
⇒ **修法 = 把 px_per_m_rail 改成实测值**（一个 yaml 键）：px_per_m=298 ⇒ 限幅 0.315×298 = **93.9 px**，恰好覆盖 T3 的 93 px；同时 _v_expected（aim.py:593）与估计器速度上限（aim.py:607-608）随之自洽，**不需要动 max_lead_factor**。
⇒ 反之只调 max_lead_factor，会把「估算错误」搬到 _v_expected、速度上限、turnaround 阈值上，**不推荐**。

### 10.2 四条 px/m 口径对照（**冲突显式标注**）+ 唯一判据

换算恒等式：**px_per_m(D) = px_per_tick × 11.378 × 57.3 / D**（11.378 = 4096/360 tick/deg）

| 口径 | 值 | 0.875 m 处 | 1.41 m 处 | 来源 |
|---|---|---|---|---|
| A 仓库 yaml | px_per_m_rail = 140 | **140** | 87 | robot.yaml:840（自称「只是估值」）|
| B T3 实测反推 | 25 px ≈ 0.084 m @1.41 m | 451~477 | **280~296** | T3 报告（captain 转述）|
| C 车端 px_per_tick | 0.94 px/tick | **700** | 435 | h:121（注释称「本车实测」）|
| D box_w 反算 | near 120 px @0.3 m 靶面 / 0.3 m | 137 | 85 | robot.yaml:185-186 + 靶面 0.25~0.35 m |

- **B 与 C 在 1.41 m 处只差 1.5×（296 vs 435），但 A/D 比它们小 3.2~3.5×** ⇒ 两个现场反推都指向「yaml 的 140 大约小 3 倍」。
- **但 F3 的「中段滞后 70 px」模型只在 A（p_true≈0.19）下与 T1 实测 64 px 吻合**（B/C 口径会预测 120~136 px）。⇒ **A 与 B/C 必有一方测错，本卡不下结论。**
- **唯一判据（2 分钟，只读）**：靶放 0.70 m 轨道两端、云台锁死不跟踪，读 /offset_center[0] 的 Δdx ⇒ **px_per_m(0.875) = Δdx / 0.70**。
  预测：**Δdx ≈ 98 px ⇒ 口径 A 对**；≈200 px ⇒ B 的边缘；**≈315 px ⇒ T3 对**；≈490 px ⇒ C 对。
  测完，lead 幅值（37 / 93 / 187 px）、限幅、fire_dz 全部有唯一答案；**测出来之前任何 lead 幅值都是猜**（但 F2/F3——世界系速率、环路增益只有 1/s——与 px/m 无关，仍成立）。

### 10.3 (b) lead_apply_gain 0.5→1.0 的配置级实验：**结论是必须保持 1.0**

- **车端已经是 1.0**（captain 10-22 核对）⇒ 实验从「0.5→1.0」变成「1.0 vs 0.5 对照」，本卡推荐**保持 1.0**：
  一致性条件（附录 B）：残差 = abs(1−gain)·L。
  - 若 L ≈ 93 px（T3 口径）：gain=0.5 ⇒ 残差 46.5 px > 18~26 px 框 ⇒ **门直接关死**；
  - 若 L ≈ 44 px（口径 A + 1.41 m）：gain=0.5 ⇒ 22 px 勉强，gain=1.0 ⇒ 0 px ✓。
  ⇒ **gain 只能 1.0**；想保守应减 lead_time_s（改幅值），而不是减 gain（会破坏三消费者一致性）。
- 验证方法（5 分钟，纯 yaml + 重启，零重编）：
  1. ros2 param get /dzrknn_dataprocess lead_apply_gain ⇒ 期望 1.0；
  2. ros2 topic echo /aim/lead_x --once ×3（静止/左移/右移）⇒ 幅值与符号（口径 A：0/±37；T3 口径：0/±93）；
  3. 靶 1 m/s 跟踪：dx_filt 是否稳定停在 **−lead** 附近（目标偏画面一侧）⇒ 「偏」= 提前量真生效；
  4. 若 1.0 与 0.5 都 0 发 ⇒ L 与框量级不匹配 ⇒ 回 §10.2 测量。
- 回退：yaml 改回 + ssh … '~/dzrobot/tools/restart_node.sh gimbal'（20 s）。

### 10.4 (c) 若确需 C++：只做「前馈输入源」这一处残差项（4 行 + 2 参数）

- 内容 = §4 的 v_th = ekf_v/k_pt + s_self·Speed_1（tick/s）；只改**前馈与预测的输入源**，**不动**判据（cpp:346-353）、死区（cpp:155-167）、两键（cpp:343-344）、类别锁、弹药。
- 影响面：ff_self_gain 默认 0 ⇒ **逐位零回归**；打开后只影响 yaw 前馈与 T=267 ms 预测项；俯仰不动。
- 回滚：ff_self_gain: 0（yaml，重启 20 s）＞ smooth_track: false（整律回退）＞ _backups 回拷重编（~2 min）。
- 数值预期：中段 abs(dx) 70 px → S1(0.5) ≤40 px → S2(1.0) ≤20 px；出等幅振荡即回退一级并把 k_sp 5→3。

### 10.5 修订后的本轮建议（一句话版）

1. **先做 §10.2 的 Δdx 测量（2 min）** —— 一个数定全局；
2. 若 T3 口径成立 ⇒ px_per_m_rail: 140 → 实测值（**限幅与 lead 同时到位，不重编**），lead_apply_gain 保持 1.0；
3. 若中段 abs(dx) 仍 >40 px ⇒ 上 §4 的 v_th 前馈（4 行，默认关）；
4. **任何情况下都不要先动 fire_dz**（先让瞄准跟上，再收紧框；抬框/收框都是二阶动作）。

