# T4 · 0.26 s 视觉滞后实验设计 + 开火判据替代（预测命中误差）

> 卡号 t4 · 成员 pipeline-eng · 2026-10-22
> 取证：实（代码/配置行号）/ 档（已归档文档）/ 推（本文推导）/ 未（未验证）
> 边界：**本轮只读**。未改代码、未改配置、未跑车、未新建脚本；全部产出仅本文件。

**一句话结论**：0.26 s 只是「流水线」这一段；从「光子进传感器」到「云台真的指到新位置」的真实口径是 **0.55~0.95 s**〔档/待实测〕。
把 `thread_num` 8→3 只能砍掉其中 **0.167 s**，但它换来三件可用的事：① 预测有效窗口 21%→44%；② 速度估计「已武装」窗口 0%→20%（1 m/s、0.70 m 轨道下）；③ 提前量幅值 −23 px。
真正决定「1 m/s 能不能开火」的不是滞后本身，而是 **`lead` 有没有进控制环、以及 `T_set` 是否等于实测 τ** —— 判据只负责在打不中时**诚实关闸**。

---

## 0. 结论先行（给 T5 排序用）

| # | 结论 | 等级 | 证据 |
|---|---|---|---|
| C1 | 滞后是**结构性**的：`put()` 每拍入队、`get()` 取**队首最老**，前 `thread_num` 拍不取 ⇒ 稳定 k 帧滞后；k=8、33.3 ms/拍 ⇒ **266.7 ms** | [实] | `rknnPool.hpp:95-111`、`det_node.cc:228-238`、`det_node.cc:67-74` |
| C2 | 但代码结构 ≠ 实际瓶颈：若单帧推理 `T_infer` > 33.3 ms，稳态滞后 = **max(k·T_tick, T_infer)**，此时**降 k 不省滞后、只掉吞吐** | [推] | §2.2；须用 k=1 诊断实测 |
| C3 | 现役判据在 1 m/s 下的等价形式是**速度门**：`\|dx + v·0.27\| ≤ 25`，dx≈0 ⇒ `\|v\| ≤ 92.6 px/s`（0.875 m 处 = **0.66 m/s**；1.41 m 处 = 1.07 m/s） | [推] | `aim.py:948-953`、`robot.yaml:831,179` |
| C4 | 该门**低估**真实脱靶量 2~3.5 倍：判据用 T_set=0.27，真实 τ=0.55~0.95 ⇒ 1 m/s 时真实超前 77~133 px（0.875 m），而门只算到 37.8 px | [推] | §3.1；须 §2.3 标定 τ |
| C5 | `aim.max_lead_factor=0.45` 把提前量硬夹在 **±44.1 px = 0.315 s**（1 m/s）⇒ 即便把 `lead_time_s` 改到 0.55，也**表达不出来** | [实+推] | `aim.py:591-592`、`robot.yaml:833,840` |
| C6 | 25 px 框在 0.875 m 处 ≈ 靶面半径（24.5 px，几乎精确相等）；但在 **1.41 m 处物理半径只有 15.2 px**，框仍是 25 px ⇒ D11 的「23 px < 25 px」是**判据假象**，真实脱靶 0.27 m > 半径 0.175 m | [推] | §3.4；须现场读一帧 `box_w` 复核 |
| C7 | 折返是**硬约束**：1 m/s、0.70 m 轨道 ⇒ 每 0.7 s 折返一次；τ=0.55 时「估计器盲窗 = τ + warmup 0.167 s = 0.72 s > 0.7 s」⇒ 1 m/s 下 `armed` **几乎永远为假** | [推] | §2.6；`aim.py:242,223-225`、`robot.yaml:833` |

**一句话排序**：T2（lead 进环）+ T4 的 τ 标定 = P0（同一件事的两个零件）；`thread_num` 8→3 = P1（便宜、可逆、单独做也买不到「能开火」，但把上面 C7 从 0% 拉到 20%）；判据替换 = P1 的配套闸门（防止 T2 改完后旧判据退化成恒真）。

---

## 1. 事实基线

### 1.1 滞后结构（代码级）

| 事实 | 值/行为 | 出处 |
|---|---|---|
| 采样周期 | 定时器 `max(33 ms, 1000/max_fps)`，`max_fps=30` ⇒ **33 ms** | `det_node.cc:67-74`、`robot.yaml:306` |
| 推理线程数 | 代码默认 **4**，YAML 覆盖为 **8** | `det_node.cc:39`、`robot.yaml:305` |
| 入队 | 每拍 `put(frame, frames_)` 压入一个 future | `det_node.cc:228-232`、`rknnPool.hpp:91-100` |
| 取结果 | 前 `thread_num` 拍**不取**；此后每拍 `get()` 弹出**队首（最老）** | `det_node.cc:234-238`、`rknnPool.hpp:102-111` |
| 稳态队列长度 | k 个 future 在途（k=`thread_num`） | [推]：第 k 拍 push 后弹 1，剩 k |
| 第 k 拍发布的是第 0 拍的帧 | 滞后 = k × T_tick | [推]，与档案 0.26 s 一致〔档：`03` §3〕 |
| 运行期能否改 | **不能**：`declare_parameter` 后只在构造函数 `get_parameter`，无回调 ⇒ 必须重启节点 | `det_node.cc:37-47` |
| 启动日志可自证 | `视觉检测: 模型=… 线程=%d 推理周期=%dms` | `det_node.cc:76-79` |

> ⚠️ 配置漂移陷阱：YAML 缺失/改名时实际生效的是**代码默认 4**（滞后 133 ms，不是 267 ms）。实验前必须用 `ros2 param get /det_node thread_num` + 启动日志双确认〔实〕。

### 1.2 延迟预算账（决定提前量量级的账）

| 环节 | 符号 | 量（k=8） | 依据 | 现场怎么测 |
|---|---|---|---|---|
| 流水线（FIFO k 帧） | `T_pipe` | **267 ms** | `rknnPool.hpp:95-111` + `det_node.cc:228-238` | 阶跃：图像事件→`/offset_center` 变化 |
| EMA 滤波（斜坡稳态滞后） | `T_ema` | **40.7 ms**（α=0.45 ⇒ (1−α)/α×33.3 ms） | `robot.yaml:123` | 计算；C++ 侧 `dx_filt_` 才含它 |
| 视觉→控制回调 | `T_ctrl` | ≤ 10 ms（100 Hz 主循环） | 〔档：`01` §1〕 | `CameMo_Conl` 阶跃 |
| 伺服 + 串口 + 下位机 | `T_servo` | **未测**；按档案 0.5~0.9 s 总量反推 ≈ **0.24~0.64 s** | 〔档：云台补丁说明 §一〕 | `camemo_feedback.Position_1` 稳定到新指令 |
| **合计 τ（判据要用的那个）** | `τ = T_pipe+T_ema+T_ctrl+T_servo` | **0.55~0.95 s** | [推] 由上行相加 | 阶跃到编码器稳定，**一个数** |

> 注：档案里的「0.5~0.9 s」是粗口径，且可能把「冷却」也算进去了；冷却不是延迟。**必须用 §2.3 的阶跃法实测 τ**，不要照抄。
> 同样的账换成 k=3：`T_pipe`=100 ms ⇒ τ ≈ **0.39~0.79 s**；k=2：67 ms ⇒ τ ≈ **0.36~0.76 s**。

### 1.3 现役开火判据的**真实**形态（别照着缺口表读）

| 事实 | 内容 | 出处 |
|---|---|---|
| 两键开火**已开** | `use_external_fire_gate: true` ⇒ C++ 侧 `aim_ready_effective = external_gate && external_ready`，**不再叠加**「画面稳定」 | `robot.yaml:227`、`cpp:290-291` |
| 但 `in_fire_zone` 仍在 | `\|dx_filt + 0.5×lead_px\| ≤ fire_dz`，`lead_px` 来自 `/aim/lead_x` | `cpp:299-302`、`cpp:1169-1177` |
| Python 侧另有一道 | `pred = dx + v×0.27`；`moving_lead` ⇒ `\|pred\| ≤ box` | `aim.py:948-953`、`aim.py:528` |
| 两道门都要过 | 有效门 = min(Python 速度门 92.6 px/s, C++ 速度门 25/(0.5×0.27)=185 px/s) | [推] |
| 旧「1.5 px/帧」判据 | **当前被旁路**（仅 `use_external_fire_gate=false` 时生效）。它不是"正在档住"，是"已退役但代码还在" | `cpp:279-281,290-291` |
| 保持帧数 | `fire_hold_frames=5`（≈0.167 s @30 Hz） | `robot.yaml:187`、`cpp:360-363` |
| 提前量限幅 | `0.45 × 0.70 m × 140 px/m = 44.1 px` ⇒ `lead_time_s` 最大只能表达 **0.315 s**（1 m/s） | `aim.py:591-592`、`robot.yaml:833,840` |
| 机械精度地板 | 配置自述「云台机械精度约 12 px」，故 `fire_dz_far` 必须 > 12 | `robot.yaml:20,180-181` |

**由此得到本卡最重要的一句**：现役判据不是"要求画面静止"（那条已退役），而是**"目标在滞后窗口内的位移必须小于开火框"**（`\|v·T_set\| ≤ box`）。这是一种**速度门**，不是命中判据。

---

## 2. 实验设计：`thread_num` 8 → 3 / 2

### 2.1 假设与可证伪预测（先写下来，再去现场）

| 编号 | 假设 | 若成立应看到 | 若看到别的 ⇒ 结论 |
|---|---|---|---|
| H1 | 滞后是 FIFO k 帧结构 | `T_pipe(8) ≈ 267±20 ms`；`T_pipe(3) ≈ 100±20 ms`；`T_pipe(2) ≈ 67±20 ms`；且随 k **线性** | 若 T_pipe(1) 明显 > 40 ms ⇒ 推理**已饱和**，滞后 = `T_infer`，**降 k 无效**（H1 被推翻，见 H2） |
| H2 | 单帧推理不饱和 | `f_det(8) ≈ 30 Hz`，且 `T_pipe(1) ≈ 33 ms` | 若 `f_det(8) < 28 Hz` ⇒ 8 线程已在饱和区，档案的 0.26 s 可能只是 `T_infer` 的巧合 |
| H3 | 吞吐代价可接受 | k=3 时 `f_det ≥ 27 Hz`（≤10% 掉帧） | 若 `f_det < 25 Hz` ⇒ k=3 不合格，退回 k=4/5，或先关 `draw`（另开一变量） |
| H4 | 滞后线性带来判据收益 | k=3 时 `T_pipe` 下降 ≥ 预测值的 60%（≥100 ms） | 下降不足 ⇒ 组合根因（DDS 排队、`draw` 阻塞、CPU 降频），转 §2.9 排查 |

> **k=1 是诊断，不是候选**：`T_pipe(1) = max(33 ms, T_infer)` —— 一次重启就能把 `T_infer` 直接量出来，这是全实验里性价比最高的一步。

### 2.2 模型（为什么「降 k 不总是省滞后」）

设单帧推理耗时 `T_infer`、线程数 k、采样周期 `T_tick=33.3 ms`：

```
T_tick_eff(k) = max(T_tick, T_infer / k)     # 回调被 get() 阻塞后的实际节拍
T_pipe(k)     = k * T_tick_eff(k) = max(k*T_tick, T_infer)
f_det(k)      = 1 / T_tick_eff(k) = min(1/T_tick, k/T_infer)
```

- 不饱和（`T_infer ≤ k·T_tick`）：`T_pipe = k·T_tick`，滞后随 k 线性 ⇒ 降 k 有效。
- 饱和（`T_infer > k·T_tick`）：`T_pipe = T_infer`，**与 k 无关**；降 k 只降吞吐。
- 推论：**k 的最优值 ≈ ceil(T_infer / 33.3 ms)**，再小只会掉帧不掉滞后。

### 2.3 端到端滞后标定（三种量法，必须交叉验证）

**方法 A（主）· 阶跃响应 + 图像时间戳**

1. 相机拍静止靶（打印靶面或 1:1 圆片），手/滑台**瞬移 ≥ 60 px**（≈0.43 m @0.875 m）。
2. 同一台车机上跑记录器（明天再建，**本轮不建脚本**）：订阅
   - `/image_raw`（`sensor_msgs/Image`，只用 `header.stamp` 定位阶跃帧）
   - `/offset_center`（`data[0]=dx`、`data[3]=box_w`）
   - `/CameMo_Conl`（`data[1]=水平位置指令`）
   - `/camemo_feedback`（`Position_1=编码器实际`）
   全部记 `recv_monotonic`。
3. 离线：模板匹配找「阶跃出现在哪一帧」→ `t0 = header.stamp`；找「dx 首次到新值」→ `t1`。
   `T_pipe ≈ t1 − t0`（量化 ±33 ms，n=20 取均值，95% CI ≈ ±10 ms）。
4. 同一套数据把 τ 量全：`t0 →` 编码器稳定到新指令 = **τ**（判据 §3 直接用它）。

> ⚠️ 先查 `ros2 topic echo /image_raw --field header.stamp --once`。若 stamp 为 0（驱动没打时间戳）⇒ 用接收时间替代，并改为**纯差分法**：同一阶跃在 k=8/k=3 下各测一次，两者之差 = 6×33.3 = 200 ms，公共误差（手感、传输）自动抵消。**这是本实验最稳的判据，不依赖绝对时间。**

**方法 B（交叉验证）· 视觉–云台分解**
把 τ 拆成四段，逐段量（都用 `recv_monotonic`，同一时钟域）：

| 段 | 量什么 | 预期 |
|---|---|---|
| ① 光子→`/offset_center` | 阶跃帧 stamp → 首条新 dx | = `T_pipe`（本实验自变量） |
| ② `/offset_center`→`/CameMo_Conl` | 首条新 dx → 指令变化 | ≤ 10 ms + 1 帧 |
| ③ 指令→`camemo_feedback` | 指令变化 → 编码器到新位置 | 串口 + 下位机，**待测** |
| ④ 反馈→画面真动 | 编码器 → 图像里靶相对偏移改变 | 闭环稳定时间（可省） |

①+②+③ 就是判据要的 τ；① 就是本实验要砍的那段。

**方法 C（兜底）· 手机高速录像**
240 fps 拍「靶 + 激光点（或云台）」同框，另用调试屏显示 `/offset_center` 翻滚数字；以靶过参考线为 t0。精度 ±4 ms，但费人工；仅当 A/B 打架时用。

### 2.4 feature flag 形式（不直接改默认值）

| 级别 | 形式 | 改文件？ | 重编？ | 回滚 | 用途 |
|---|---|---|---|---|---|
| **F1（推荐）** | 启动期参数覆盖：`ros2 run det_node det_node --ros-args --params-file ~/dzrobot/config/robot.yaml -p thread_num:=3` | ❌ 零改动 | ❌ | 重启节点 20 s | 明日现场实验 |
| F2 | `_tmp_session/aim-p0/exp/det_node_t3.launch.py`：`parameters=[CONFIG_FILE, {'thread_num': 3}]` | 只写 `_tmp_session` | ❌ | 换回原 launch | 要复用多次时 |
| F3（P1 结构项） | 新增参数 `pool_get: oldest\|latest`，`get()` 改为「取最新已完成」；或 `thread_num` 加参数回调重建池 | ✅ 冻结区 `src/rknn_pt` | ✅ | git revert + 重编 | 实验证明 FIFO 是主因后再做 |
| F4（永久改默认） | 把 `robot.yaml:305` 的 8 改成 3 | ✅ 冻结区 `config/**` | ❌ | git 回滚 + 冻结登记销账 | **实验通过后**，走 §2.8 登记 |

> F1 的两条硬前提〔实〕：① 参数只在构造期读（`det_node.cc:37-47`）⇒ 必须重启，`ros2 param set` 无效；② 包名/可执行名都是 `det_node`（`package.xml:3`、`CMakeLists.txt:2,18`），launch 也只加载这一个 YAML（`det_node.launch.py:28-34`）⇒ `--params-file` + `-p` 等价于原 launch，不引入第二真源。

### 2.5 步骤（一变量原则）

**常量（全程不动）**：`draw: true`、`max_fps: 30.0`、`model_path: ""`（同一 `light_det.rknn`）、相机曝光/增益、光照、靶位与靶速、云台 `pid_*/ema_alpha/predict_gain/lead_*` 全部不动、`use_external_fire_gate=true`。
**唯一自变量**：`thread_num`。

| 步 | 配置 | 目的 | 时长 | 记录 |
|---|---|---|---|---|
| E0 | k=8（现状） | 基线：f_det、T_pipe、τ、CPU、温度 | 3 min | `run_k8_a.csv` |
| E1 | k=1 | **诊断**：直接读 `T_infer`（`T_pipe(1)=max(33,T_infer)`） | 2 min | `run_k1.csv` |
| E2 | k=3 | 候选 A | 3 min | `run_k3.csv` |
| E3 | k=2 | 候选 B | 3 min | `run_k2.csv` |
| E4 | k=8（复测） | 漂移/热漂检查（E0 与 E4 差 > 20 ms ⇒ 数据作废重来） | 3 min | `run_k8_b.csv` |

每步之间只重启 `det_node`（`pkill -f det_node` → 按 F1 起），其余节点不停；每步开始先核 `ros2 param get /det_node thread_num` 与启动日志「线程=k」，结束前存 `ros2 topic hz` 输出。

### 2.6 收益 vs 吞吐（表，按 `T_infer` 分档）

`T_pipe(k)=max(k·33.3, T_infer)`，`f_det(k)=min(30, k/T_infer)`；超前量按 1 m/s、140 px/m（0.875 m）：

| `T_infer` | k=8 | k=3 | k=2 | 结论 |
|---|---|---|---|---|
| 30 ms | 267 ms / 30 Hz | 100 / 30 | 67 / 30 | 三者都不掉帧，**k=2 最优** |
| 60 ms | 267 / 30 | 100 / 30 | 67 / 30 | k=2 仍 30 Hz（2/0.06=33） |
| 80 ms | 267 / 30 | 100 / 30 | **80 / 25** | k=3 是拐点，k=2 掉 17% |
| 100 ms | 267 / 30 | 100 / 30 | 100 / 20 | k≤3 都到地板 100 ms，**k=3 最优** |
| 150 ms | 267 / 30 | **150 / 20** | 150 / 13 | 只能 k≥5；此时降 k 无收益 |

**非吞吐收益（与 `T_infer` 无关，只与 τ 有关）**——这三条才是本实验的正当理由：

| 指标（1 m/s、0.70 m 轨道、0.267/0.100 s 流水线 + 0.24~0.64 s 伺服） | k=8 | k=3 | 公式 |
|---|---|---|---|
| 估计器「已武装」窗口 / 0.7 s 单程 | **0%**（τ=0.55 ⇒ 盲窗 0.72 s > 0.7 s） | **≈20%**（τ=0.39 ⇒ 盲窗 0.56 s） | `0.70 − (τ + 5帧×33 ms)` / 0.70 |
| 预测有效窗口（折返不落在 τ 内） | **21%**（τ=0.55） | **≈44%**（τ=0.39） | `1 − τ/0.70` |
| 需要提前量（0.875 m） | 77~133 px（**超 44 px 限幅**） | 55~111 px（仍超限幅） | `140 px/s × τ` |
| 单程可开火窗（含 5 帧保持） | 0.15 s < 0.167 s ⇒ **恒不满足** | 0.31 s ⇒ 勉强满足 | `0.70 − τ` |

> 结论：k=3 买到的不是"命中"，是**"从结构上不可能开火"变成"有窗口、但要打中还得靠 T2 的 lead 进环"**。

### 2.7 验收门限（机器可判）

| 判据 | 门限 | 命令/证据 |
|---|---|---|
| 滞后下降 | `T_pipe(3) ≤ T_pipe(8) − 100 ms`（预测 −167 ms，允许 60% 达成） | 阶跃 n=20，均值 + 95% CI |
| 不掉帧 | `f_det(3) ≥ 27 Hz`（≥90% 基线） | `ros2 topic hz /offset_center` 30 s |
| 不劣化跟踪 | `out_of_box` 事件率不高于基线 +20%；`/aim/status` 不异常 | 车端日志 `4_det.log` / aim 日志 |
| 不热降频 | 结温/CPU 不高于基线 +10 ℃ | `cat /sys/class/thermal/thermal_zone*/temp` |
| 可复现 | E4 与 E0 的 `T_pipe` 差 ≤ 20 ms | 两次 k=8 |

### 2.8 回滚

| 层级 | 回滚动作 | 耗时 | 残余 |
|---|---|---|---|
| F1/F2 | 用原命令重启 `det_node`（或原 launch），核 `param get=8` + 日志「线程=8」 | < 30 s | 无（磁盘零改动） |
| F3 | `git -C dzrobot_v2 checkout -- src/rknn_pt` + 重编 + 重启 | 5 min | 无 |
| F4 | 回滚那 1 行 YAML → `git diff` 必须为空 → 冻结登记销账（`tools/wf/frozen.json`） | 2 min | 无 |

### 2.9 禁止 / 风险

- ❌ 不能同时改 `draw`、`max_fps`、模型、`lead_time_s`（那是 T2 的变量）——混了就说不清是哪个起作用（`AGENTS.md` §1 铁律 6：一次只改一个变量）。
- ❌ 不能用 k=1 的掉帧去"证明" 8→3 不行：k=1 是诊断，不是候选。
- ⚠️ `get()` 阻塞在主线程定时器里 ⇒ 若 `T_infer` 远大于周期，k 很小的配置会让 `/offset_center` 低于 20 Hz；云台 `vision_timeout_ms=1000` 虽不会触发，但速度估计窗口会变稀（0.4 s 内样本从 12 → 8）。
- ⚠️ 重启 `det_node` 期间云台会收到全 0 心跳（无目标帧）而进 RESCAN；实验用静止靶 + 手动锚定，避免把"重扫"误当成"跟丢"。
- ⚠️ `draw:true` 的 `imshow+waitKey` 在 ARM 上是可观开销（`det_node.cc:80-84` 自述）——它是 `T_infer` 之外的第二开销；**本轮不碰**，留作"若 k=2 掉帧"的下一步单变量实验（draw→false）。

---

## 3. 判据替代：预测命中误差

### 3.1 旧判据在 1 m/s 下为什么恒假（复算）

- 旧「画面稳定」门：`\|vx\|, \|vy\| ≤ 1.5 px/帧`（`cpp:279-281`）。1 m/s ⇒ 4.67 px/帧（`03` §4）⇒ 恒假。
  等价说法：`1.5 px/帧 × 30 fps = 45 px/s = 0.32 m/s @140 px/m` —— **这条门隐含"靶速 ≤ 0.32 m/s"**，它当年是为慢靶整定的。
- 但它**当前被旁路**（两键开火，`cpp:290-291`）。真正在跑的是 `\|dx + v·T_set\| ≤ box`：
  - 稳态 dx≈0 ⇒ 门退化成 `\|v\| ≤ box/T_set = 25/0.27 = 92.6 px/s`（0.66 m/s @0.875 m）。
  - 1 m/s = 140 px/s ⇒ **0.875 m 恒假**；1.41 m = 86.9 px/s ⇒ 勉强过（6% 余量）——这正是 D11 建议的来由，也是 C6 说的"判据假象"。

### 3.2 预测命中误差 e_pred（公式 + 单位）

**定义**：开火瞬间，激光落点与靶心在画面水平方向的**预测偏差**（px）。

```
e_pred(t) = | x(t) + v̂(t)·τ − L_srv(t) − b_l |          [px]
```

| 符号 | 含义 | 单位 | 来源 | 现役值 |
|---|---|---|---|---|
| `x` | 最新一帧水平偏移 `dx`（C++ 用 `dx_filt_`） | px | `/offset_center[0]`、`contract.py:217` | — |
| `v̂` | 轨道速度估计（时间戳驱动、长基线端点差分） | px/s | `aim.py:1192`（遥测 `v_px_s`）、`RailEstimator` | — |
| `τ` | **光子→云台真的指到新位置**的总滞后 | s | §2.3 实测（本卡产出） | 0.55~0.95〔推/待测〕 |
| `L_srv` | **真正进伺服环**的提前量 | px | 现役 **0**（lead 只进判据，`cpp:294-302`；T2 负责进环） | 0 |
| `b_l` | 激光-相机不同轴偏移 | px | `robot.yaml:212-213` | **0.0，未标定** |
| `box` | 开火框半宽 | px | `fire_dz_far/near`，`robot.yaml:179,184`；`cpp:776-799` | 25（远端，int 截断） |

**等价写法**（无环内提前量时，稳态 dx≈0）：`e_pred ≈ \|v̂·τ\| = 140 px/s × 0.55~0.95 s = **77~133 px**`（0.875 m）——比配置的 `T_set=0.27` 假设（37.8 px）大 2~3.5 倍。

### 3.3 为什么这条式子能替代旧判据

| 场景 | 旧判据 `\|dx+v·T_set\|≤box` | 新判据 `e_pred≤κbox` |
|---|---|---|
| lead 不进环（今天） | 25/0.27 ⇒ 速度门 92.6 px/s | 与 τ 挂钩，**诚实地**判"打不中" |
| lead 进环（T2 之后） | dx→−L ⇒ **恒 ≈0，恒真**，失去意义 | 仍盯 `\|v(τ−T_set)\|+b_l`，**能发现 T_set 标错** |
| 折返 | 不区分 | 显式盲窗（§3.6），不预测过折返点 |

> 即：**判据不是 T2 的替代品，是 T2 的安全带**。T2 把 lead 放进环后，旧判据会退化成恒真；没有 e_pred，就会在 T_set 标错 0.3 s 时继续开火，每发偏 42 px。

### 3.4 阈值建议（与 25 px 框、靶面、机械精度、保持帧数的关系）

**几何换算**（`px_per_m_rail=140 px/m @0.875 m`，`03` §3；S 随距离反比 ⇒ `S(d)=140×0.875/d`）：

| 站距 d | S (px/m) | 靶面半径 0.175 m 的像素半径 | 现役框 | 建议框 | 1 m/s 超前量（τ=0.267 / 0.60） |
|---|---|---|---|---|---|
| 0.875 m | 140 | **24.5 px** | 25 px | 24.5（≈现值） | 37.3 / 84 px |
| 1.41 m | 86.9 | **15.2 px** | 25 px（**偏大 65%**） | 15.2 | 23.2 / 52 px |

- 25 px 框在 0.875 m 处**恰好等于靶面半径**（24.5 px）——这不是巧合〔推〕：若 `box_w` 就是靶面宽，则远端点标定 `box_w_far=30 px` 对应约 1.4 m（30 px/0.35 m = 85.7 px/m ≈ 86.9）。
- **由此推出**：靶面半径（px）≈ `box_w/2`（`box_w` 是靶面宽），与距离无关。所以半径正确的框 = `box_w/2`，而现役 `fire_box_px()` 在 `box_w ≤ 30 px` 时一律返回 25 px（`aim.py:182-183`、`cpp:788-792`），**在 D11 上把框放大了 65%**。
- **阈值建议（分两档，先保守后收紧）**：
  - 开火：`e_pred ≤ 0.8 × box_phys`（`box_phys=box_w/2`）：0.875 m ⇒ 19.6 px；1.41 m ⇒ 12.2 px。
  - 保持：`e_pred ≤ 1.0 × box_phys`（迟滞，避免抖动关闸）。
  - 质量：`σ_e ≤ 0.2 × box_phys`（§3.5），否则"能开但没把握"，宁可不打。
- **与 5 帧保持的相容性**（必须验算）：1 m/s 下框内停留 = `2·box_phys/140` = 0.35 s（0.875 m）/ 0.35 s（1.41 m，因为 S 也按比例缩小）；0.8 档更窄 = 0.28 s ≈ 8.4 帧 > 5 帧 ✓。若把 κ 收到 0.5 ⇒ 0.175 s = 5.3 帧，**贴着下限**，不建议再低。
- **折返门**：`now − last_flip_seen < τ` ⇒ 禁火。理由见 §3.6：实测折返比物理折返晚 τ 才被看到，这 τ 内 `v̂` 方向是错的，`e_pred` 误差可达 `2\|v\|τ = 154 px`。

### 3.5 不确定度预算（决定 τ 要标多准）

```
σ_e = sqrt( σ_x² + (τ·σ_v)² + (v·σ_τ)² + σ_bl² )
```

| 项 | 量级 | 依据 |
|---|---|---|
| `σ_x` 检测抖动 | 1~2 px | 未测；用静止靶的 dx 标准差直接量 |
| `τ·σ_v` 速度噪声 | ≈0.3 px/s × 0.6 s = **0.2 px** | `aim.py:207`（12 帧窗口 ±0.3 px/s） |
| `v·σ_τ` **主项** | 140 px/s × 0.05 s = **7 px** | τ 的标定精度（本卡 §2.3 要求 ±36 ms） |
| `σ_bl` 激光偏置 | **未知**，静态标定前按 ≥5 px 记 | `robot.yaml:212-213` 全 0 |

⇒ **τ 必须准到 ±36 ms 才能把 `v·σ_τ` 压到 5 px（0.2×24.5）**；§2.3 的 n=20 阶跃（CI ±10 ms）够用。这也是"为什么必须先做 τ 标定、再谈判据"。

### 3.6 伪代码（可直接搬进 `aim.py::_evaluate` / C++ 第五步）

```python
# 每拍（aim.py 50 Hz / C++ 100 Hz）
x   = dx_filt                      # px，滞后 τ
v   = est.v                         # px/s
tau = TAU_MEAS                      # s，§2.3 实测；k 变了要重标
box = box_w / 2.0                   # px，物理半径（距离无关）；兜底 min(25, box_w/2)
L   = g_loop * v * T_SET             # px，真正进环的提前量（今天 g_loop=0 ⇒ L=0）

# 1) 估计器可用性
if not est.init or est.stale:        return False, "estimator_stale"
if not est.armed:                    return False, "estimator_warmup"

# 2) 折返盲窗：观测到的折返比物理折返晚 τ
if est.last_flip_seen is not None and (now - est.last_flip_seen) < tau:
    return False, "turnaround_blind"          # 新增原因码

# 3) 控制环已稳住（旧判据保留为"必要性"而非"决定性"）
if abs(x + L) > box:                 return False, "control_error"

# 4) 预测命中误差
e_pred = abs(x + v * tau - L - b_laser)       # px
sigma  = sqrt(sig_x**2 + (tau*sig_v)**2 + (v*sig_tau)**2 + sig_laser**2)
if e_pred > 0.8 * box:               return False, "predicted_miss"
if sigma  > 0.2 * box:               return False, "prediction_uncertain"

# 5) 保持（迟滞在 _set_fire_ready 里做）
hold_frames += 1
return (hold_frames >= 3), "ok"       # 3 帧=0.1 s 足够；5 帧在 1 m/s 下吃掉半个窗
```

C++ 侧对应改法（只列改动点，不改）：第五步 `aim_err_x` 换成 `\|dx_filt_ + vx*30.0*tau − L\|`——注意 C++ 的 `vx` 是 **px/帧**（`cpp:126`），要先 ×30 换成 px/s；且只有 lead 进环（`cpp:213-225`）后 `L` 才非零。

### 3.7 与 T2 / T3 的接口（三条，T5 裁决用）

1. **T2（lead 进环）**：进环后 `L = g·v·T_set`，e_pred 的残差 = `\|v(τ − T_set) + b_l\|`。
   ⇒ T2 的 `T_set` **必须用本卡 §2.3 的 τ**，不能再用 0.27；且 `aim.max_lead_factor=0.45`（⇒ 44.1 px）**必须同时抬高到 ≥1.0**（0.55 s ⇒ 需要 77 px = 0.79；0.95 s ⇒ 1.36），否则提前量被夹死。
2. **T3（1.41 m 站距）**：D11 的「23 px < 25 px」只在"框固定 25 px"时成立；物理半径在 1.41 m 只有 15.2 px。建议 T3 现场读一帧 `/offset_center[3]`（box_w），若 ≈30 px ⇒ 框应按 `box_w/2=15 px` 归一化，D11 的结论要改成「判据会开、命中靠 lead 进环」。
3. **T5 排序**：判据替换与 `thread_num` 都**不能单独**让 1 m/s 命中；它们的作用是（a）让 τ 可测、（b）让残差可判、（c）扩大开火窗。真正的使能项是 T2。

---

## 4. 给 T5 的排序卡

| 序 | 动作 | 前置 | 工时 | 收益（量化） | 风险/回滚 | 验收 |
|---|---|---|---|---|---|---|
| P0-a | **T2：lead 进控制环**（约 4 行，冻结区登记） | 无 | 0.5 d | 把 e_pred 残差从 `v·τ`（77~133 px）压到 `v·\|τ−T_set\|+b_l`；τ/T_set 一致时 ≈0 | 中（改 C++ 冻结区）；git revert + 重编 5 min | 1 m/s 下 `predicted_miss` 不再恒假；遥测 `pred/box` |
| P0-b | **τ 标定**（本卡 §2.3，只读记录器） | 无 | 0.5 h | 给 T2 一个正确的 `T_set`（±36 ms 才能把 σ 压到 5 px） | 低（磁盘零改动） | 阶跃 n=20，CI ≤ ±15 ms；四段分解表 |
| P1-a | **thread_num 8→3**（F1 参数覆盖） | 无 | 0.5 h | τ −0.167 s；预测有效窗 21%→44%；armed 窗 0%→20%；超前量 −23 px | 低（重启即回） | §2.7 五条门限 |
| P1-b | **e_pred 判据 + 折返盲窗 + box=box_w/2** | P0-b（要 τ） | 0.5 d | 判据不再"误开"；T2 改完后仍有闸；D11 框不再偏大 65% | 中（Python 侧为主，C++ 一处） | 1 m/s 全程 `out_of_box` 与 `predicted_miss` 分开计数；无 `turnaround_blind` 误伤 |
| P2 | F3：`get()` 取最新 / `thread_num` 热参数 | P1-a 证明 FIFO 为主因 | 0.5 d | 滞后 ≈ `max(33, T_infer)`，与 k 解耦 | 高（冻结区重编） | k=8 下 `T_pipe` 降到 ≈`T_infer` |

**不建议**：① 只改 `fire_dz_far_px` 抬框（掩盖，`03` §5 ⛔ 已裁决）；② 只改 `lead_time_s` 而不进环（判据会恒假）；③ 先做 P2 再测 P1（顺序反了，可能白改）。

---

## 5. 证据索引

| 文件 | 行 | 内容 |
|---|---|---|
| `dzrobot_v2/src/rknn_pt/include/rknnPool.hpp` | 91-111 | `put()` 压 future、`get()` 取队首并 pop（FIFO 本体） |
| `dzrobot_v2/src/rknn_pt/include/ThreadPool.hpp` | 58-88, 97-132 | 任务队列 + 懒建线程（饱和模型依据） |
| `dzrobot_v2/src/rknn_pt/src/det_node.cc` | 37-47 | `thread_num` 声明/读取（代码默认 4，无回调） |
| 同上 | 67-74 | 定时器周期 `max(33, 1000/max_fps)` |
| 同上 | 76-79 | 启动日志打印线程数（现场自证） |
| 同上 | 228-238 | 每拍 put；`frames_>=thread_num_` 才 get |
| 同上 | 262-270 | `draw` 的 imshow 开销 |
| `dzrobot_v2/src/rknn_pt/package.xml` / `CMakeLists.txt` | 3 / 2,18 | 包名/可执行名 = `det_node` |
| `dzrobot_v2/src/dzrknn_dataprocess/src/dzrknn_dataprocess.cpp` | 126-129 | `vx = dx_filt_ − dx_prev_filt_`（px/帧，无时间戳） |
| 同上 | 213-225 | 控制环只用滤波误差+速度前馈+陀螺前馈（lead 不在环） |
| 同上 | 261-302 | 开火七步：box_w→fire_dz、aim_stable、两键、`lead_applied` |
| 同上 | 279-281 | 1.5 px/帧「画面稳定」判据 |
| 同上 | 290-291 | 两键开火时**不叠加** aim_stable |
| 同上 | 360-391 | `fire_hold_frames` 连发计数 |
| 同上 | 776-799 | `fireDeadzonePx` 线性插值 + int 截断 |
| 同上 | 1169-1177 | `/aim/lead_x` 订阅与 ±400 px 守卫 |
| 同上 | 1265-1266 | `offset_center` / `camemo_feedback` 订阅（BEST_EFFORT, depth 1） |
| `dzrobot_v2/src/dzbrain/dzbrain/tasks/aim.py` | 43-45 | 缺口 ①②③ 的处置说明 |
| 同上 | 163-189 | `fire_box_px()` 线性插值 + 退化处理 |
| 同上 | 196-249 | `RailEstimator`：时间戳、端点差分 0.4 s、跳变门、warmup 5 帧 |
| 同上 | 528 | `aim.lead_time_s` 读取 |
| 同上 | 577, 591-592 | `lead_eps`、`_max_lead_px = 0.45×rail_span×px_per_m` |
| 同上 | 883-892 | `_lead_px = v × lead_time_s` + 限幅 |
| 同上 | 945-984 | 判据：`pred=dx+lead`、按策略比框、估计器门、冷却 |
| 同上 | 1192-1194 | 遥测 `v_px_s` / `pred_px`（实验直接读这两个数） |
| `dzrobot_v2/src/dzbrain/dzbrain/io/contract.py` | 214-249 | `OffsetObservation`（dx/box_w/ts） |
| `dzrobot_v2/src/dzbrain/dzbrain/io/ros_io.py` | 250, 329-330 | `ts=time.time()` 打点；QoS 取 topic 契约 |
| `dzrobot_v2/config/robot.yaml` | 123 / 132 | `ema_alpha=0.45` / `predict_gain=0.5`（帧） |
| 同上 | 177-192 | 开火框 25/26、`box_w_far/near=30/120`、hold=5、stable=1.5 |
| 同上 | 202-207 | `fire_only_blue`、`max_shots=10` |
| 同上 | 212-213 | `laser_offset_x/y = 0.0`（未标定） |
| 同上 | 227-228 | `use_external_fire_gate=true`、`lead_apply_gain=0.5` |
| 同上 | 305-309 | `thread_num=8`、`max_fps=30`、`draw=true` |
| 同上 | 831-840 | `lead_time_s=0.27`、`fire_policy=moving_lead`、`rail_span_m=0.70`、`target_speed_mps=0.04`(残留)、`px_per_m_rail=140` |
| `docs/20_资料索引库/视觉与云台/02_视觉模型与检测.md` | 24-29 | 0.26 s 机制 + 队列深度（档案口径） |
| `docs/20_资料索引库/视觉与云台/03_移动靶缺口与改进方向.md` | 34-37, 50-74 | 缺口 #13/#4、1 m/s 换算表、判据恒假 |
| `docs/20_资料索引库/视觉与云台/01_云台瞄准与开火链路.md` | 63-95 | 七条 AND、两套许可口径、lead 不进环的 P0 |

---

## 6. 未验证 / 不要当结论

| 项 | 状态 | 怎么证 |
|---|---|---|
| `T_infer` 到底多少 | **未** | E1（k=1）：`T_pipe(1)=max(33,T_infer)` |
| τ 的 0.24~0.64 s 伺服段 | **未**（档案粗口径） | §2.3 方法 A 的 ①→③ 分解 |
| 1 m/s 时 `armed` 窗 = 0% | **推**（依赖 τ 与 rail 0.70 m） | 仿真里把 τ 当参数扫；或现场看 `estimator_warmup` 占比 |
| `box_w` 在 1.41 m ≈ 30 px | **未**（由标定端点反推） | 现场读 `/offset_center[3]` |
| `laser_offset` 实际偏多少 | **未**（配置 0.0） | 固定靶打一发，量落点与画面中心 |
| 检测抖动 σ_x | **未** | 静止靶 dx 标准差（30 s） |
| 0.26 s 是不是 `T_infer` 的巧合 | **未** | E0 vs E1 的对比直接判 |

> 本卡所有"收益"数字都是**离线推导**，没有实车数据；明日实验的第一件事应是 E0/E1，而不是直接改配置。
