# -*- coding: utf-8 -*-
import json,re,statistics as st
from collections import Counter
from pathlib import Path
W=Path(r'D:\User\Desktop\比赛存档\v1')
CAM=W/'docs/_work/TRACK-DAY-20261022/evidence/cam'
ev=[json.loads(l) for l in open(CAM/'aim_rec_D.jsonl',encoding='utf-8') if l.strip()]
T0=ev[0]['t']; T1=max(e['t'] for e in ev)
print("D t0..t1",T0,T1,"dur",T1-T0)
# main gate window
gates=[(e['t'],int(e['v'])) for e in ev if e['k']=='/aim/fire_gate']
ints=[]; s=None
for t,v in gates:
    if v==1 and s is None: s=t
    elif v==0 and s is not None: ints.append((s,t)); s=None
if s is not None: ints.append((s,T1))
main=max(ints,key=lambda x:x[1]-x[0])
print("gate intervals rel:",[(round(a-T0,2),round(b-T0,2),round(b-a,2)) for a,b in ints],"main",round(main[0]-T0,2),round(main[1]-T0,2))
off=[e for e in ev if e['k']=='/offset_center']
lead=[(e['t'],float(e['v'])) for e in ev if e['k']=='/aim/lead_x']
sts=[(e['t'],int(e['v'])) for e in ev if e['k']=='/aim/status']
def prev(seq,t):
    lo,hi=0,len(seq)-1; best=None
    while lo<=hi:
        m=(lo+hi)//2
        if seq[m][0]<=t: best=seq[m]; lo=m+1
        else: hi=m-1
    return best
def box(w,far=18.0,near=26.0,bwf=30.0,bwn=120.0):
    if w<=0: return far
    tt=max(0.0,min(1.0,(w-bwf)/(bwn-bwf))); return far+tt*(near-far)
def classify(a,b,far,near):
    rows=[]
    for e in off:
        t=e['t']
        if t<a or t>b: continue
        v=e['v']; cls=int(v[2]); w=float(v[3]); h=float(v[4]); dx=float(v[0]); dy=float(v[1])
        lp=prev(lead,t); lv=lp[1] if lp and t-lp[0]<=0.2 else 0.0
        sp=prev(sts,t); sv=sp[1] if sp and t-sp[0]<=0.6 else -1
        bpx=box(w,far,near)
        if cls==0 or w<=0: c='A'
        elif abs(dx+lv)>bpx or abs(dy)>bpx: c='C'
        elif cls==2: c='B'
        elif not (0.6<=w/h<=1.6): c='B'
        else: c='D'
        rows.append((t,c,dx,dy,w,h,lv,sv,dx+lv,bpx))
    n=len(rows); cc=Counter(r[1] for r in rows)
    print(f"\n=== FIRE window {a-T0:.2f}..{b-T0:.2f} ({b-a:.1f}s) box {far}/{near}: n={n} ===")
    for c in 'ABCD': print(f"  {c}: {cc.get(c,0)} ({100*cc.get(c,0)/max(n,1):.1f}%)")
    def runs_of(c):
        runs=[]; cur=None
        for r in rows:
            if r[1]==c:
                if cur is None: cur=[r[0],r[0],0]
                cur[1]=r[0]; cur[2]+=1
            elif cur: runs.append(cur); cur=None
        if cur: runs.append(cur)
        return runs
    for c in 'ABCD':
        rs=runs_of(c)
        if rs:
            best=max(rs,key=lambda x:x[1]-x[0])
            print(f"  longest {c}: {best[1]-best[0]:.2f}s n={best[2]} {best[0]-T0:.2f}..{best[1]-T0:.2f}s")
    cdx=[abs(r[2]) for r in rows if r[1]=='C']
    if cdx: print(f"  C: |dx| med={st.median(cdx):.0f} <=42 share={100*sum(1 for x in cdx if x<=42)/len(cdx):.0f}%")
    return rows
classify(main[0],main[1],18,26)
classify(main[0],main[1],42,42)
classify(ints[0][0],ints[-1][1],18,26)

# D FIRE reason lines in 7_path: L2670..L2820
p=CAM/'7_path_BCD_1938.log'; lines=p.read_text(encoding='utf-8',errors='replace').splitlines()
seg=lines[2669:2820]  # L2670..L2820
rc=Counter()
for l in seg:
    m=re.search(r'不开火：(.+)$',l)
    if m:
        r=re.split(r'\[T\]|遥测|检查③|桥洞',m.group(1))[0].strip(); rc[r]+=1
print("\n=== 7_path D FIRE L2670-L2820 reasons:",dict(rc.most_common()),"total",sum(rc.values()))
# same for L2532..? no; find line of '→ FIRE' in each stop; the last is 2670
# gimbal lost lines after line 2500
g=(CAM/'5_gimbal_BCD_1959.log').read_text(encoding='utf-8',errors='replace').splitlines()
after=g[2500:]
print("gimbal lines after 2500:",len(after),"lost:",sum(1 for l in after if '目标脱离视野' in l),"gate:",sum(1 for l in after if '收到【开火放行】' in l),"laser:",sum(1 for l in after if 'pub_LaserShot_Command' in l))
