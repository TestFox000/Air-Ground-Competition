# -*- coding: utf-8 -*-
import json,re
from collections import Counter
from pathlib import Path
W=Path(r'D:\User\Desktop\比赛存档\v1')
CAM=W/'docs/_work/TRACK-DAY-20261022/evidence/cam'
D=json.load(open(CAM/'aim_rec_D.jsonl',encoding='utf-8')) if False else None
# load D events
ev=[]
for line in open(CAM/'aim_rec_D.jsonl',encoding='utf-8'):
    try: ev.append(json.loads(line))
    except: pass
print("D events",len(ev),"t0",ev[0]['t'] if ev else None,"t1",max(e['t'] for e in ev))
ks=Counter(e['k'] for e in ev); print("keys",dict(ks))
sts=[(e['t'],int(e['v'])) for e in ev if e['k']=='/aim/status']
print("status first/last",sts[:5],sts[-5:],"n",len(sts))
# status runs
runs=[]; 
for t,v in sts:
    if not runs or runs[-1][2]!=v: runs.append([t,t,v])
    else: runs[-1][1]=t
print("status runs (t0,t1,v):")
for r in runs[:30]: print("  ",r)

# 7_path stop lines
p=CAM/'7_path_BCD_1938.log'; lines=p.read_text(encoding='utf-8',errors='replace').splitlines()
print("\n7_path lines",len(lines))
for i,l in enumerate(lines,1):
    if any(k in l for k in ('停站点','硬死线','→ FIRE','云台 TRACK 且有目标','任务结束','路线载入','到点 ')):
        print(f"  L{i}: {l[:240]}")

# gimbal gate lines with nearest epoch
g=CAM/'5_gimbal_BCD_1959.log'; glines=g.read_text(encoding='utf-8',errors='replace').splitlines()
print("\ngimbal lines",len(glines))
last_ep=None; gates=[]; losts=[]
for i,l in enumerate(glines,1):
    m=re.search(r'\[INFO\] \[(\d+\.\d+)\]',l)
    if m: last_ep=float(m.group(1))
    if '收到【开火放行】' in l: gates.append((i,last_ep,l.strip()[:160]))
    if '目标脱离视野' in l: losts.append((i,last_ep,l.strip()[:160]))
print("gate lines:")
for x in gates: print("  ",x)
print("lost lines count",len(losts),"first",losts[:3],"last",losts[-3:])
