# -*- coding: utf-8 -*-
import json, statistics as st
from collections import Counter
from pathlib import Path
W=Path(r'D:\User\Desktop\比赛存档\v1'); CAM=W/'docs/_work/TRACK-DAY-20261022/evidence/cam'
ev=[json.loads(l) for l in open(CAM/'aim_rec_D.jsonl',encoding='utf-8') if l.strip()]
T0=ev[0]['t']
gates=[(e['t'],int(e['v'])) for e in ev if e['k']=='/aim/fire_gate']
ints=[]; s=None
for t,v in gates:
    if v==1 and s is None: s=t
    elif v==0 and s is not None: ints.append((s,t)); s=None
if s is not None: ints.append((s,max(e['t'] for e in ev)))
a,b=max(ints,key=lambda x:x[1]-x[0])
print(f"FIRE {a-T0:.2f}..{b-T0:.2f}")

# 1 status timeline
sts=[(e['t'],int(e['v'])) for e in ev if e['k']=='/aim/status']
print("\n[1] status events in FIRE:")
sel=[(t,v) for t,v in sts if a<=t<=b]
print("  n=",len(sel),"values",dict(Counter(v for t,v in sel)))
print("  first/last",[(round(t-T0,2),v) for t,v in sel[:3]],[(round(t-T0,2),v) for t,v in sel[-3:]])
# all transitions
print("  all transitions:")
for i in range(1,len(sts)):
    if sts[i][1]!=sts[i-1][1]:
        print("   ",f"{sts[i][0]-T0:7.2f}s",sts[i-1][1],"->",sts[i][1])
# intervals
iv=[sts[i][0]-sts[i-1][0] for i in range(1,len(sts))]
print("  sample interval med/min/max",round(st.median(iv),2),round(min(iv),2),round(max(iv),2))

# 2 edge clipping
off=[e for e in ev if e['k']=='/offset_center' and a<=e['t']<=b]
lead=[(e['t'],float(e['v'])) for e in ev if e['k']=='/aim/lead_x']
def prev(seq,t):
    lo,hi=0,len(seq)-1; best=None
    while lo<=hi:
        m=(lo+hi)//2
        if seq[m][0]<=t: best=seq[m]; lo=m+1
        else: hi=m-1
    return best
def box(w,far=18.0,near=26.0):
    tt=max(0.0,min(1.0,(w-30.0)/90.0)); return far+tt*(near-far)
IMW,IMH=640,480
def clip(v):
    dx,dy,cls,w,h=v[0],v[1],int(v[2]),v[3],v[4]
    if cls==0 or w<=0: return None
    cx,cy=IMW/2+dx,IMH/2+dy
    l,r,t,bt=cx-w/2,cx+w/2,cy-h/2,cy+h/2
    edges=[]
    if l<0: edges.append('L')
    if r>IMW: edges.append('R')
    if t<0: edges.append('T')
    if bt>IMH: edges.append('B')
    margin=min(l,IMW-r,t,IMH-bt)
    return (edges,margin,dx,dy,w,h)
C=[e for e in off if int(e['v'][2]) in (1,2) and e['v'][3]>0 and abs(e['v'][0]+((prev(lead,e['t'])[1] if prev(lead,e['t']) and e['t']-prev(lead,e['t'])[0]<=0.2 else 0)))>box(e['v'][3])]
cc=[clip(e['v']) for e in C]
ec=Counter(tuple(x[0]) for x in cc if x)
print("\n[2] C frames",len(C),"clipped any",sum(1 for x in cc if x and x[0]),dict(ec))
print("  margin med/min",round(st.median([x[1] for x in cc if x]),1),round(min(x[1] for x in cc if x),1))
# last valid before each cls=0 run
runs=[]; cur=None
for e in off:
    if int(e['v'][2])==0:
        if cur is None: cur=[e['t'],e['t'],0]
        cur[1]=e['t']; cur[2]+=1
    elif cur: runs.append(cur); cur=None
if cur: runs.append(cur)
lasts=[]
for r in runs:
    i=next((i for i,e in enumerate(off) if e['t']>=r[0]),None)
    if i and i>0:
        v=off[i-1]['v']; cl=clip(v)
        if cl: lasts.append(cl)
print("  cls=0 runs",len(runs),"last-valid clipped",sum(1 for x in lasts if x[0]),"of",len(lasts),dict(Counter(tuple(x[0]) for x in lasts if x[0])))
print("  last-valid margin med",round(st.median([x[1] for x in lasts]),1) if lasts else None)

# 3 dx sign runs
vals=[]
for e in off:
    v=e['v']
    if int(v[2]) in (1,2) and v[3]>0: vals.append((e['t'],v[0]))
signs=[(t,x) for t,x in vals if x!=0]
sr=[]; cur=None
for t,x in signs:
    s=1 if x>0 else -1
    if cur is None or cur[2]!=s:
        if cur: sr.append(cur)
        cur=[t,t,s,1]
    else: cur[1]=t; cur[3]+=1
if cur: sr.append(cur)
print("\n[3] dx sign runs:",len(sr),"durations:",[round(x[1]-x[0],2) for x in sr])
print("  median run",round(st.median([x[1]-x[0] for x in sr]),2),"max",round(max(x[1]-x[0] for x in sr),2))
print("  mean dx",round(sum(x for t,x in vals)/len(vals),1),"median",round(st.median([x for t,x in vals]),1))
print("  cum dx end",round(sum(x for t,x in vals),0),"over",len(vals),"frames")

# 4 replay variants
def judge(boxval,holdK):
    sat=[]; last=None
    for e in off:
        t=e['t']; v=e['v']; cls=int(v[2]); w=v[3]; h=v[4]; dx=v[0]; dy=v[1]
        lp=prev(lead,t); lv=lp[1] if lp and t-lp[0]<=0.2 else 0.0
        ok=False
        if cls==1 and w>0 and 0.6<=w/h<=1.6:
            ok=abs(dx+lv)<=boxval and abs(dy)<=boxval
            last=(ok,t,dx,dy,w,h,lv) if ok else (ok,t,dx,dy,w,h,lv)
        if not ok and holdK>0 and last and (t-last[1])<=holdK/30.0 and abs(last[2]+last[6])<=boxval and abs(last[3])<=boxval:
            ok=True
        sat.append((t,ok))
    # runs and events
    runs=[]; cur=None
    for t,ok in sat:
        if ok:
            if cur is None: cur=[t,t,0]
            cur[1]=t; cur[2]+=1
        elif cur: runs.append(cur); cur=None
    if cur: runs.append(cur)
    events=0; last_ev=-1e9
    for r in runs:
        if r[2]>=5 and r[0]-last_ev>=0.8:
            events+=1; last_ev=r[0]
    n=sum(1 for t,ok in sat if ok)
    longest=max((r[1]-r[0] for r in runs),default=0)
    return n,len(sat),longest,events
print("\n[4] variants (hold K frames; events=run>=5frames + cooldown0.8s):")
for label,boxval,holdK in [('V0 actual',None,0),('V1 box26',26,0),('V1 box36',36,0),('V1 box42',42,0),('V2 box18/26 K5',23,5),('V2 box18/26 K10',23,10),('V2 box18/26 K15',23,15),('V3 box36 K10',36,10),('V3 box42 K10',42,10)]:
    if boxval is None:
        n=sum(1 for e in ev if e['k']=='/aim/fire_ready' and a<=e['t']<=b and int(e['v'])==1)
        print(f"  {label}: ready=1 frames={n}/876 -> events=0")
    else:
        n,tot,longest,events=judge(boxval,holdK)
        print(f"  {label}: sat={n}/{tot} ({100*n/tot:.1f}%) longest={longest:.2f}s events={events}")
# topic silence check
ot=[e['t'] for e in ev if e['k']=='/offset_center']
gaps=[ot[i]-ot[i-1] for i in range(1,len(ot))]
print("\n[5] /offset_center: n",len(ot),"max gap",round(max(gaps),3),"s; cls=0 frames",sum(1 for e in off if int(e['v'][2])==0),"of",len(off),"-> topic is NOT silent")
