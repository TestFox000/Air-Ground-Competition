# -*- coding: utf-8 -*-
import json,re,statistics as st
from collections import Counter
from pathlib import Path
W=Path(r'D:\User\Desktop\比赛存档\v1'); CAM=W/'docs/_work/TRACK-DAY-20261022/evidence/cam'
# reason counts by line ranges
lines=(CAM/'7_path_BCD_1938.log').read_text(encoding='utf-8',errors='replace').splitlines()
def rc(a,b):
    c=Counter()
    for l in lines[a-1:b]:
        m=re.search(r'不开火：(.+)$',l)
        if m: c[re.split(r'\[T\]|遥测|检查③|桥洞',m.group(1))[0].strip()]+=1
    return c
print("D segment L2647-L2824:",dict(rc(2647,2824).most_common()))
print("pre-FIRE L2647-L2669:",dict(rc(2647,2669).most_common()))
print("FIRE L2670-L2820:",dict(rc(2670,2820).most_common()))
print("post L2821-L2824:",dict(rc(2821,2824).most_common()))
# D jsonl stats
ev=[json.loads(l) for l in open(CAM/'aim_rec_D.jsonl',encoding='utf-8') if l.strip()]
T0=ev[0]['t']
gates=[(e['t'],int(e['v'])) for e in ev if e['k']=='/aim/fire_gate']
ints=[]; s=None
for t,v in gates:
    if v==1 and s is None: s=t
    elif v==0 and s is not None: ints.append((s,t)); s=None
if s is not None: ints.append((s,max(e['t'] for e in ev)))
a,b=max(ints,key=lambda x:x[1]-x[0])
off=[e for e in ev if e['k']=='/offset_center' and a<=e['t']<=b]
lead=[(e['t'],float(e['v'])) for e in ev if e['k']=='/aim/lead_x' and a<=e['t']<=b]
ready=[int(e['v']) for e in ev if e['k']=='/aim/fire_ready' and a<=e['t']<=b]
sts=[int(e['v']) for e in ev if e['k']=='/aim/status' and a<=e['t']<=b]
las=[int(e['v']) for e in ev if e['k']=='/LaserShot_Command' and a<=e['t']<=b]
cl=[int(e['v'][2]) for e in off]
valid=[e for e in off if int(e['v'][2]) in (1,2) and e['v'][3]>0]
dx=[e['v'][0] for e in valid]; w=[e['v'][3] for e in valid]
lz=[x for t,x in lead if abs(x)>1e-9]
print(f"\nFIRE {a-T0:.2f}-{b-T0:.2f}s frames={len(off)} cls={dict(Counter(cl))} valid={len(valid)}")
print(f"  lead n={len(lead)} nz={len(lz)} nz_med={st.median(lz) if lz else 0:.1f} max={max(lz) if lz else 0:.1f}")
print(f"  ready {dict(Counter(ready))} status {dict(Counter(sts))} laser {dict(Counter(las))}")
print(f"  valid dx med={st.median(dx):.0f} mean={sum(dx)/len(dx):.1f} pos={sum(1 for x in dx if x>0)} neg={sum(1 for x in dx if x<0)} |dx| p10/p50/p90={sorted(abs(x) for x in dx)[int(.1*(len(dx)-1))]:.0f}/{st.median([abs(x) for x in dx]):.0f}/{sorted(abs(x) for x in dx)[int(.9*(len(dx)-1))]:.0f}")
print(f"  w med={st.median(w):.0f} px -> px/m at 0.35m = {st.median(w)/0.35:.0f}")
print(f"  px/m from lead: {st.median(lz)/0.27/0.3:.0f}" if lz else "  no lead")
# cls=0 runs within FIRE
runs=[]; cur=None
for e in off:
    if int(e['v'][2])==0:
        if cur is None: cur=[e['t'],e['t'],0]
        cur[1]=e['t']; cur[2]+=1
    elif cur: runs.append(cur); cur=None
if cur: runs.append(cur)
print(f"  cls=0 runs in FIRE: n={len(runs)} >=0.5s={sum(1 for r in runs if r[1]-r[0]>=0.5)} >=2.44s={sum(1 for r in runs if r[1]-r[0]>=2.44)} max={max((r[1]-r[0] for r in runs),default=0):.2f}s")
# 43 deg counterfactual
import math
print(f"  43deg lateral at 1.41m = {1.41*math.tan(math.radians(43)):.2f} m; at 296px/m = {1.41*math.tan(math.radians(43))*296:.0f} px; frame half=320")
