# -*- coding: utf-8 -*-
import json, statistics as st, re
from pathlib import Path
W = Path(r'D:\User\Desktop\比赛存档\v1')
CAM = W/'docs/_work/TRACK-DAY-20261022/evidence/cam'
D19 = W/'docs/_work/TRACK-DAY-20261022/evidence/d11_1900'
for name in ('aim_rec_A.jsonl','aim_rec_B.jsonl'):
    p = CAM/name
    ks={}; t0=None; t1=None
    for line in open(p, encoding='utf-8'):
        try: o=json.loads(line)
        except Exception: continue
        k=o.get('k'); v=o.get('v'); t=o.get('t')
        if t is not None:
            t0 = t if t0 is None else min(t0,t); t1 = t if t1 is None else max(t1,t)
        ks.setdefault(k,[]).append(v)
    print(f"=== {name}: {sum(len(v) for v in ks.values())} events, t {t0:.1f}..{t1:.1f} ({(t1-t0):.1f}s) ===")
    for k,v in sorted(ks.items(), key=lambda x:-len(x[1])):
        print(f"  {k:28s} n={len(v):5d}", end='')
        if k in ('/aim/fire_ready','/aim/fire_gate','/aim/status','/LaserShot_Command','/shoot_count'):
            from collections import Counter
            print(' vals', dict(Counter(str(x) for x in v).most_common(5)), end='')
        elif k=='/aim/lead_x':
            nums=[float(x) for x in v if isinstance(x,(int,float))]
            if nums: print(f' med={st.median(nums):.1f} min={min(nums):.1f} max={max(nums):.1f} nz={sum(1 for x in nums if abs(x)>1e-9)}', end='')
        elif k=='/offset_center':
            lens=[len(x) for x in v if isinstance(x,list)]
            print(f' len={dict(Counter(lens))}', end='')
        print()
    # fire_gate=1 intervals
    fg=[(o['t'],o['v']) for line in open(p,encoding='utf-8') for o in [json.loads(line)] if o.get('k')=='/aim/fire_gate']
    if fg:
        on=[t for t,v in fg if v==1]
        print('  fire_gate=1 events:', len(on), 'first/last', (on[0] if on else None, on[-1] if on else None))
