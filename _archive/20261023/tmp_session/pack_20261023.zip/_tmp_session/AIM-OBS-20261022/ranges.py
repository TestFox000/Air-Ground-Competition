# -*- coding: utf-8 -*-
import re
from collections import Counter
from pathlib import Path
W=Path(r'D:\User\Desktop\比赛存档\v1')
lines=(W/'docs/_work/TRACK-DAY-20261022/evidence/cam/7_path_BCD_1938.log').read_text(encoding='utf-8',errors='replace').splitlines()
def rc(a,b):
    c=Counter()
    for l in lines[a-1:b]:
        m=re.search(r'不开火：(.+)$',l)
        if m: c[re.split(r'\[T\]|遥测|检查③|桥洞',m.group(1))[0].strip()]+=1
    return dict(c.most_common())
for a,b in [(1,2880),(2506,2824),(2616,2824),(2584,2824),(2539,2824),(2647,2824),(2670,2820)]:
    print(f"L{a}-L{b}:",rc(a,b),"total",sum(rc(a,b).values()))
# route load lines
for i,l in enumerate(lines,1):
    if '路线载入' in l or '停站点 1 个' in l or '→ FIRE' in l or '硬死线 30' in l:
        print(f"  L{i}: {l[:160]}")
