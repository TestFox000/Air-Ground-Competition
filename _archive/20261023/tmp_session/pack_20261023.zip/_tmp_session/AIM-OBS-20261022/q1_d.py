# -*- coding: utf-8 -*-
import json, statistics as st
from collections import Counter
from pathlib import Path
W=Path(r'D:\User\Desktop\比赛存档\v1')
CAM=W/'docs/_work/TRACK-DAY-20261022/evidence/cam'
ev=[json.loads(l) for l in open(CAM/'aim_rec_D.jsonl',encoding='utf-8') if l.strip()]
T0=ev[0]['t']
def fmt(t): return f"{t-T0:6.2f}s"

gates=[(e['t'],int(e['v'])) for e in ev if e['k']=='/aim/fire_gate']
print("fire_gate events:")
for t,v in gates: print("  ",fmt(t),v)
# gate=1 intervals
ints=[]; s=None
for t,v in gates:
    if v==1 and s is None: s=t
    elif v==0 and s is not None: ints.append((s,t)); s=None
if s is not None: ints.append((s,max(e['t'] for e in ev)))
print("gate=1 intervals:",[(round(a-T0,2),round(b-T0,2)) for a,b in ints])

off=[e for e in ev if e['k']=='/offset_center']
lead=[(e['t'],float(e['v'])) for e in ev if e['k']=='/aim/lead_x']
sts=[(e['t'],int(e['v'])) for e in ev if e['k']=='/aim/status']
def prev(seq,t):
    lo,hi=0,len(seq)-1; best=None
    while lo<=hi:
        m=(lo+hi)//2
        if seq[m][0]<=t: best=seq[m]; lo=m+1
        else: hi=m-1
    return best
def box(w,far=18.0,near=26.0,bwf=30.0,bwn=120.0):
    if w<=0: return far
    tt=(w-bwf)/(bwn-bwf); tt=max(0.0,min(1.0,tt)); return far+tt*(near-far)

def classify(far,near,label):
    rows=[]
    for e in off:
        t=e['t']; v=e['v']
        cls=int(v[2]); w=float(v[3]); h=float(v[4]); dx=float(v[0]); dy=float(v[1])
        lp=prev(lead,t); lv=lp[1] if lp and t-lp[0]<=0.2 else 0.0
        sp=prev(sts,t); sv=sp[1] if sp and t-sp[0]<=0.6 else -1
        b=box(w,far,near)
        if cls==0 or w<=0: c='A'
        elif abs(dx+lv)>b or abs(dy)>b: c='C'
        elif cls==2: c='B'
        elif not (0.6<=w/h<=1.6): c='B'
        else: c='D'
        rows.append((t,c,cls,dx,dy,w,h,lv,sv,dx+lv,b))
    n=len(rows); cc=Counter(r[1] for r in rows)
    print(f"\n=== classify {label}: n={n} ===")
    for c in 'ABCD': print(f"  {c}: {cc.get(c,0)} ({100*cc.get(c,0)/n:.1f}%)")
    # longest runs
    def runs_of(c):
        runs=[]; cur=None
        for r in rows:
            if r[1]==c:
                if cur is None: cur=[r[0],r[0],0]
                cur[1]=r[0]; cur[2]+=1
            elif cur: runs.append(cur); cur=None
        if cur: runs.append(cur)
        return runs
    for c in 'ABCD':
        rs=runs_of(c)
        if not rs: continue
        best=max(rs,key=lambda x:x[1]-x[0])
        print(f"  longest {c}: {best[1]-best[0]:.2f}s n={best[2]} start={fmt(best[0])} end={fmt(best[1])}")
    # dx stats for C
    cdx=[r[3] for r in rows if r[1]=='C']
    if cdx: print(f"  C dx med={st.median(cdx):.0f} p10/p90={sorted(cdx)[int(.1*(len(cdx)-1))]:.0f}/{sorted(cdx)[int(.9*(len(cdx)-1))]:.0f} |dx|<=42 share={100*sum(1 for x in cdx if abs(x)<=42)/len(cdx):.0f}%")
    return rows

rows=classify(18,26,'D FIRE 18/26')
classify(42,42,'D FIRE 42/42 (sensitivity)')

# cls=0 run lengths (all D capture)
zr=[]; cur=None
for e in off:
    if int(e['v'][2])==0:
        if cur is None: cur=[e['t'],e['t'],0]
        cur[1]=e['t']; cur[2]+=1
    elif cur: zr.append(cur); cur=None
if cur: zr.append(cur)
print(f"\n=== cls=0 runs: count={len(zr)} ===")
print(f"  runs >=0.5s: {sum(1 for r in zr if r[1]-r[0]>=0.5)} total={sum(r[1]-r[0] for r in zr if r[1]-r[0]>=0.5):.1f}s")
print(f"  runs >=2.44s: {sum(1 for r in zr if r[1]-r[0]>=2.44)} total={sum(r[1]-r[0] for r in zr if r[1]-r[0]>=2.44):.1f}s")
print(f"  all cls=0 time: {sum(r[1]-r[0] for r in zr):.1f}s / {off[-1]['t']-off[0]['t']:.1f}s")
print(f"  max run: {max((r[1]-r[0] for r in zr),default=0):.2f}s")
