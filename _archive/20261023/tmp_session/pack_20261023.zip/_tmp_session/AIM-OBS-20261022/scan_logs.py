# -*- coding: utf-8 -*-
import re, statistics as st
from collections import Counter
from pathlib import Path
W=Path(r'D:\User\Desktop\比赛存档\v1')
D=W/'docs/_work/TRACK-DAY-20261022/evidence/d11_1900'
def scan_log(p, tag):
    txt=p.read_text(encoding='utf-8',errors='replace')
    lines=txt.splitlines()
    reasons=Counter()
    reason_t=[]
    tline=[]
    for i,l in enumerate(lines,1):
        m=re.search(r'不开火：(.+)$', l)
        if m:
            r=m.group(1).strip()
            # strip trailing telemetry glued on same line
            r=re.split(r'[T]|遥测|检查③|桥洞', r)[0].strip()
            reasons[r]+=1; reason_t.append((i,r))
        if l.startswith('[T]') or '[T] ' in l:
            tline.append((i,l))
    print(f"=== {tag} ({p.name}) lines={len(lines)} ===")
    print("  reasons:", dict(reasons.most_common()))
    print("  [T] lines:", len(tline))
    for key in ['停站点','到站','ACQUIRE','FIRE','硬死线','收到【开火放行】','发/中','发数','fire_gate=1','fire_ready=1','瞄准合格']:
        c=sum(1 for l in lines if key in l)
        print(f"  '{key}' lines: {c}")
    # first/last 3 [T]
    for i,l in tline[:2]+tline[-2:]:
        print(f"   [T] {i}: {l[:220]}")
    # stop/FIRE lines
    for i,l in enumerate(lines,1):
        if ('停站点' in l or '硬死线' in l or '收到【开火放行】' in l or 'ACQUIRE' in l) and len(l)<400:
            print(f"   L{i}: {l[:260]}")
    return reasons, tline
for tag,f in [('round1','7_path_aim.round1_box1826.log'),('round2','7_path_aim.round2_box42.log')]:
    scan_log(D/f, tag)

g=D/'5_gimbal.log'
txt=g.read_text(encoding='utf-8',errors='replace'); lines=txt.splitlines()
print(f"\n=== 5_gimbal.log lines={len(lines)} ===")
for key in ['收到【开火放行】','自瞄状态 -> TRACK','自瞄状态 -> SCAN','自瞄状态 -> IDLE','目标脱离视野','重扫接续','视觉静默','类别已锁定','诊断(不放行开火)','pub_LaserShot_Command','扫描进度','进入扫描前先归位','归位段结束']:
    print(f"  '{key}': {sum(1 for l in lines if key in l)}")
print("  last 8 lines:")
for l in lines[-8:]: print("   ", l[:220])
