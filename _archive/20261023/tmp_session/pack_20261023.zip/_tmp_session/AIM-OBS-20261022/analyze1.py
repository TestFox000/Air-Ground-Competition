# -*- coding: utf-8 -*-
import json, re, statistics as st
from collections import Counter
from pathlib import Path
W=Path(r'D:\User\Desktop\比赛存档\v1')
CAM=W/'docs/_work/TRACK-DAY-20261022/evidence/cam'
D19=W/'docs/_work/TRACK-DAY-20261022/evidence/d11_1900'
CAP=W/'docs/_work/TRACK-DAY-20261022/evidence/d11_1834/cap'

def pct(a,ps=(0,5,25,50,75,90,95,99,100)):
    if not a: return {}
    s=sorted(a); return {p:round(s[min(len(s)-1,int(round(p/100*(len(s)-1))))],2) for p in ps}

def analyze_jsonl(p,name):
    ev=[]
    for line in open(p,encoding='utf-8'):
        try: ev.append(json.loads(line))
        except: pass
    off=[e for e in ev if e.get('k')=='/offset_center']
    ts=[e['t'] for e in off]
    gaps=[ts[i]-ts[i-1] for i in range(1,len(ts))]
    gap05=sum(g for g in gaps if g>0.5); gap10=sum(g for g in gaps if g>1.0)
    total=ts[-1]-ts[0] if ts else 0
    cls=Counter(int(e['v'][2]) for e in off if len(e['v'])>=8)
    good=[e for e in off if len(e['v'])>=8 and int(e['v'][2]) in (1,2) and e['v'][3]>0]
    dx=[e['v'][0] for e in good]; dy=[e['v'][1] for e in good]; bw=[e['v'][3] for e in good]; bh=[e['v'][4] for e in good]
    ratio=[w/h for w,h in zip(bw,bh) if h]
    lead=[float(e['v']) for e in ev if e.get('k')=='/aim/lead_x']
    lead_nz=[x for x in lead if abs(x)>1e-9]
    sts=Counter(int(e['v']) for e in ev if e.get('k')=='/aim/status')
    print(f"=== {name}: offset n={len(off)} {total:.1f}s avg={len(off)/max(total,1e-9):.1f}Hz ===")
    print(f"  gap med/p90/p99/max = {pct(gaps)[50]}/{pct(gaps)[90]}/{pct(gaps)[99]}/{max(gaps):.2f}s; >0.5s count={sum(1 for g in gaps if g>0.5)} total={gap05:.1f}s ({100*gap05/total:.0f}%); >1.0s={sum(1 for g in gaps if g>1.0)} total={gap10:.1f}s ({100*gap10/total:.0f}%)")
    print(f"  cls {dict(cls)} ; valid-box frames={len(good)} ({100*len(good)/max(len(off),1):.0f}%)")
    print(f"  dx pct {pct(dx)}")
    print(f"  |dx| pct {pct([abs(x) for x in dx])}")
    print(f"  w med {pct(bw)[50]} h med {pct(bh)[50]} ratio p5/med/p95 {pct(ratio)[5]}/{pct(ratio)[50]}/{pct(ratio)[95]}")
    print(f"  lead n={len(lead)} nz={len(lead_nz)} ({100*len(lead_nz)/max(len(lead),1):.1f}%) nz_med={st.median(lead_nz) if lead_nz else 0:.1f} min/max={min(lead) if lead else 0:.1f}/{max(lead) if lead else 0:.1f}")
    print(f"  status {dict(sts)}")

for f in ('aim_rec_A.jsonl','aim_rec_B.jsonl'):
    analyze_jsonl(CAM/f,f)

# round1/2 FIRE window
def fire_window(p,name,start_pat,end_pat):
    lines=p.read_text(encoding='utf-8',errors='replace').splitlines()
    si=next((i for i,l in enumerate(lines) if start_pat in l),None)
    ei=next((i for i,l in enumerate(lines) if end_pat in l and i>(si or 0)),None)
    if si is None or ei is None:
        print(f"=== {name}: FIRE window not found ({si},{ei}) ==="); return
    seg=lines[si:ei+1]
    rc=Counter()
    tt=0; tnone=0; ts=0; aim=Counter()
    for l in seg:
        m=re.search(r'不开火：(.+)$',l)
        if m:
            r=re.split(r'\[T\]|遥测|检查③|桥洞',m.group(1))[0].strip(); rc[r]+=1
        if l.startswith('[T]') or '[T] ' in l:
            tt+=1
            tnone += 1 if '靶none' in l else 0
            ts += 1 if re.search(r'靶s[-0-9]',l) else 0
            m=re.search(r'瞄(\w+)',l)
            if m: aim[m.group(1)]+=1
    print(f"=== {name}: FIRE window lines {si+1}..{ei+1} ({len(seg)} lines, {tt} [T]) ===")
    print(f"  reasons {dict(rc.most_common())} total={sum(rc.values())}")
    print(f"  [T]: 靶none={tnone} 靶s…={ts}; aim={dict(aim)}")

for tag,f,s,e in [('round1','7_path_aim.round1_box1826.log','→ FIRE','放弃：到站硬死线'),('round2','7_path_aim.round2_box42.log','→ FIRE','放弃：到站硬死线')]:
    fire_window(D19/f,tag,s,e)

# 18:34 cap offset format
for f in ('offset.txt','lead.txt','ready.txt'):
    p=CAP/f
    txt=p.read_text(encoding='utf-8',errors='replace').splitlines()
    print(f"=== cap/{f}: lines={len(txt)} first3={txt[:3]} last1={txt[-1:]} ===")
