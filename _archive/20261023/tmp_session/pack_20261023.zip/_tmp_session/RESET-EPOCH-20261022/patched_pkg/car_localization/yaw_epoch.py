# -*- coding: utf-8 -*-
"""位姿源 epoch：一次进程启动 = 一个会话；每次 reset 重锚 = 会话内 +1。

## 为什么要有它
serial_reader 重启 / `reset:BLOCK,HEAD` 会让 `imu_yaw_init` 重捕
（serial_reader.py:149-153），发布 yaw 的**原点**被一次性换掉
（2026-10-22 实测单帧跳 130.7°）。这是“授权的不连续”，不是车在转。

航向守卫原先只看到位姿帧，无法区分“授权重锚”与“真的被转 130°”，
于是每次 reset/重启都判 `yaw_jump` → `EV_TASK_FAULT` → SAFE_STOP 永久锁存
（`clear_safety()` 全仓零调用者，只能重启栈）。本模块把“授权”显式化。

## 契约
- `value`：整数会话号。新会话基数取进程启动时的墙钟毫秒，会话内每次 reset +1，
  所以 `v0 < v1 < v2` 单调；**守卫只依赖“变了”**，不依赖“变大”
  （墙钟被 NTP 回拨时允许一次非单调，仍能正确触发重基线）。
- `kind`：0=startup（刚起，原点任意，行车前必须 reset）；
  1=reset（`reset:BLOCK,HEAD` 已把原点重锚到指令航向）。
"""
from __future__ import annotations

import time

#: 进程刚启动：原点任意（imu_yaw_init 取的是当时姿，与地图无关）。
KIND_STARTUP = 0
#: `reset:BLOCK,HEAD` 已执行：原点被授权重锚到 HEAD。
KIND_RESET = 1


class YawEpoch:
    """单调会话号 + 授权类型（纯 Python，无 rclpy 依赖，可本地单测）。"""

    def __init__(self, now_ms: int | None = None) -> None:
        self._base = int(now_ms if now_ms is not None else time.time() * 1000.0)
        self._seq = 0
        self._kind = KIND_STARTUP

    @property
    def value(self) -> int:
        return self._base + self._seq

    @property
    def kind(self) -> int:
        return self._kind

    def bump_reset(self) -> int:
        """reset 授权重锚：会话内 +1，并标记为“原点可信”。返回新 epoch。"""
        self._seq += 1
        self._kind = KIND_RESET
        return self.value


__all__ = ["YawEpoch", "KIND_STARTUP", "KIND_RESET"]
