set -u
OUT="_tmp_session/RESET-EPOCH-20261022"
D="$OUT/patches/reset_epoch.diff"
: > "$D"
pair() {
  diff -u --label "a/$1" --label "b/$1" "$2" "$3" >> "$D" || true
}
pair "src/dzbrain/dzbrain/io/contract.py" "dzrobot_v2/src/dzbrain/dzbrain/io/contract.py" "$OUT/patched_pkg/dzbrain/io/contract.py"
pair "src/dzbrain/dzbrain/io/ros_io.py" "dzrobot_v2/src/dzbrain/dzbrain/io/ros_io.py" "$OUT/patched_pkg/dzbrain/io/ros_io.py"
pair "src/dzbrain/dzbrain/tasks/localization.py" "dzrobot_v2/src/dzbrain/dzbrain/tasks/localization.py" "$OUT/patched_pkg/dzbrain/tasks/localization.py"
pair "src/car_localization/car_localization/serial_reader.py" "dzrobot_v2/src/car_localization/car_localization/serial_reader.py" "$OUT/patched_pkg/car_localization/serial_reader.py"
diff -u --label "a/src/car_localization/car_localization/yaw_epoch.py" --label "b/src/car_localization/car_localization/yaw_epoch.py" /dev/null "$OUT/patched_pkg/car_localization/yaw_epoch.py" >> "$D" || true
echo "---diff lines---"; wc -l < "$D"
echo "---files touched---"; grep -c "^+++" "$D"