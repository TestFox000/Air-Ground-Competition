# RESET-EPOCH：reset → 航向守卫 SAFE_STOP 闩锁的根治补丁（#4 线）

> 只读 `dzrobot_v2/src`、`config`、车端日志；**只写** `_tmp_session/RESET-EPOCH-20261022/`。
> 未部署、未上车、未 SSH、未改 src/config。补丁是**副本**：`patched_pkg/`（可跑、可 diff、可 revert 丢弃）。

## 0. 一句话结论

130.7° 是 `serial_reader` 在 reset/重启时把 **yaw 原点（imu_yaw_init）** 一次性重锚造成的**授权不连续**，不是车在转（40.4 rad/s = 静止包络 45°/s 的 51 倍，v=0、位置不动）。
根治 = 把"授权"显式化成新话题 **`/nav/yaw_epoch`**（`[epoch, kind]`，transient_local）；航向守卫**只在 epoch 变化的那一帧重基线**，阈值与其余判据一字不改——真正的 130° 旋转（无 epoch 变化）照旧触发 `EV_TASK_FAULT`（红/绿测试 T2/T3/T5 带牙验证）。

## 1. 事实链（为什么修这里，不修阈值/斜坡）

| 事实 | 证据 |
|---|---|
| 跳变 = 130.7°，帧间隔 2317.6°/s（dt≈0.056 s），v=0.00 | `docs/_work/TRACK-DAY-20261022/evidence/cam/7_path_A.log:141` |
| 跳变前/后遥测 yaw = −131.3° / −0.6°（含固定 trim −0.6°，差值抵消）= 原始帧 −130.7° → 0.0° | 同日志 `:139,153`；`config/robot.yaml:446,880`（trim） |
| 原点被换掉的是 `imu_yaw_init`（`:149-153` 重捕）；发布四元数只带 `yaw_rel`（`:236-242`） | `car_localization/serial_reader.py` |
| **`dr_yaw_off` 不进发布 yaw**（只喂 DR 积分 `:221-223` 与 5Hz 打印 `:248-249`）⇒ **给 130° 做斜坡无效** | 同上；前卡 `_tmp_session/INFRA-RESET-20261022/REPORT.md` §1.3 |
| 守卫单帧 >30° 立即判故障 → `EV_TASK_FAULT`；Safety 锁存 SAFE_STOP 且全仓无 `clear_safety()` 调用者 | `tasks/localization.py:751-756,812-816`；`tasks/safety.py:432-436`；`main.py:2188-2200`（无 clear CLI） |

## 2. 设计（最小改动）

### 2.1 新话题 / 字段

```
/nav/yaw_epoch   std_msgs/UInt64MultiArray   data = [epoch, kind]
QoS: depth=1, reliable, TRANSIENT_LOCAL      （contract.QOS_EPOCH）
  epoch : 会话号。启动时 = 墙钟毫秒；每次 reset 重锚 +1 ⇒ 连续两次 reset 严格递增；
          重启后的新会话基数更大（实测 T4.5：…0000002 → …0001000）。
  kind  : 0 = startup（刚起，原点任意，行车前必须 reset）；1 = reset（原点已重锚到指令航向）。
```

**为什么 transient_local**：现场已验证的缓解是"先 reset（brain 未起）再起 brain"。latched 语义让后起的 dzbrain 一订阅就拿到当前授权，B 轮的顺序约束可以取消；同时 1 Hz 兜底重发（`serial_reader.py` odom 回调）保证 DDS 缓存异常时也能收敛。

### 2.2 改哪几行（原仓库行号）

| 文件 | 原行 | 改动 |
|---|---|---|
| `car_localization/serial_reader.py` | 29-34 | 导入 `YawEpoch` + `rclpy.qos` + `UInt64MultiArray` |
| 同上 | 107-108 之后 | 建 `/nav/yaw_epoch` 发布者（transient_local）+ `self.yaw_epoch = YawEpoch()` + 发首帧 |
| 同上 | 189 之前 | 新增 `_publish_epoch()` |
| 同上 | 181-183 之后 | reset 重锚后 `bump_reset()` + 立即广播 |
| 同上 | 246-247 | 每 50 帧（≈1 Hz）兜底重发 |
| `dzbrain/io/contract.py` | 41 | 新增 `QOS_EPOCH`（transient_local） |
| 同上 | 73-74 之后 | 话题表新增 `yaw_epoch` |
| `dzbrain/io/ros_io.py` | 225 / 213 | 导入 `UInt64MultiArray`；新增 `self._yaw_epoch` |
| 同上 | 318-322 之后 | `on_yaw_epoch()` 回调 |
| 同上 | 347-348 | 订阅列表新增一条（**不**进 `REQUIRED_SUBSCRIPTIONS`，不阻塞启动自检） |
| 同上 | 455 之后 | 新增 `yaw_epoch() -> (value, kind) | None` |
| `dzbrain/tasks/localization.py` | 226 | 新增 `_yaw_prev_epoch / yaw_epoch_rebaselines / yaw_epoch_startup` |
| 同上 | 702（`frame_t = now - age` 后） | **epoch 变化 ⇒ 只重基线并 return**（不判故障、不发 `EV_TASK_FAULT`） |
| 同上 | 846 之前 | 新增 `_pose_yaw_epoch()`（`getattr` 懒查，旧车端/旧替身自动降级为 None） |
| `car_localization/yaw_epoch.py` | 新文件 | `YawEpoch`（纯 Python、无 rclpy、可单测；ms 基数 + 会话内 +1） |

### 2.3 守卫判据（只豁免一帧，其余原样）

```python
frame_t = now - age
epoch = self._pose_yaw_epoch()                  # None = 旧源，行为不变
if epoch is not None:
    value, kind = epoch
    if self._yaw_prev_epoch is not None and value != self._yaw_prev_epoch:
        self._yaw_prev = (frame_t, x, y, yaw)   # 重新基线
        self._yaw_prev_epoch = value
        self._yaw_bad_run = self._yaw_good_run = 0
        return                                  # ★ 这一帧没有“角速度”，不判
    self._yaw_prev_epoch = value
# ↓ 以下原判据完全不动：dt 门槛 / plausible speed / 差速包络 / 单帧跳变 30° / IMU 矛盾 / 连续 N 帧
```

安全性论证：epoch 只由 `serial_reader` 在 **reset 或启动**时发布；真实的物理旋转/绑架不会产生 epoch 变化 ⇒ 仍走原判据（T2/T3/T5）。重基线只吃掉"换纪元后的第一帧"，下一帧起恢复正常（T3：同 epoch 内再转 120° 仍闩锁）。

### 2.4 为什么不用"把 130° 斜坡化"

跳变发生在**发布 yaw 的原点**（`imu_yaw_init` 重捕），而 `dr_yaw_off` 从不进入发布四元数（`serial_reader.py:236-242`）；斜坡只能改 DR 积分方向/诊断打印，**消不掉这次跳变**。若把 yaw 原点本身斜坡化，等于让车在几秒内"慢慢转 130°"：投影/前视/云台航向全部被带偏，且斜坡速率一旦超过包络仍会触发（更糟：把一次可识别的授权点变成一段不可识别的错误航向）。

## 3. 红 / 绿（真实运行输出）

- 测试文件：`tests/test_reset_epoch.py`（152 行，纯脚本 + `tests/harness.py` 的 `check/finish`；仓库无 pytest 依赖，故未引入 pytest，跑法即项目惯例）
- 补丁副本：`patched_pkg/`（`dzbrain/` + `car_localization/`，不改仓库）
- 输出留档：`out/red.txt`、`out/green.txt`

```bash
# 红：对当前仓库代码
python -X utf8 _tmp_session/RESET-EPOCH-20261022/tests/test_reset_epoch.py red
#   结果：6/16 通过，10 失败        （exit 1）
# 绿：对补丁副本
python -X utf8 _tmp_session/RESET-EPOCH-20261022/tests/test_reset_epoch.py green
#   结果：20/20 全部通过 ✅          （exit 0）
```

| 用例 | 断言要点 | 红 | 绿 |
|---|---|---|---|
| T1 reset+epoch | 不闩锁 / 0 条 `EV_TASK_FAULT` / 重基线 1 次 | ❌ 3 项 | ✅ 3 项 |
| T2 无 epoch | 真跳变闩锁、reason=`yaw_jump` | ✅ 3 项（保护在） | ✅ 3 项 |
| T3 带牙 | 重锚不闩锁，但**同 epoch 再转 120° 必须闩锁** | ❌ 2 项 | ✅ 3 项 |
| T4 单调 | `v0<v1<v2`、kind 0→1、重启基数更大 | ❌ 1 项（模块不存在） | ✅ 5 项 |
| T5 有钩子但不变 | 同 epoch 跳变仍闩锁（防"有钩子就放行"） | ✅ 2 项 | ✅ 2 项 |
| T6 连续两次 reset | 两次均不闩锁、重基线=2、零 fault、epoch 跟到最新 | ❌ 4 项 | ✅ 4 项 |

**踩坑记录（对后续复用很重要）**：`tests/fakes.py:18` 会 `sys.path.insert(0, .../src/dzbrain)` 把仓库源码顶到最前。测试若先 `import fakes` 再 `import dzbrain`，绿跑会静默用**仓库原版**（第一次绿跑就是假绿，T1 仍红）。已改为"先 import dzbrain、再 import fakes"，并在输出首行打印实际 `dzbrain.__file__` 自证（`out/green.txt:1` 指向 `patched_pkg`）。

语法门禁：`python -X utf8 -m py_compile` 对 5 个补丁文件 ⇒ **exit 0**。

## 4. 影响面与回滚（各一行）

- **影响面**：必须**同一次**部署 `car_localization`（serial_reader + 新 yaw_epoch.py）与 `dzbrain`（contract/ros_io/localization）两个包，colcon 重编 + `start_all.sh restart`；无 config/话题名/单位变化，新话题不在 `REQUIRED_SUBSCRIPTIONS`（旧 dzbrain 忽略它、旧 serial_reader 让新 dzbrain 降级为今天的判据）⇒ 两个方向都可分批灰度。
- **回滚点**：恢复上一版两个包的 install/src（部署工具默认把被覆盖文件备份到 `~/duzhong/_backups/<时间戳>/`），`start_all.sh restart`；本补丁不涉及 config/标定/数据迁移，回滚无残留。

## 5. 本卡没能验证的（如实列出）

1. **无 rclpy 环境**：`serial_reader.py` / `ros_io.py` 只做了 `py_compile`（exit 0），**没有跑 ROS 端到端**；话题 IDL/QoS 的实际匹配需车端/带 ROS 的机器。
2. **未上车**：`/nav/yaw_epoch` 的真实发布频率、transient_local 晚订阅是否可靠、`reset` 后 epoch 是否恰好 +1，需一次现场 30 s 采集。
3. **startup epoch 只重基线、不软停**（刻意收小范围）：`serial_reader` 单独重启后原点任意，行车前仍需 `reset`（现场规程不变）。若要做成"startup 自动软停"，必须并入 `_update_drift_guard` 的 `_limit_state` 唯一写者契约（另卡，避免两个写者互相覆盖）。
4. **墙钟回拨**：epoch 用 `time.time()*1000`，NTP 回拨会让单调性破一次；守卫只依赖"变了"，仍会正确重基线（T4 只钉正常路径）。

## 6. 文件清单

```
_tmp_session/RESET-EPOCH-20261022/
├─ REPORT.md                          （本文件）
├─ patches/reset_epoch.diff            （unified diff：5 文件 / +149 −2；含 1 个新文件）
├─ patches/_gen_diff.sh                （生成 diff 的脚本，可复跑）
├─ patched_pkg/                        （打过补丁的副本；测试直接 import 它）
│   ├─ dzbrain/{core,io,tasks,...}
│   └─ car_localization/{serial_reader.py, yaw_epoch.py, ...}
├─ tests/test_reset_epoch.py           （红/绿测试，152 行）
└─ out/{red.txt, green.txt}            （真实运行输出；green 首行自证 import 路径）
```

复跑门禁（两条即可）：
```
python -X utf8 -m py_compile _tmp_session/RESET-EPOCH-20261022/patched_pkg/car_localization/serial_reader.py _tmp_session/RESET-EPOCH-20261022/patched_pkg/dzbrain/io/ros_io.py _tmp_session/RESET-EPOCH-20261022/patched_pkg/dzbrain/tasks/localization.py
python -X utf8 _tmp_session/RESET-EPOCH-20261022/tests/test_reset_epoch.py green   # 应为 20/20 exit 0
```
