# -*- coding: utf-8 -*-
r"""reset-epoch 修复的三条验收（仓库惯例：纯脚本，python file.py，exit 0=绿/1=红）。

用法：
    python test_reset_epoch.py red      # 对**未修补**仓库代码跑（预期红：T1/T3/T4/T6 失败）
    python test_reset_epoch.py green    # 对 patched_pkg 副本跑（预期全绿）

验收目标（对应 R0 任务）：
  T1  带 epoch 的 reset（原点重锚）**不闩锁**、不发 EV_TASK_FAULT；
  T2/T5  **真正的 130° 旋转仍要触发保护**（无 epoch / epoch 不变两种口径）；
  T3  重基线之后，同一 epoch 内的下一次真跳变**仍必须**闩锁（修完不能变瞎）；
  T4  YawEpoch 单调（连续两次 reset 的 epoch 严格递增，重启后基数更大）；
  T6  连续两次 reset 各自重基线、一次都不误判（epoch 单调推进）。

不使用 pytest：项目 29 套测试全是这种自记账脚本（tests/harness.py），
本文件沿用 check()/finish() 口径，便于和主干回归合并。
"""
from __future__ import annotations

import math
import pathlib
import sys

MODE = (sys.argv[1] if len(sys.argv) > 1 else "red").strip().lower()
HERE = pathlib.Path(__file__).resolve()
ROOT = HERE.parents[3]                      # .../v1
if MODE == "green":
    PKG = ROOT / "_tmp_session/RESET-EPOCH-20261022/patched_pkg"
    CARLOC = PKG
else:
    PKG = ROOT / "dzrobot_v2/src/dzbrain"
    CARLOC = ROOT / "dzrobot_v2/src/car_localization"

sys.path.insert(0, str(CARLOC))
sys.path.insert(0, str(PKG))
sys.path.insert(0, str(ROOT / "dzrobot_v2/src/dzbrain/tests"))

# ★ 顺序要紧：先把 dzbrain 钉在目标副本上，再 import fakes ——
#   tests/fakes.py 第 18 行会 sys.path.insert(0, .../src/dzbrain) 把仓库源码顶到最前；
#   若先 import fakes，dzbrain 会被解析成**仓库原版**，绿跑就变成假的（本文件踩过）。
from dzbrain.core.blackboard import Blackboard                # noqa: E402
from dzbrain.core.config import Config                        # noqa: E402
from dzbrain.core.events import EV_TASK_FAULT, EventBus       # noqa: E402
from dzbrain.tasks.localization import LocalizationTask       # noqa: E402

from fakes import FakeBridge, FakeClock                       # noqa: E402
from harness import check, finish, section                    # noqa: E402

print(f"[reset-epoch] MODE={MODE}  dzbrain={sys.modules['dzbrain'].__file__}")

BLOCK = "D11"
X, Y = 0.175, 3.675


def build():
    clock = FakeClock()
    bridge = FakeBridge(clock)
    bb, bus = Blackboard(), EventBus()
    cfg = Config.from_dict({
        "route": {"tokens": ["D11", "E11"]},
        "pursuit": {}, "fix": {"anchor_at_waypoint": False},
        "safety": {}, "logging": {}, "mission": {"auto_start": False},
    })
    task = LocalizationTask(bridge, bb, bus, cfg, log=lambda m: None, clock=clock.now)
    sub = bus.subscribe("fault", [EV_TASK_FAULT], maxsize=32)
    return task, bridge, bb, bus, clock, sub


def frame(task, bridge, clock, yaw_deg, epoch=None):
    """喂一帧（dt=0.05 s）；epoch=(value,kind) 时给 bridge 挂鸭子类型钩子。"""
    if epoch is not None:
        bridge.yaw_epoch = lambda: (epoch[0], epoch[1])
    bridge.set_pose(X, Y, math.radians(yaw_deg))
    clock.advance(0.05)
    task.tick()


def baselines(task):
    return int(getattr(task, "yaw_epoch_rebaselines", 0))


section("T1 带 epoch 的 reset：130.7° 原点重锚不得闩锁")
t, b, bb, bus, ck, sub = build()
frame(t, b, ck, -130.7, epoch=(1000, 0))     # startup 基线
frame(t, b, ck, 0.0, epoch=(1001, 1))        # reset 授权 + 单帧 130.7°
check("T1.1 不闩锁（yaw_untrusted=False）", t.yaw_untrusted is False,
      f"got {t.yaw_untrusted}, reason={t._yaw_reason!r}")
check("T1.2 不发 EV_TASK_FAULT（0 条）", len(sub.poll(32)) == 0)
check("T1.3 计一次重基线（yaw_epoch_rebaselines==1）", baselines(t) == 1,
      f"got {baselines(t)}")

section("T2 无 epoch 能力（老 serial_reader/老替身）：真跳变仍必须闩锁")
t, b, bb, bus, ck, sub = build()
frame(t, b, ck, -130.7)                       # 不挂 yaw_epoch
frame(t, b, ck, 0.0)
check("T2.1 闩锁（保护保留）", t.yaw_untrusted is True)
check("T2.2 发过 EV_TASK_FAULT", any(e.type == EV_TASK_FAULT for e in sub.poll(32)))
check("T2.3 原因为 yaw_jump", t._yaw_reason == "yaw_jump", f"got {t._yaw_reason!r}")

section("T3 带牙：重基线之后，同一 epoch 内再真转 120° 仍必须闩锁")
t, b, bb, bus, ck, sub = build()
frame(t, b, ck, -130.7, epoch=(1000, 0))
frame(t, b, ck, 0.0, epoch=(1001, 1))        # 授权重锚（不判）
check("T3.1 重锚那一刻不闩锁", t.yaw_untrusted is False,
      f"got {t.yaw_untrusted}, reason={t._yaw_reason!r}")
sub.poll(32)                                  # 清掉 T1 段可能残留
frame(t, b, ck, 120.0, epoch=(1001, 1))      # 同 epoch 内 120° / 0.05 s
check("T3.2 同 epoch 真转 120° 仍闩锁", t.yaw_untrusted is True)
check("T3.3 且发出 yaw_jump 故障",
      t._yaw_reason == "yaw_jump" and any(e.type == EV_TASK_FAULT for e in sub.poll(32)))

section("T4 YawEpoch 单调：连续两次 reset 严格递增、重启后基数更大")
try:
    from car_localization.yaw_epoch import KIND_RESET, KIND_STARTUP, YawEpoch
    ep_ok, ep_err = True, ""
except Exception as exc:                      # noqa: BLE001
    ep_ok, ep_err = False, f"{type(exc).__name__}: {exc}"
check("T4.1 yaw_epoch 模块存在（未修补代码应在此失败）", ep_ok, ep_err)
if ep_ok:
    ep = YawEpoch(now_ms=1_760_000_000_000)
    v0, k0 = ep.value, ep.kind
    v1 = ep.bump_reset()
    v2 = ep.bump_reset()
    check("T4.2 startup kind=0", k0 == KIND_STARTUP, f"got {k0}")
    check("T4.3 连续两次 reset 严格递增 v0<v1<v2",
          v0 < v1 < v2, f"v0={v0} v1={v1} v2={v2}")
    check("T4.4 第二次 reset 后 kind=1", ep.kind == KIND_RESET, f"got {ep.kind}")
    ep2 = YawEpoch(now_ms=1_760_000_001_000)  # 模拟重启（更晚墙钟）
    check("T4.5 重启后新会话基数 > 旧会话末值", ep2.value > v2,
          f"new={ep2.value} old={v2}")

section("T5 epoch 存在但**不变**：130.7° 跳变仍必须闩锁（防“有钩子就放行”）")
t, b, bb, bus, ck, sub = build()
frame(t, b, ck, -130.7, epoch=(2000, 1))
frame(t, b, ck, 0.0, epoch=(2000, 1))
check("T5.1 同 epoch 跳变照旧闩锁", t.yaw_untrusted is True)
check("T5.2 且发出 EV_TASK_FAULT", any(e.type == EV_TASK_FAULT for e in sub.poll(32)))

section("T6 连续两次 reset：各自重基线、epoch 单调推进、零误报")
t, b, bb, bus, ck, sub = build()
state = {"v": 3000, "k": 0}
b.yaw_epoch = lambda: (state["v"], state["k"])
frame(t, b, ck, -130.7)                       # startup 基线（v=3000）
state["v"], state["k"] = 3001, 1
frame(t, b, ck, 0.0)                          # reset #1（130.7° 重锚）
state["v"], state["k"] = 3002, 1
frame(t, b, ck, 2.0)                          # reset #2（小幅重锚）
check("T6.1 两次 reset 均不闩锁", t.yaw_untrusted is False,
      f"got {t.yaw_untrusted}, reason={t._yaw_reason!r}")
check("T6.2 重基线计数=2（每次 epoch 变化一次）", baselines(t) == 2,
      f"got {baselines(t)}")
check("T6.3 零 EV_TASK_FAULT", len(sub.poll(32)) == 0)
check("T6.4 epoch 跟踪到最新值（单调推进）",
      getattr(t, "_yaw_prev_epoch", None) == 3002,
      f"got {getattr(t, '_yaw_prev_epoch', None)}")

finish()
