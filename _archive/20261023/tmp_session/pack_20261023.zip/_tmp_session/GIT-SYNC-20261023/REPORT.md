# Git 双远端同步 · 第一轮只读审计（2026-10-23）

> 只读审计，**未推送、未改远端、未动 origin/public**。命令与原始输出见 [COMMANDS.md](COMMANDS.md)。

## 0. 三条结论（与交接事实有出入，以此为准）

1. **GitHub 不是"无关历史"**：远端 main = `9d8e486`，就是本地分支 `chunk-push` 的头；其根 `61acc8b`（chunk base）也在本地。另 `TestFox000/v2.0` 301 重定向到 **同一仓库**（repo id 1429839966）⇒ origin 与 github 是同一个仓，main 已被一条"分块重建"历史占用。
2. **真正的阻塞是 100 MB 单文件硬限**：本地 `main` 可达 blob 中 **6 个 >100 MB**（320/287/252/208/207/118 MB，全在 `docs/history_cache/` 与 `_tmp_session/archive/`）⇒ 任何携带该历史的推送（含新建分支、merge 后推 main、搬去新仓）都会被 GitHub 拒；本地整仓 **2.24 GiB**。
3. **Gitee 失败点已定位到 blob 下载**：`git fetch --filter=blob:none` **成功（EXIT=0）**；而 `--depth=1`、protocol v0、HTTP/1.1 三种组合全部在 index-pack 启动（`pack_header=2,2233`）后**静默卡死 150 s**，随后报 `invalid index-pack output`。不是认证、不是协议版本、不是 HTTP 版本。

## 1. 现状核实

| 项 | 实测 |
|---|---|
| 分支 / HEAD | `main` / `a7df165`（**比交接多 2 个提交**：`8de37a0`、`a7df165`，他人落卡） |
| 远端 | github=Air-Ground-Competition、gitee=yubinghuan_1/air_ground、origin=v2.0（→同 GitHub 仓）、public=本地裸库 |
| 远端 main | github `9d8e486` = origin `9d8e486` = 本地 `chunk-push`；gitee `0bc2196`（根 `6abf5b1` 9-28 重建基线，361 提交，与本地零共享提交） |
| 上游追踪 | `main` **无 upstream** |
| 可推送内容 | 本轮 §11 已提交：`8768b34`(AGENTS+13/−1)、`1ec743d`(AGENTS+42)，仅 AGENTS.md，无凭据 |

### 工作树脏项分类（41 项，均非本轮任务）

- **他人已暂存（勿并入）**：`.gitignore`（**首行新增 BOM** + 加 `git_save/`）、`docs/_工具/doc_policy.json`（+1 行）
- **他人已改未暂存**：21 篇 `docs/**`、`doc_policy_baseline.json`、`目录索引.json/.md`
- **他人未跟踪**：8 篇新文档、`DOC-FIX-20261023` 卡、`_archive/20261023/`、docs 快照 zip、`history_cache/` 归档目录
- **另一张卡的在途删除**：`air_ground_models/` 6 个文件（` D`）
- **本轮任务**：无脏项（AGENTS.md 改动已入 commit）

## 2. 认证与部署检查

| 项 | 结论 |
|---|---|
| `.github/workflows` | **不存在**（`.github` 目录都没有）⇒ 推 GitHub **不触发部署**；无 git hooks |
| GitHub 写权限 | ✅ SSH `Hi TestFox000!` 认证通过；HTTPS ls-remote 亦返回 9d8e486（curl 200/24.6 s，偏慢）；仓库 `pushed_at` 10-23 08:44 证明本机推过 |
| Gitee 写权限 | ⚠️ **未验证**——SSH `Permission denied (publickey)`（无 gitee 密钥），只能走 HTTPS；GCM 2.9.1 已配（`credential.helper`=GCM），是否存有 gitee 令牌未验证（不读凭据） |
| 凭据/大文件 | 待推的 2 个提交只改 AGENTS.md，口令/token/私钥扫描 **0 命中**；构建产物未在暂存区 |

## 3. 三选项（含风险 / 回滚 · 均需你点头后才执行）

**A. 新建分支分推（推荐）** — 在既有 chunk 线上加一个"只带增量"的提交，推 `agents/<名>/<主题>`，不碰任何 main。
- 依据：GitHub main = `9d8e486`（本地已有），chunk 树 239.6 MB、**0 个 >100 MB blob**；增量只需 22 个文件（10 改 + 12 增）。
- 命令（GitHub，SSH 免改 remote 配置）：`git switch -c agents/lead/v1root-20261023 chunk-push` → 逐文件取出 HEAD 版本 → commit → `git push git@github.com:TestFox000/Air-Ground-Competition.git agents/lead/v1root-20261023`
- 风险：分支树是 chunk 快照（含 `dzrobot_v2/`、`dzsmartscout/`），不等于 v1 根仓全貌；**推送量小、可随时放弃**。
- 回滚：remote 分支可 `--delete`（仅删自建分支），本地 `git branch -D`；main 全程未动。

**B. 先 merge 远端历史再推 main — ❌ 实测不可行，不建议尝试。**
- 理由：① 本地 main 含 6 个 >100 MB blob，GitHub 硬限直接拒；② 需上传 ~2.2 GB（当前 GitHub 仓仅 173 MB）；③ gitee 与本地零共享提交，merge 后同样超限。
- 若仍要试，命令只到本地：`git merge --allow-unrelated-histories 9d8e486`（冲突面大），**推前必被拒**；回滚 `git reset --hard a7df165`。风险：浪费一次 2 GB 上传与数十分钟。

**C. 以本地历史为准另建仓库** — 同样受 100 MB 限制，**只能推"无历史的精简快照"**；需你手动建空仓（本机无 gh CLI/令牌）。
- 命令：`git checkout --orphan snapshot-20261023` → 移除 6 个大归档与 1.5 GB 工作树中的重物 → commit → `git push <新仓URL> snapshot-20261023:main`
- 风险：与现有 GitHub 仓重复、要多维护一处；回滚 = 删新仓（你操作）。

## 4. 建议

先做 **A**（两端各推一个自建分支，成本最低、零改写），同时把 `docs/history_cache/02_仓库快照/*.tar.gz`、`03_过程稿快照/*.tar.gz` 与 `_tmp_session/archive/zips/*.zip` 明确列入不追踪（历史里那 6 个 blob 因"禁止改写"**永久留存**，只能保证今后不再增加），待你确认后再考虑是否把 gitee 的分支也推上去、以及是否要修 gitee 传输。

## 5. 未验证 / 待你决定

- Gitee **写**权限未验证（不敢空推探活）；其 fetch 卡死疑为服务端流入中断，未拿到服务端证据（无 Gitee 后台权限）。
- `air_ground_models/` 删除、21 篇文档改动属他人/他卡在途，**本轮一律未动**。
