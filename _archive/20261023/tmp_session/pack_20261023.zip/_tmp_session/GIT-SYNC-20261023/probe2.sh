#!/usr/bin/env bash
D="D:/User/Desktop/比赛存档/v1/_tmp_session/GIT-SYNC-20261023/probe"
G="https://gitee.com/yubinghuan_1/air_ground.git"
cd "$D" || exit 1
mkdir -p p5 p6 p7
p5(){ cd "$D/p5" && rm -rf .git && git init -q && git remote add g "$G" && echo "CMD: http.version=HTTP/1.1 + depth=1" > ../p5.log;
  GIT_TERMINAL_PROMPT=0 timeout 100 git -c http.version=HTTP/1.1 fetch --depth=1 g main >> ../p5.log 2>&1; echo "EXIT=$?" >> ../p5.log; }
p6(){ cd "$D/p6" && rm -rf .git && git init -q && git remote add g "$G" && echo "CMD: partial clone --filter=blob:none depth=1" > ../p6.log;
  GIT_TERMINAL_PROMPT=0 timeout 100 git -c protocol.version=2 fetch --depth=1 --filter=blob:none g main >> ../p6.log 2>&1; echo "EXIT=$?" >> ../p6.log; }
p7(){ cd "$D/p7" && rm -rf .git && git init -q && git remote add g "$G" && echo "CMD: GIT_TRACE=1 depth=1" > ../p7.log;
  GIT_TRACE=1 GIT_TERMINAL_PROMPT=0 timeout 100 git fetch --depth=1 g main >> ../p7.log 2>&1; echo "EXIT=$?" >> ../p7.log; }
p5; echo "p5 done"
p6; echo "p6 done"
p7; echo "p7 done"
echo ALL2_DONE
