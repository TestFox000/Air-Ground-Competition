#!/usr/bin/env bash
# Gitee fetch 失败诊断探针（只读，全部在 _tmp_session 内）
D="D:/User/Desktop/比赛存档/v1/_tmp_session/GIT-SYNC-20261023/probe"
G="https://gitee.com/yubinghuan_1/air_ground.git"
mkdir -p "$D"; cd "$D" || exit 1
run() {
  name="$1"; shift
  echo "===== $name =====" > "$name.log"
  echo "CMD: $*" >> "$name.log"
  start=$(date +%s)
  GIT_TERMINAL_PROMPT=0 timeout 150 "$@" >> "$name.log" 2>&1
  ec=$?
  end=$(date +%s)
  echo "EXIT=$ec SECS=$((end-start))" >> "$name.log"
  echo "---- $name done ec=$ec ----"
}

rm -rf p1 p2 p3 p4

# P1: protocol.version=0 + depth=1 on main
mkdir -p p1 && cd p1 && git init -q && git remote add g "$G"
run p1 git -c protocol.version=0 fetch --depth=1 g main
cd ..

# P2: default protocol v2 + depth=1 on main
mkdir -p p2 && cd p2 && git init -q && git remote add g "$G"
run p2 git fetch --depth=1 g main
cd ..

# P3: full (non-shallow) fetch of main, default settings
mkdir -p p3 && cd p3 && git init -q && git remote add g "$G"
run p3 git fetch g main
cd ..

# P4: shallow fetch of a small side branch (size dependence test)
mkdir -p p4 && cd p4 && git init -q && git remote add g "$G"
run p4 git fetch --depth=1 g agents/trae-glm/pure-pursuit-u2
cd ..

echo "ALL_DONE"
