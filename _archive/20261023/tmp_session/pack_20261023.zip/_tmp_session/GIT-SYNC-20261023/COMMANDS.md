# 命令记录（均已执行 · 只读）

工作目录 `D:/User/Desktop/比赛存档/v1`，git 2.56.0.windows.2，GCM 2.9.1。所有探针在 `_tmp_session/GIT-SYNC-20261023/probe/` 内（临时仓，不入库）。

## 1. 仓库现状

```bash
git remote -v; git rev-parse --abbrev-ref HEAD; git rev-parse HEAD
git for-each-ref --format='%(refname) %(objectname:short)'
git merge-base --is-ancestor refs/remotes/gitee/main HEAD   # => 非祖先
git rev-list --left-right --count refs/remotes/gitee/main...HEAD  # => 361  17
git rev-list --max-parents=0 refs/remotes/gitee/main       # => 6abf5b1 (2026-09-28 重建基线)
git rev-list --max-parents=0 refs/heads/chunk-push         # => 61acc8b (chunk base)
```

关键输出：HEAD=`a7df165`；github main=`9d8e486`=chunk-push；gitee main=`0bc2196`；`main` 无 upstream。

## 2. 远端可达性与认证

```bash
git ls-remote git@github.com:TestFox000/Air-Ground-Competition.git   # 9d8e486 refs/heads/main
git ls-remote https://github.com/TestFox000/Air-Ground-Competition.git  # 同上（首次 Recv failure，重试成功）
git ls-remote https://gitee.com/yubinghuan_1/air_ground.git         # 0bc2196 + 多个 agents/* 分支
ssh -T git@github.com    # Hi TestFox000! ... 认证通过
ssh -T git@gitee.com     # git@gitee.com: Permission denied (publickey).
curl -sS https://api.github.com/repos/TestFox000/v2.0 -L          # 301 -> repo 1429839966 = Air-Ground-Competition
```

## 3. 体积与 100 MB 红牌

```bash
git rev-list --objects HEAD | git cat-file --batch-check='%(objecttype) %(objectname) %(objectsize) %(rest)' \
  | awk '$1=="blob" && $3>100000000'          # => 6 条
git count-objects -vH                          # size-pack: 2.24 GiB
```
命中的 6 个 blob：
320.2 MB `docs/history_cache/03_过程稿快照/process_TRACK-FIELD-R3_20261022.tar.gz`；
287.4 MB `docs/history_cache/02_仓库快照/ext_gitee_air_ground_20261022.tar.gz`；
251.7 MB `docs/history_cache/03_过程稿快照/process_drafts_20261022.tar.gz`；
207.7 MB `docs/history_cache/02_仓库快照/ext_yb_tree_20261022.tar.gz`；
206.6 MB `docs/history_cache/02_仓库快照/ext_gitee_main_tree_20261022.tar.gz`；
117.8 MB `_tmp_session/archive/zips/小车负责人.zip`。
对照：`chunk-push` 历史 >100 MB blob 数 = **0**；其树 1897 文件 / 239.6 MB。

## 4. Gitee fetch 诊断（本轮核心）

四组探针全部 `git init` 临时仓 + `git remote add`，结果：

| 探针 | 命令 | 结果 |
|---|---|---|
| p1 | `git -c protocol.version=0 fetch --depth=1 g main` | `fatal: fetch-pack: invalid index-pack output`，卡死至 150 s 超时 |
| p2 | `git fetch --depth=1 g main` | 同上 |
| p3 | `git fetch g main`（非浅） | 同上 |
| p4 | `git fetch --depth=1 g agents/trae-glm/pure-pursuit-u2`（小侧分支） | 同上 ⇒ **与分支/历史大小无关** |
| p5 | `git -c http.version=HTTP/1.1 fetch --depth=1 g main` | 同上 |
| p6 | `git -c protocol.version=2 fetch --depth=1 --filter=blob:none g main` | ✅ **EXIT=0**，拿到 tip 提交/树（1 commit） |
| p7 | `GIT_TRACE=1 git fetch --depth=1 g main` | 停在 `index-pack --stdin --fix-thin --pack_header=2,2233` 之后无任何输出 |

⇒ 协商正常（`pack_header=2,2233` 已收到），**死在 pack 流读取**；与协议版本、HTTP 版本、深浅无关，只与"要不要下载 blob"有关。

## 5. 部署面与暂停堆

```bash
ls -d .github            # No such file or directory（无 workflow，不触发部署）
ls .git/hooks | grep -v sample   # 空
git diff --cached --name-only    # .gitignore / docs/_工具/doc_policy.json（他人暂存）
git diff 8768b34^..HEAD -- AGENTS.md | grep -iE '(ghp_|github_pat_|BEGIN .*PRIVATE KEY|password|token)'
                                 # 0 命中
```

## 6. 未执行（遵守硬边界）

`git push`（含 --dry-run）/ `git fetch` 进主仓 / `force` / 删分支 / 改 remote 或权限 —— **全部未做**。
