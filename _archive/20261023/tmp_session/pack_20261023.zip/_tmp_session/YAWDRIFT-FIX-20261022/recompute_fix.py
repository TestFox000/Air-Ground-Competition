# -*- coding: utf-8 -*-
"""Offline recompute for YAWDRIFT-FIX: read lead probe CSV, infer raw gyro
from the current dual-path average, then simulate candidate fixes.

Model from code:
  current dzactuator: Publish_ImuSensor(raw) + Publish_ImuSensor_filter(filtered)
  both call Quaternion_Solution on the same global q, dt=1/100, at 50 Hz.
  => yaw rate = 0.5*(gz_raw + gz_filtered)  [two calls per frame, each adds gz*dt]
  (if one call per frame with dt=1/100 => 0.5*gz; with dt=1/50 => gz)
"""
import csv, math, pathlib, statistics

base = pathlib.Path(r"D:/User/Desktop/比赛存档/v1")
csvp = base/"_tmp_session/LEAD-FIELD-20261022/lead_yaw_probe_2000.csv"
rows=[]
with csvp.open(encoding="utf-8",errors="replace") as f:
    for r in csv.DictReader(f):
        try:
            rows.append({k:float(v) for k,v in r.items()})
        except Exception:
            pass
rows=[r for r in rows if r.get("imu_yaw_deg") is not None]
t=[r["t_s"] for r in rows]
y=[r["imu_yaw_deg"] for r in rows]
gz=[r["gyro_z_dps"] for r in rows]  # actually rad/s

def slope(xs,ys):
    n=len(xs); mx=sum(xs)/n; my=sum(ys)/n
    sxx=sum((x-mx)**2 for x in xs); sxy=sum((x-mx)*(y-my) for x,y in zip(xs,ys))
    b=sxy/sxx
    ss=sum((yy-(my+b*(xx-mx)))**2 for xx,yy in zip(xs,ys))
    st=sum((yy-my)**2 for yy in ys)
    return b, 1-ss/st if st else float("nan")

cur_slope_deg,cur_r2=slope(t,y)
cur_slope_rad=math.radians(cur_slope_deg)
filt_mean=statistics.mean(gz)
raw_i=[2*cur_slope_rad - g for g in gz]   # from current average = 0.5(raw+filt)
raw_mean=statistics.mean(raw_i)
bias0=raw_mean-filt_mean
print("n",len(rows))
print("current imu slope deg/s %.6f R2 %.6f"%(cur_slope_deg,cur_r2))
print("filtered gz mean rad/s %.6f deg/s %.6f"%(filt_mean,math.degrees(filt_mean)))
print("inferred raw mean rad/s %.6f deg/s %.6f"%(raw_mean,math.degrees(raw_mean)))
print("inferred current bias rad/s %.6f deg/s %.6f"%(bias0,math.degrees(bias0)))
print("current dual avg deg/s %.6f"%(math.degrees(0.5*(raw_mean+filt_mean))))

def integrate(rate_deg_s):
    # trapezoid on 1 Hz samples; initial yaw 0
    out=[0.0]
    for i in range(1,len(rows)):
        dt=t[i]-t[i-1]
        out.append(out[-1]+0.5*(rate_deg_s[i-1]+rate_deg_s[i])*dt)
    b,r2=slope(t,out)
    return b,r2,out[-1]

# A: separate q, filtered-only, one call/frame
for dtname,factor in [("dt=1/100 (one call)",0.5),("dt=1/50 (one call)",1.0)]:
    rate=[factor*math.degrees(g) for g in gz]
    b,r2,total=integrate(rate)
    print("A separate filtered-only %s: slope %.6f R2 %.6f total %.3f"%(dtname,b,r2,total))

# B: separate q, raw-only, one call/frame dt=1/50
rate=[math.degrees(g) for g in raw_i]
b,r2,total=integrate(rate)
print("A raw-only dt=1/50: slope %.6f R2 %.6f total %.3f"%(b,r2,total))

# C: separate q + dt=1/50 + static bias update while stationary
for tau in [2.0,5.0]:
    bias=bias0
    rate=[]
    for g_raw in raw_i:
        bias += (1.0-math.exp(-1.0/tau))*(g_raw-bias)
        rate.append(math.degrees(g_raw-bias))
    b,r2,total=integrate(rate)
    print("C separate+dt1/50+bias tau=%.1fs: slope %.6f R2 %.6f total(end) %.3f"%(tau,b,r2,total))

# D: current shared-q with both calls but raw path bias-corrected (same corrected gz both)
# rate = corrected gz (factor 1.0) = filtered
rate=[math.degrees(g) for g in gz]
b,r2,total=integrate(rate)
print("D shared-q both corrected: slope %.6f R2 %.6f total %.3f"%(b,r2,total))
