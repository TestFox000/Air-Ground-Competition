# Yaw 漂移修复设计（YAWDRIFT-FIX-20261022）

> 卡：YAWDRIFT-FIX-20261022｜owner：motion-auditor｜只读源码 + 离线复算；不改 src/config，不部署。
> 依据：_tmp_session/YAWDRIFT-20261022/REPORT.md（120 行，A934F4B8…）、
> _tmp_session/LEAD-FIELD-20261022/lead_yaw_probe_2000.csv、dzactuator.cpp / Quaternion_Solution.cpp/h。
> 台账：D-024（信号坏时调参=开倒车）、D-027（阿克曼、守卫差速前提、先量测再改代码）。
> 产出：PATCH.diff（草稿，未应用）、recompute_fix.py、recompute_result.txt、本报告。

## 0 一句话

共享 q 与 raw/filtered 抵消已钉死；但**只把 raw 路分出去并不能收敛到 0**：
filtered 路单独是 −0.170°/s（dt=1/50）或 −0.085°/s（dt=1/100），比现在的 −0.070 更差。
最小可行修复 = **分离 q + 实测 dt + 静止在线零偏更新**；离线复算 τ=2 s 时 118 s 斜率 **−0.00023°/s**（目标 ±0.005）。

## 1 代码精确位置（核对报告结论）

- 旧共享状态：Quaternion_Solution.cpp:212 的全局 q0..q3；Quaternion_Solution.cpp:214-279 积分/归一化。
- filtered 路：Publish_ImuSensor_filter 在 dzactuator.cpp:534 调 Quaternion_Solution(gx,gy,gz,ax,ay,az)。
- raw 路：Publish_ImuSensor 在 dzactuator.cpp:591 调同一个 Quaternion_Solution(raw gyro/accel)。
- 调用顺序：Control 循环 dzactuator.cpp:1325（raw）→:1326（filtered），同一帧两次写同一 q。
- 零偏：imu_bias_correction dzactuator.cpp:451-499；BIAS_CALIBRATION_SAMPLES=200（dzactuator.h:294）；
  只在 filtered 路 :509,515-517 使用；raw 路 :582-592 用未校正 gz。
- 硬编码 dt：Quaternion_Solution.cpp:255-257 的 1.0f/100；IMU_SAMPLING_FREQ=50（:10）。
- /odom yaw 静止不更新：dzactuator.cpp:1298-1304；serial_reader 选 IMU：serial_reader.py:197-210。
- 固定偏移：serial_reader.py:146-154,236-244；contract.py:133；geometry.py:45。

**核对结论**：报告的双路共享/抵消正确；但报告/任务里“filtered 路本身应接近 0”的隐含前提**不成立**。
实测 filtered gz 均值 −0.17015°/s，raw 反推 +0.02917°/s，当前平均 −0.07049°/s；bias 估计 0.1993°/s。
所以“raw 独立 q”单独做会把 imu_data 斜率变成 −0.085（dt=1/100）或 −0.170（dt=1/50），不是 ±0.005。
若只改 raw 路零偏、仍共享 q，则两路都变 −0.170 量级，更差。

## 2 最小修复设计（PATCH.diff）

三处：
1. Quaternion_Solution.h：新增 QuaternionState（q0..q3）与 Quaternion_Solution_State(..., float dt_s)；保留旧 Quaternion_Solution 兼容包装。
2. Quaternion_Solution.cpp：把原函数改为按 state 操作，dt 参数化（替换 1.0f/100）；旧函数用独立 legacy state + 1/100 保持兼容。
3. dzactuator.cpp：
   - Publish_ImuSensor_filter：static QuaternionState filtered_q；实测 dt（clamp 0.005~0.05 s）；调 State 版；
     并加静止在线零偏：bias_calibrated && !montion_flag && fabs(raw gz)<0.05 时
     gyro_bias_z += 0.01*(raw gz - gyro_bias_z)（50 Hz ⇒ τ≈2 s）。
   - Publish_ImuSensor：static QuaternionState raw_q；同样实测 dt；调 State 版，raw 仍用未校正 gz。
   - 旧 Quaternion_Solution 保留给未迁移调用者；当前两处调用全部迁移。

**副作用/影响面**
- /raw 的 orientation 从“raw+filtered 混合”变成“raw-only”；全树未发现 /raw 订阅者（只有 parser 的 raw 关键字），无控制影响；/raw 的 gyro/accel 字段仍是原始。
- /imu_data 的 orientation 变成 filtered-only；serial_reader 的 map yaw 会随之改变（预期）；/odom/localization 与 [T] 的固定偏移仍是 §1 的 49.8°，本补丁不处理。
- /imu_data.angular_velocity.z 在静止时会随 bias 更新；dzrknn_dataprocess 用它做云台前馈（:1136-1140）。静止时应为 0，运动时 montion_flag=true 冻结 bias；但“轮不转、人慢转/推车”可能被误吸收，需现场验证。
- 启动 200 样本后开始静态 bias；τ=2 s，初始 0.17°/s 误差在 118 s 内累计约 −0.204°（斜率 −0.00023），首 10 s 有约 0.3° 瞬态；若不能接受，可把 τ 降到 1 s 或延长初始校准，但会增大误吸收风险。
- 旧全局 q 删除；twoKi 仍为 0，integralFB* 仍共享；若以后启用积分项，需把 integralFB* 也放进 state（当前不启用）。
- 不改 config；无新参数；alpha/dt 为代码常量，后续可再参数化。

## 3 离线复算（lead_yaw_probe_2000.csv，118 s）

命令：

    cd _tmp_session/YAWDRIFT-FIX-20261022
    python recompute_fix.py

模型：当前 yaw 率 = 0.5(raw+filtered)（两路各一次、50 Hz、dt=1/100）；raw 由当前斜率反推。

| 方案 | 118 s 斜率 | 末态累计 | 判定 |
|---|---:|---:|---|
| 现状（双路共享 q） | −0.07049°/s | — | baseline |
| A：raw 独立 q，filtered-only，dt=1/100 | −0.08516°/s | −9.96° | 更差，fail |
| A：raw 独立 q，filtered-only，dt=1/50 | −0.17032°/s | −19.92° | 更差，fail |
| A：raw-only，dt=1/50 | +0.02933°/s | +3.42° | 变好但 fail |
| 共享 q、两路都用 corrected gz | −0.17032°/s | −19.92° | fail |
| **C：A + dt=1/50 + 静止 bias τ=2 s** | **−0.00023°/s** | **−0.204°** | **pass（±0.005）** |
| C 但 τ=5 s | −0.00154°/s | −0.687° | 斜率 pass，瞬态更大 |

结论：**A/B 单独都不满足目标；必须 C**。τ=2 s 是推荐值（0.01@50 Hz）。

## 4 部署影响面 / 回滚

- 改动文件（仅草稿）：src/dzactuator/include/Quaternion_Solution.h、src/dzactuator/src/Quaternion_Solution.cpp、src/dzactuator/src/dzactuator.cpp。
- 构建：colcon build --packages-select dzactuator（人工，需解冻登记；本卡不执行）。
- 部署：唯一入口 tools/deploy_to_car.py（本卡不部署）；备份车端 install 的 dzactuator 库与源码快照。
- 回滚：恢复上述 3 文件（或车端旧二进制）→ 重新 build → 重启栈；无 config 改动；回滚点 = 部署前 install 备份 + 源码 diff。
- 影响：/imu_data orientation（serial_reader map yaw）、/raw orientation、/imu_data gz（云台前馈）；/odom yaw 不变（仍静止不更新）。
- 风险：静态 bias 误吸收慢速人力转动；montion_flag 只由轮速判定，推车/架空时需额外 gate；温度长期漂移只在静止段收敛。

## 5 上车验证 10 分钟方案（静止 2 min 为核心）

1. 车静止、brain 不跑、det/云台/射击按今晚条件；录 /imu_data、/raw、/odom/localization、/odom 2 min（1 Hz CSV）。
2. 判据：/imu_data orientation 斜率 abs(slope)<0.005°/s 且 R²>0.99；/odom/localization 同斜率；/odom yaw 仍恒定；/raw orientation 允许有 raw 漂移（仅诊断）。
3. 手转 90° 已知角：/imu_data yaw 应变化 90°±2°（若只变 45° ⇒ dt/单路仍错）；转回后静置 30 s 斜率仍 <0.005。
4. 短跑 5 min（0.1 m/s，直线+一个弯）：检查 /imu_data gz 符号/量级、map yaw 无跳变、guard 不误触发、云台前馈无异常。
5. 停机/回滚条件：静置斜率 >0.01°/s、90° 手转误差 >5°、map yaw 跳变 >1°、guard/SAFETY 异常 → 立即回滚旧二进制。
6. 记录：版本/文件 hash、启动后 0/30/60/120 s 的 yaw、斜率、R²、温度（若有）、/raw gz 均值。

## 6 边界 / 未做

- 未改 src；PATCH.diff 只是草稿；未 build/上车/部署；未改 config；未 SSH。
- 未处理 49.8° 固定偏移（另属 serial_reader/初始化帧问题）；未改守卫阈值（D-024/D-027）。
- 未验证 /raw 是否有外部消费者（全树静态 grep 未见）；上线前再 ros2 topic info /raw -v 确认。
- 未验证 montion_flag 在推车/架空/云台振动下的 gate 充分性；这是本补丁最大的现场风险。
