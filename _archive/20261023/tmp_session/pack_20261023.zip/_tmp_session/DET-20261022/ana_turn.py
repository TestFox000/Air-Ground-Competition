import json
rows=[json.loads(l) for l in open('/tmp/snap2/pairs.jsonl') if l.strip()]
det=[r for r in rows if r['cls']>0]
t0=det[0]['t']; t1=det[-1]['t']
print('span %.1fs rows %d fps %.1f'%(t1-t0,len(det),len(det)/(t1-t0)))
# turnarounds: sign change of dx velocity over window
seq=[(r['t']-t0,r['dx']) for r in det]
turn=[]
for i in range(3,len(seq)-3):
    d1=seq[i][1]-seq[i-3][1]; d2=seq[i+3][1]-seq[i][1]
    if d1*d2<0 and abs(d1)>10 and abs(d2)>10:
        turn.append((round(seq[i][0],2),seq[i][1]))
# dedupe close turns
out=[]
for tt in turn:
    if not out or tt[0]-out[-1][0]>0.5: out.append(tt)
print('turns:',out[:12])
if len(out)>=3:
    per=[out[i+1][0]-out[i][0] for i in range(len(out)-1)]
    print('periods:',[round(p,2) for p in per[:10]])
