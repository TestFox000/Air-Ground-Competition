#!/bin/bash
# DET-20261022 · 阈值 A/B（只读 src，复制到 /tmp 再改；不改 dzrobot/src、不改 config）
# 用法：bash ab_det.sh <bag 含 /image_raw> [BOX_THRESH=0.25]
#
# ★安全前置（必须满足，否则脚本直接退出）：
#   1) 停掉云台火控 dzrknn_dataprocess（dzactuator_node）——否则 /offset_center 会让云台动；
#   2) 停掉生产 det_node ——否则它会和 A/B 抢 /image_raw 并把 /offset_center 发给云台；
#   3) 底盘/射击链路不参与本轮。
set -euo pipefail
BAG="${1:?usage: ab_det.sh <bag> [thresh]}"
TH="${2:-0.25}"

if pgrep -f 'dzrknn_dataprocess|dzactuator_node' >/dev/null 2>&1; then
  echo "[ABORT] 云台火控在跑；先停 dzrknn_dataprocess，避免 /offset_center 动云台"; exit 2
fi
if pgrep -f '/det_node --ros-args' >/dev/null 2>&1; then
  echo "[ABORT] 生产 det_node 在跑；先停，避免抢 /image_raw"; exit 2
fi

TS=$(date +%s)
AB="/tmp/det_ab_${TS}"
cp -a ~/dzrobot/src/rknn_pt "$AB"
sed -i "s/#define BOX_THRESH .*/#define BOX_THRESH ${TH}/" "$AB/include/det/postprocess.h"
echo "[1/4] copied to $AB, BOX_THRESH=$TH"
grep -n 'BOX_THRESH' "$AB/include/det/postprocess.h"

cd "$AB"
source /opt/ros/humble/setup.bash
echo "[2/4] colcon build (det_node)"
colcon build --packages-select det_node \
  --build-base "$AB/build" --install-base "$AB/install" \
  --cmake-args -DCMAKE_BUILD_TYPE=Release 2>&1 | tail -8

source "$AB/install/setup.bash"
MODEL="$AB/model/light_det.rknn"
[ -f "$MODEL" ] || MODEL=$(find "$AB/install" -name 'light_det.rknn' | head -1)
echo "[3/4] run A/B det (model=$MODEL, remap /offset_center:=/offset_center_ab)"
ros2 run det_node det_node --ros-args \
  -r __node:=det_node_ab \
  -r /offset_center:=/offset_center_ab \
  -p draw:=false -p max_fps:=30.0 -p model_path:="$MODEL" &
DET=$!
sleep 2
ros2 bag play "$BAG" --topics /image_raw &
PLAY=$!
OUT="/tmp/ab_offset_${TS}.txt"
timeout 90 ros2 topic echo /offset_center_ab > "$OUT" 2>/dev/null || true
wait $PLAY 2>/dev/null || true
sleep 1
kill $DET 2>/dev/null || true
wait $DET 2>/dev/null || true

echo "[4/4] result -> $OUT"
python3 - "$OUT" <<'PY'
import re, sys
p = sys.argv[1]
lines = open(p, encoding='utf-8', errors='replace').read().splitlines()
msgs, i = [], 0
while i < len(lines):
    if lines[i].strip() == 'data:':
        vals, j = [], i + 1
        while j < len(lines) and lines[j].startswith('- '):
            try: vals.append(int(lines[j][2:].strip()))
            except Exception: pass
            j += 1
        if len(vals) >= 5: msgs.append(vals)
        i = j
    else:
        i += 1
if not msgs:
    print('NO MESSAGES (bag/image or det failed)'); sys.exit(1)
det = sum(1 for m in msgs if m[2] in (1, 2) and m[3] > 0)
print(f'n={len(msgs)} det={det} ({100*det/len(msgs):.1f}%) cls0={sum(1 for m in msgs if m[2]==0)}')
PY

cat <<'EOF'
[可选] letterbox A/B（需同时改两处，未在本脚本自动执行）：
  1) rkpt.cc:229 注释掉 resize_rga；:236-239 取消注释（min_scale/pads/letterbox）；
  2) postprocess.cc:79 删除 (void)pads；:154-157 改为 (clamp(b.x1,0,model_in_w)-pads.left)/scale_w 等。
  两处同改才几何正确；只改一处会得到偏移框。
EOF
