import os, sys
p = '/tmp/det1022/rec_pairs.py'
s = open(p, encoding='utf-8').read()
if 'os._exit(0)' in s:
    print('ALREADY_PATCHED'); sys.exit(0)
old_imp = 'import argparse, json, os, time'
if 'import signal' not in s:
    assert old_imp in s, 'import line changed'
    s = s.replace(old_imp, 'import argparse, json, os, signal, time', 1)
old = "            self.get_logger().info(f'结束：收到 {self.n_img} 帧，保存 {self.n_saved}')\n            rclpy.shutdown()"
new = ("            self.get_logger().info(f'结束：收到 {self.n_img} 帧，保存 {self.n_saved}')\n"
       "            try:\n                self.f.flush()\n            except Exception:\n                pass\n"
       "            os._exit(0)")
if old not in s:
    print('PATTERN_MISS'); sys.exit(2)
s = s.replace(old, new, 1)
if 'signal.signal' not in s:
    s = s.replace('    rclpy.init()\n', '    signal.signal(signal.SIGTERM, lambda *_: os._exit(0))\n    rclpy.init()\n', 1)
open(p, 'w', encoding='utf-8').write(s)
print('PATCHED_OK')
