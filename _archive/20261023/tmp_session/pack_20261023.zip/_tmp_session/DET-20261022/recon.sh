#!/bin/bash
source /opt/ros/humble/setup.bash
source /home/duzhong/dzrobot/install/setup.bash
echo "---NODES"
ros2 node list 2>/dev/null
echo "---TOPICS"
ros2 topic list 2>/dev/null | grep -iE "manual|gimbal|aim"
echo "---OFFSET"
timeout 5 ros2 topic echo --once /offset_center 2>/dev/null
echo "---STATUS"
timeout 5 ros2 topic echo --once /aim/status 2>/dev/null
echo "---LEAD"
timeout 5 ros2 topic echo --once /aim/lead_x 2>/dev/null
