#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""只读录制云台自瞄闭环各通道：/offset_center /aim/status /camemo_feedback /CameMo_Conl /aim/lead_x /aim/fire_ready。
用法：python3 rec_aim.py --out /tmp/aimrec.jsonl --dur 90
"""
import argparse, json, time
import rclpy
from rclpy.node import Node
from std_msgs.msg import Int32, Int32MultiArray, Float32, UInt8


class Rec(Node):
    def __init__(self, out, dur):
        super().__init__('aim_rec')
        self.out = out
        self.f = open(out, 'w', encoding='utf-8')
        self.dur = float(dur)
        self.t0 = time.time()
        self.count = 0
        self.create_subscription(Int32MultiArray, '/offset_center', lambda m: self.log('offset', list(m.data)), 20)
        self.create_subscription(Int32, '/aim/status', lambda m: self.log('status', [int(m.data)]), 20)
        self.create_subscription(Int32MultiArray, '/camemo_feedback', lambda m: self.log('fb', list(m.data)), 20)
        self.create_subscription(Int32MultiArray, '/CameMo_Conl', lambda m: self.log('conl', list(m.data)), 20)
        self.create_subscription(Float32, '/aim/lead_x', lambda m: self.log('lead_x', [float(m.data)]), 20)
        self.create_subscription(UInt8, '/aim/fire_ready', lambda m: self.log('fire_ready', [int(m.data)]), 20)
        self.create_timer(0.2, self.tick)
        self.get_logger().info('rec -> %s  %.0fs' % (out, self.dur))

    def log(self, k, v):
        self.f.write(json.dumps({'t': round(time.time(), 4), 'k': k, 'v': v}) + '\n')
        self.f.flush()
        self.count += 1

    def tick(self):
        if time.time() - self.t0 > self.dur:
            self.f.close()
            rclpy.shutdown()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default='/tmp/aimrec.jsonl')
    ap.add_argument('--dur', type=float, default=90.0)
    a = ap.parse_args()
    rclpy.init()
    node = Rec(a.out, a.dur)
    try:
        rclpy.spin(node)
    except Exception:
        pass
    print('done count=%d' % node.count)


if __name__ == '__main__':
    main()
