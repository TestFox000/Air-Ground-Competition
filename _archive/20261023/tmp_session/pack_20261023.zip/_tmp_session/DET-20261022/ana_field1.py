import json, statistics, collections
rows=[]
p='/tmp/pairs_field1/pairs.jsonl'
for line in open(p, encoding='utf-8'):
    line=line.strip()
    if line:
        try: rows.append(json.loads(line))
        except: pass
n=len(rows)
print('rows',n)
if n:
    t0=rows[0]['t']; t1=rows[-1]['t']
    print('span %.1fs fps %.1f'%(t1-t0, n/max(1e-9,t1-t0)))
    det=[r for r in rows if r['cls']>0]
    print('det %d/%d = %.1f%%'%(len(det),n,100*len(det)/n))
    print('cls', dict(collections.Counter(r['cls'] for r in rows)))
    if det:
        dx=[r['dx'] for r in det]; w=[r['w'] for r in det]; dy=[r['dy'] for r in det]
        s=sorted(dx)
        print('dx min/max %d/%d med %d p10 %d p90 %d'%(min(dx),max(dx),statistics.median(dx),s[int(.1*len(s))],s[int(.9*len(s))]))
        print('dy min/max %d/%d med %d'%(min(dy),max(dy),statistics.median(dy)))
        print('w  min/max med %d/%d %d'%(min(w),max(w),statistics.median(w)))
