import json, collections
rows=[json.loads(l) for l in open('_tmp_session/DET-20261022/aimrec_static.jsonl', encoding='utf-8') if l.strip()]
print('rows', len(rows))
kinds=collections.Counter(r['k'] for r in rows); print(kinds)
off=[r for r in rows if r['k']=='offset']
print('offset sample', off[0]['v'] if off else None, 'n', len(off))
