import json, statistics, collections
rows=[json.loads(l) for l in open('_tmp_session/DET-20261022/aimrec_track.jsonl', encoding='utf-8') if l.strip()]
kinds=collections.Counter(r['k'] for r in rows)
print('rows',len(rows),dict(kinds))
t0=rows[0]['t']; t1=rows[-1]['t']
print('span %.1fs'%(t1-t0))
st=[r for r in rows if r['k']=='status']
# status timeline (change points)
prev=None; changes=[]
for r in st:
    v=r['v'][0]
    if v!=prev: changes.append((round(r['t']-t0,2), v)); prev=v
print('status changes:', changes[:40])
st_track=[r for r in st if r['v'][0]==2]
print('status counts:', collections.Counter(r['v'][0] for r in st))
off=[r for r in rows if r['k']=='offset']
det=[r for r in off if len(r['v'])>=5 and r['v'][2] in (1,2)]
print('offset rows', len(off), 'det', len(det), 'rate %.1f%%'%(100*len(det)/len(off) if off else 0))
if det:
    dx=[r['v'][0] for r in det]; dy=[r['v'][1] for r in det]; w=[r['v'][3] for r in det]
    print('dx min/med/max %d/%d/%d'%(min(dx),statistics.median(dx),max(dx)))
    print('dy min/med/max %d/%d/%d'%(min(dy),statistics.median(dy),max(dy)))
    print('w min/med/max %d/%d/%d'%(min(w),statistics.median(w),max(w)))
    print('cls', collections.Counter(r['v'][2] for r in det))
lead=[r['v'][0] for r in rows if r['k']=='lead_x']
print('lead_x n',len(lead),'min/max',(min(lead),max(lead)) if lead else None,'nonzero',sum(1 for v in lead if abs(v)>0.01))
fr=[r['v'][0] for r in rows if r['k']=='fire_ready']
print('fire_ready n',len(fr),'sum',sum(fr) if fr else None)
conl=[r for r in rows if r['k']=='conl']
if conl:
    p1=[r['v'][1] for r in conl if len(r['v'])>1]; p0=[r['v'][0] for r in conl if len(r['v'])>0]
    print('conl Pos0 med/max', statistics.median(p0), max(p0), 'Pos1 med/span', statistics.median(p1), max(p1)-min(p1))
fb=[r for r in rows if r['k']=='fb']
if fb: print('fb sample', fb[0]['v'])
