import json, statistics, collections
rows=[]
for line in open('/tmp/pairs_gimbal120/pairs.jsonl', encoding='utf-8'):
    line=line.strip()
    if line:
        try: rows.append(json.loads(line))
        except: pass
dx=[r['dx'] for r in rows if r['cls']>0]
buckets=collections.Counter()
for v in dx:
    a=abs(v)
    buckets['<=80' if a<=80 else '81-150' if a<=150 else '151-230' if a<=230 else '231-300' if a<=300 else '>300']+=1
tot=sum(buckets.values())
print('dx bucket share:', {k: '%.0f%%'%(100*v/tot) for k,v in buckets.items()})
segs=[]; cur=[]
for i,r in enumerate(rows):
    if r['cls']==0:
        cur.append(i)
    else:
        if cur: segs.append((cur[0],cur[-1]))
        cur=[]
if cur: segs.append((cur[0],cur[-1]))
edge=0; inframe=0; edge_d=[]; inf_d=[]
for a,b in segs:
    prev=rows[a-1] if a>0 else None
    d=b-a+1
    if prev is None: continue
    if abs(prev['dx'])>280 or abs(prev['dy'])>190:
        edge+=1; edge_d.append(d)
    else:
        inframe+=1; inf_d.append(d)
print('miss segs total',len(segs),'edge-exit',edge,'in-frame',inframe)
if inf_d: print('in-frame miss len: n',len(inf_d),'med',statistics.median(inf_d),'max',max(inf_d))
if edge_d: print('edge miss len: n',len(edge_d),'med',statistics.median(edge_d),'max',max(edge_d))
print('in-frame entries (dx,dy,w,dur,t):')
cnt=0
for a,b in segs:
    prev=rows[a-1] if a>0 else None
    if prev is None: continue
    if not(abs(prev['dx'])>280 or abs(prev['dy'])>190):
        print(' ', prev['dx'], prev['dy'], prev['w'], b-a+1, 't=%.1f'%prev['t'])
        cnt+=1
        if cnt>=25: break
jumps=[]
for a,b in segs:
    prev=rows[a-1] if a>0 else None
    nxt=rows[b+1] if b+1<len(rows) else None
    if prev and nxt: jumps.append(abs(nxt['dx']-prev['dx']))
if jumps:
    print('reacquire |d dx| med', statistics.median(jumps), 'p90', sorted(jumps)[int(.9*len(jumps))])
