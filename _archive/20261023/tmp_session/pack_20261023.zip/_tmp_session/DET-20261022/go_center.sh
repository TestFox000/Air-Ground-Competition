#!/bin/bash
set +u
source /opt/ros/humble/setup.bash
source $HOME/.bashrc >/dev/null 2>&1
source /home/duzhong/dzrobot/install/setup.bash
source /home/duzhong/dzrobot/dzros.env
export ROS_DOMAIN_ID=118
# freeze/manual
timeout 2 ros2 topic pub -r 5 /nav/manual_gimbal std_msgs/msg/UInt8 "{data: 1}" >/dev/null 2>&1
# command center pose: [pitch, yaw, spd, spd] ticks
timeout 4 ros2 topic pub -r 20 /CameMo_Conl std_msgs/msg/Int32MultiArray "{data: [2144, 2048, 800, 800]}" >/dev/null 2>&1
echo SENT
sleep 1
cd /tmp/det1022
timeout 20 python3 rec_pairs.py --out /tmp/pairs_k2 --dur 8 --stride 5 >/tmp/rec_k2.log 2>&1
echo RC=$?
tail -1 /tmp/rec_k2.log
