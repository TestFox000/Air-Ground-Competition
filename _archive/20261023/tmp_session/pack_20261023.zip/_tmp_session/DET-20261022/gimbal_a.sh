#!/bin/bash
set +u
source /opt/ros/humble/setup.bash
source /home/duzhong/dzrobot/install/setup.bash
source /home/duzhong/dzrobot/dzros.env
cd /home/duzhong/dzrobot

echo "== pre =="
pgrep -af 'dzactuator_node|dzrknn_dataprocess|usb_cam_node|det_node' | grep -v pgrep | head -10

echo "== scan_request type =="
grep -rn "scan_request" src/dzrknn_dataprocess/src/*.cpp src/dzrknn_dataprocess/include/*.h 2>/dev/null | head -5

if ! pgrep -f 'dzactuator/src/dzactuator_node' >/dev/null 2>&1; then
  setsid ros2 launch dzactuator bringup.launch.py > /tmp/t_chassis.log 2>&1 &
  echo "chassis_started pid=$!"
fi
sleep 9
echo "== chassis log tail =="
tail -6 /tmp/t_chassis.log

if ! pgrep -f 'dzrknn_dataprocess' >/dev/null 2>&1; then
  setsid ros2 launch dzrknn_dataprocess dzrknn_dataprocess.launch.py > /tmp/t_gimbal.log 2>&1 &
  echo "gimbal_started pid=$!"
fi
sleep 9
echo "== gimbal log tail =="
tail -10 /tmp/t_gimbal.log

echo "== topics =="
ros2 topic list 2>/dev/null | grep -E 'offset_center|aim/status|scan_request|image_raw' | head
echo "== procs =="
pgrep -af 'dzactuator_node|dzrknn_dataprocess' | grep -v pgrep | head
