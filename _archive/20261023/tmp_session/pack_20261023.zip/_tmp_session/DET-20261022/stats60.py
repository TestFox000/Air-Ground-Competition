# -*- coding: utf-8 -*-
import json, statistics as st, sys
rows=[json.loads(l) for l in open(r"_tmp_session/DET-20261022/pairs60.jsonl",encoding="utf-8") if l.strip()]
rows.sort(key=lambda r:r["t"])
n=len(rows); t0=rows[0]["t"]; t1=rows[-1]["t"]
det=[r for r in rows if r.get("cls",0) in (1,2) and r.get("w",0)>0]
miss=[r for r in rows if r not in det]
fps=n/(t1-t0)
print(f"frames={n} dur={t1-t0:.1f}s fps={fps:.1f}")
print(f"det={len(det)} ({100*len(det)/n:.1f}%) miss={len(miss)}")
from collections import Counter
print("cls:",Counter(r["cls"] for r in rows))
# runs
def runs(seq):
    out=[];cur=None
    for r in seq:
        ok=r.get("cls",0) in (1,2) and r.get("w",0)>0
        if cur is None or cur[2]!=ok:
            if cur: out.append(cur)
            cur=[r["t"],r["t"],ok,0]
        cur[1]=r["t"]; cur[3]+=1
    if cur: out.append(cur)
    return out
rs=runs(rows)
mu=[x for x in rs if not x[2]]; md=[x for x in rs if x[2]]
print(f"det_runs={len(md)} miss_runs={len(mu)}")
if mu:
    L=[x[3] for x in mu]; print(f"miss_len_frames median={st.median(L)} max={max(L)}")
    Ls=[x[1]-x[0] for x in mu]; print(f"miss_len_s median={st.median(Ls):.3f} max={max(Ls):.3f}")
if md:
    L=[x[3] for x in md]; print(f"det_len_frames median={st.median(L)} max={max(L)}")
# per-1s bins
bins={}
for r in rows:
    b=int(r["t"]-t0)
    bins.setdefault(b,[0,0]); bins[b][1]+=1
    if r.get("cls",0) in (1,2) and r.get("w",0)>0: bins[b][0]+=1
print("per-sec det rate:", " ".join(f"{100*bins[b][0]/bins[b][1]:.0f}" for b in sorted(bins)))
def q(v,p): 
    v=sorted(v); k=(len(v)-1)*p/100; import math; f=int(k); c=min(f+1,len(v)-1); return v[f]+(v[c]-v[f])*(k-f)
for k in ("dx","dy","w","h"):
    v=[r[k] for r in det]
    if v: print(f"{k}: p5={q(v,5):.0f} p50={q(v,50):.0f} p95={q(v,95):.0f} min={min(v)} max={max(v)}")
a5=[r["a5"] for r in det]; a6=[r["a6"] for r in det]; a7=[r["a7"] for r in det]
if a5: print(f"a5: p50={st.median(a5)} a6: p50={st.median(a6)} a7: p50={st.median(a7)}")
