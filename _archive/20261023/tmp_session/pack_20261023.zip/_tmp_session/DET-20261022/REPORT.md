# DET-20261022 · Det 视觉检出率离线归因（只读）

- 日期 2026-10-22｜写域 `_tmp_session/DET-20261022/`｜未改 src/config，未发任何 ROS/云台/电机命令，未部署
- 证据：本地 `car_logs/`（`4_det.log`、`2_camera.log`、`5_gimbal.log`、`dmesg_uvc.txt`、`lsusb.txt`、`find_media.txt`、`ps.txt`、`camera_ctrls.txt`）；D 轮 `docs/_work/TRACK-DAY-20261022/evidence/cam/aim_rec_D.jsonl`、`evidence/d11_1834/cap/offset.txt`；卡面 §11–14
- 脚本：`rec_pairs.py`（车端成对录制）、`analyze_pairs.py`（离线对照）、`ab_det.sh`（阈值/letterbox A/B 草案，不跑 src）

## 0. 先纠正一个包名（影响找文件）

**检测不在 `src/dzrknn_dataprocess/`**：它是 `/offset_center` 的**消费方**（云台火控，cpp:1265 订阅）。真正的检测链是：
`usb_cam /image_raw` → **`src/rknn_pt/src/det_node.cc`**（RKNN，`/offset_center` 发布，det_node.cc:30-33/215-260）→ `dzrknn_dataprocess`（消费）→ `dzbrain/aim.py`。
后处理在 `src/rknn_pt/src/det/postprocess.cc`，预处理在 `src/rknn_pt/src/det/rkpt.cc:205-297`。

## 1. 检测链上所有可能压低检出的门（文件:行号）

| # | 门 | 位置 | 当前值 | 影响 |
|---|---|---|---|---|
| G1 | **置信度阈值** | `include/det/postprocess.h:26` `#define BOX_THRESH 0.4`；过滤 `postprocess.cc:107` | **0.4（编译期宏，无配置键）** | 分数 0.2–0.39 的目标直接丢；**首疑** |
| G2 | NMS 阈值 | `postprocess.h:25` 0.45；`postprocess.cc:39-65,148` | 0.45 | 正常，不是低检出主因 |
| G3 | 最小框 | `postprocess.cc:118` `bw<=1||bh<=1` | 1 px | 实际不拦；无最小目标面积门 |
| G4 | 类别过滤 | `postprocess.h:20` OBJ_CLASS_NUM=2 | blue/red 都保留 | 无类别过滤 |
| G5 | ROI | 无 | — | 全画面 |
| G6 | 跳帧/限帧 | `det_node.cc:62-74` 定时器 33 ms；`rknnPool.hpp:91-111` future 队列**无上限** | 30 fps、8 线程 | 推理慢只会让结果滞后，不丢消息；实测 offset 30.3 Hz ⇒ 非 60.7% 主因 |
| G7 | **预处理拉伸** | `rkpt.cc:216-241`：`resize_rga` 到模型输入（640×640），`pads=0`；**letterbox 被注释**（236-239） | 640×480→640×640，纵向 **1.33×** 拉伸 | 与训练分布不一致；边缘/形状分数下降；**代码级缺陷** |
| G8 | 发布选择 | `det_node.cc:242-260` 循环**覆盖** msg；NMS 后按分数降序（postprocess.cc:41-42/60-65），最后一个是**最低分** | 发布最低分框 | 多框时 cls/bbox 抖动；**不造成无检测** |
| G9 | 相机曝光/格式 | `config/robot.yaml:250-260`：640×480 yuyv 30、brightness 0，**无 exposure/gain**；`2_camera.log:85-86` `Setting 'exposure_auto' to 3` → **unknown control**；`:92-94` `Invalid v4l2 format` 崩溃 | 曝光未受控（驱动默认/自动） | 可能运动模糊/过暗；但 18:34 与 19:37 检出率相同（见 §3）⇒ 不是主因 |
| G10 | 模型 | `light_det.rknn`；输入 640×640（YOLOv8-pose，8400 候选，postprocess.cc:30） | — | 模型自身 recall 未知；无 score 日志 |

> **FIRE 窗口来源更正**：D 的 recorder 是 `evidence/cam/aim_rec2.py`，**订阅了 `/aim/fire_gate`**（:10），所以 `aim_rec_D.jsonl` 有 **11 条 gate**；通用/A-B 旧 recorder 才没有。D 的 gate 区间（最长 14.55–43.45 s）与 `5_gimbal` 5 条 `收到【开火放行】`（2507–2515）、`7_path` L2670→L2820（FIRE→硬死线）**三重交叉一致**。
>
**检测输出**：`det_node.cc:244-258`：`dx=box.center_x-width/2`、`dy=...`、`cls=res.cls+1`、`w/h=box`、`[7]=kpt_conf*100`。**没有检测分数**（score 未进 msg）⇒ 离线无法直接看"分数分布"；需在验证时加日志/加第 9 位。

## 2. 车端只读取证（2026-10-22 20:2x）

- **相机已掉线**：`lsusb.txt` 无 UVC 相机（只剩 hub/2.4G 鼠标/串口/JTAG）；`/dev/video0` 不存在（只有 `video-dec0/enc0`）；`camera_ctrls.txt` 92 B（打不开）。
- **dmesg**（`dmesg_uvc.txt`）：`20:12:12 usb 1-1: USB disconnect` → `1-1.2` → `uvcvideo 1-1.2: Failed to resubmit video URB (-19)`；20:12:13 hub 重枚举、2.4G 鼠标出现在 `1-1.1`，**相机未回来**。⇒ 外部硬件/供电/线缆事件，与 39% 检出率无关。
- **相机启动**：`2_camera.log:11` `Starting 'default_cam' at 640x480 via mmap (yuyv) at 30 FPS`；`:68` 设备支持 **YUYV 640×480@30**；`:92-94` 首次启动抛 `Invalid v4l2 format`（exit -6），之后被 respawn；`:85-86` exposure_auto 控制不存在。
- **det 日志没有检测统计**：`4_det.log` 仅 7 行（启动、draw:false、`waiting for /image_raw`）；`4_det_robot_logs.log` 是 10-21 的 556 B。**没有每帧 det 日志**；唯一 det 证据是 `/offset_center`。
- **无原始帧/无 rosbag**：`find_media.txt` 只有 10-20 的 RealSense 视频（`r2_field_20261020/evidence/*.mp4`）和 navigation2 测试 bag；**10-22 无 jpg/png/mp4/bag**。卡面 §10 的 `video/runA–D.mp4` 是 **RealSense D435if 外拍**，不是 det 的 USB 相机 ⇒ **不能做"原始帧 vs det"**（这就是相机恢复后第一件事）。
- **进程**：`ps.txt` det_node 28209 仍 99% CPU 空转（waiting），dzactuator 28234 在跑；usb_cam 不在（launch 在 2.3 s 重试）。

## 3. D 轮量化（aim_rec_D.jsonl + 18:34 cap）

| 样本 | 帧/消息 | 检出（cls=1/2, w>0） | w 中位 | 说明 |
|---|---:|---:|---:|---|
| D FIRE 14.55–43.45 s | 876 | **344（39.3%）** | **196 px** | 目标近/大 |
| 18:34 单点 cap | 1519 | **569（37%）** | **53 px** | 目标远/小、日落前后 |
| A 轮（19:22） | 2956 | 758（26%） | 94 px | 云台 SCAN |
| B 轮（19:29） | 2576 | 690（27%） | 97 px | 云台 SCAN |

- **bbox 大小不决定检出率**：w=53→37%、94→26–27%、196→39%，非单调；**18:34（w53）与 19:37（w196）检出率几乎相同（37% vs 39%）** ⇒ "目标太小/太远"不是主因。
- **光照/曝光不是主因（削弱）**：18:34（日落前后）与 19:37（夜）检出率 37% vs 39%，差 2 个百分点；`exposure_auto` 未知控制确实没设，但两时段同率 ⇒ 不是主导。
- **帧级闪烁**（关键）：D FIRE 29 s 内 **cls=1 段 85 个、中位 3 帧（0.07 s）、最长 0.43 s**；**cls=0 段 84 个、中位 2 帧（0.03 s）、最长 0.73 s**。检测是"2–3 帧检出、1–2 帧丢失"的**逐帧抖动**，不是"目标离开视野 0.7 s"。这是**分数贴着阈值 0.4** 的典型形态。
- **丢失段 vs bbox/位置**：84 个 cls=0 段前最后一帧 `w` 中位 196、`|dx|` 中位 182；`corr(丢失时长, w) = −0.412`，`corr(丢失时长, |dx|) = +0.465` ⇒ **大 bbox 反而丢得短；|dx| 越大丢得略长**（边缘效应），但相关弱（|r|<0.5），**bbox 不是主因**。
- **云台 yaw**：**未记录**。D jsonl 无 gimbal tick/`CameMo_Conl`；`5_gimbal` 无时间戳；能用的只有 `/aim/status`（FIRE 内 58/58=TRACK，无 SCAN）和 `[T]` 车体 yaw（−42.6→−43.2，30 s 仅 0.6°）。⇒ **"丢失段 vs 云台 yaw"当前不可判**；验证时补录 `/CameMo_Conl` + `/camemo_feedback`。
- **cls 抖动分布**：D FIRE 只有 cls=0/1，**无 cls=2（红）**；A/B 有 cls=2 15/6 帧（误检）。0↔1 的逐帧翻转（85/84 段）是**分数阈值抖动**，不是蓝红混淆。C++ 侧 `cls_switch_confirm_frames=5` 在 2–3 帧检出段里永远攒不满，日志出现 `locked_cls=0`/`类别未确认`；D FIRE 的 `5_gimbal` 末尾能锁到 `locked_cls=1`。
- **39% 最可能的 2–3 个原因（按证据排序）**：
  1. **BOX_THRESH=0.4 + 分数贴阈值**（postprocess.h:26 / postprocess.cc:107）：帧级 2–3 帧检出/1–2 帧丢失；不同距离/时段同率；**score 未记录**是唯一缺口。若把阈值降到 0.2–0.3 能把 39% 拉到 >80%，即实锤。
  2. **预处理拉伸（letterbox 被注释）**（rkpt.cc:216-241）：640×480→640×640 纵向 1.33×，与训练分布不一致；边缘更差（|dx| 相关 +0.465）。需 letterbox A/B 定影响。
  3. **相机—云台负偏置**（dx 中位 −90、最后有效 |dx| 182、13% 贴左边）：把靶的轨道扫掠整体推到左边缘，叠加分数下降；**是贡献项，不是逐帧闪烁的根因**（闪烁在各 |dx| 都出现）。
  4. **发布最低分框**（det_node.cc:242-260）：解释 bbox 94 vs 196、cls 抖动；不解释无检测。

## 4. 相机恢复后 10 分钟验证方案（可直接跑）

**安全前置（硬）**：先停 `dzrknn_dataprocess`（云台火控）与底盘/射击，再只开 `2_camera` + `4_det` + 记录；**否则 det 的 `/offset_center` 会让云台动**，违反本卡边界。相机的 `auto_exposure` 用 `v4l2-ctl` 读/写（先读后写，写前记录原值）。

| 分钟 | 动作 | 命令/脚本 | 判据 |
|---|---|---|---|
| 0–1 | 相机健康、格式、曝光控制 | `ls -l /dev/video0`；`v4l2-ctl -d /dev/video0 --list-formats-ext \| grep -A2 '640x480'`；`v4l2-ctl --list-ctrls \| grep -i exposure` | 有 `YUYV 640×480@30`；有 `auto_exposure`/`exposure_time_absolute` |
| 1–3 | 起相机+det，确认链路 | `ros2 launch dzactuator camera.launch.py`；`ros2 launch det_node det_node.launch.py`；`ros2 topic hz /image_raw`；`ros2 topic hz /offset_center` | 两话题 ≈30 Hz；`/offset_center` 有非零 bbox |
| 3–5 | 成对录制（中心/左端/右端/0.3 m/s） | `python3 rec_pairs.py --out /tmp/pairs --dur 60` | `pairs/pairs.jsonl` + `frame_*.jpg`；每帧带 dx/cls/w/h |
| 5–7 | 离线对照 | `python3 analyze_pairs.py --dir /tmp/pairs` | 输出检出率、闪烁段、**cls=0 且靶在画面内的帧数/占比**、亮度分箱、contact sheet |
| 7–10 | 阈值/letterbox A/B（可选） | `bash ab_det.sh --bag /tmp/pairs_bag --thresh 0.25`（在车端 /tmp 复制源码，不改 src） | 阈值 0.4→0.25 的检出率/闪烁；letterbox 版对比 |

**判据（先写死）**：
- **cls=0 帧里"靶在画面内"占比 >50%** ⇒ 检测器/阈值（G1/G7）；<20% ⇒ 瞄准/云台指向（G9 的偏置），不是 det。
- 阈值 0.4→0.25 后检出率 **>80%** 且误检可接受 ⇒ 主因 G1；若仍 <60% ⇒ 模型/曝光/G7。
- letterbox 版比拉伸版检出率高 **>15 个百分点** ⇒ G7 实锤。
- 亮度分箱（帧均值 <40/40–80/>80）检出率差 >20 个百分点 ⇒ 曝光/光照（G9）。

**脚本**（已落本目录）：
- `rec_pairs.py`：订阅 `/image_raw` + `/offset_center`，逐帧存 JPEG + JSONL（含编码处理 `rgb8/yuv422_yuy2`）。
- `analyze_pairs.py`：离线统计检出率/闪烁/亮度/位置；对 cls=0 帧用前后最近 cls=1 帧插值 bbox，判定"靶在画面内"；生成 contact sheet。
- `ab_det.sh`：车端 `/tmp` 复制 `rknn_pt`，改 `BOX_THRESH`（可选 letterbox），colcon build 到 `/tmp`，用录制的 bag 重放对比；**不碰 src/config**。

## 5. 局限/未做

- 相机 20:12 掉线，**无法实时**；本报告所有 det 结论来自 `/offset_center` 与日志，**无原始帧**。
- 检测 **score 未进 msg**（`data[7]` 是关键点 conf，不是 det score），阈值假设需恢复后补 score 日志/加第 9 位再证。
- 云台 **yaw tick / CameMo_Conl 未录**，"丢失 vs 云台 yaw"当前不可判。
- `video/runA–D.mp4` 是 RealSense 外拍，不是 det 相机；**不能替代原始帧**。
- 未改 src/config、未发 ROS/云台命令、未部署；回滚 = 删 `_tmp_session/DET-20261022/`。
