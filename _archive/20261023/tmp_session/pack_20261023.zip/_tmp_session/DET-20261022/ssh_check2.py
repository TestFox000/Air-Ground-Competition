import paramiko, time
cands = [("192.168.0.4", None), ("duzhong.local", None)]
for host, _ in cands:
    for k in range(2):
        try:
            c = paramiko.SSHClient(); c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            c.connect(host, username="duzhong", password="duzhong", timeout=6, allow_agent=False, look_for_keys=False, banner_timeout=10)
            i,o,e = c.exec_command("hostname; hostname -I; uptime", timeout=10)
            print("OK", host, o.read().decode(errors="replace").strip())
            raise SystemExit
        except SystemExit:
            raise
        except Exception as ex:
            print("FAIL", host, k, str(ex)[:100])
            time.sleep(1)
print("NONE")
