import json, statistics
rows=[json.loads(l) for l in open('_tmp_session/DET-20261022/aimrec_track.jsonl', encoding='utf-8') if l.strip()]
t0=rows[0]['t']
# build series
off={}; conl={}; fb={}; st={}
for r in rows:
    t=round(r['t']-t0,1)
    if r['k']=='offset' and len(r['v'])>=5:
        off[t]=(r['v'][0],r['v'][1],r['v'][2],r['v'][3])
    elif r['k']=='conl' and len(r['v'])>=2:
        conl[t]=(r['v'][0],r['v'][1])
    elif r['k']=='fb' and len(r['v'])>=2:
        fb[t]=(r['v'][0],r['v'][1])
    elif r['k']=='status':
        st[t]=r['v'][0]
# sample every 0.5s nearest
import math
print('t   st  dx  dy cls w   conl0 conl1  fb0 fb1')
for tt in [i*0.5 for i in range(0,60)]:
    def near(d):
        if not d: return None
        k=min(d, key=lambda x:abs(x-tt))
        return d[k] if abs(k-tt)<0.35 else None
    o=near(off); c=near(conl); f=near(fb); s=near(st)
    print('%.1f %s %s %s'%(tt, s, o, c))
