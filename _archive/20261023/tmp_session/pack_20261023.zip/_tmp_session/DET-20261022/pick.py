import json
rows=[]
for line in open('/tmp/pairs_gimbal120/pairs.jsonl', encoding='utf-8'):
    line=line.strip()
    if line:
        try: rows.append(json.loads(line))
        except: pass
def near(t, tol=0.05):
    return [r for r in rows if abs(r['t']-t)<=tol]
# find the 203-frame miss start
segs=[]; cur=[]
for i,r in enumerate(rows):
    if r['cls']==0: cur.append(i)
    else:
        if cur: segs.append((cur[0],cur[-1]))
        cur=[]
if cur: segs.append((cur[0],cur[-1]))
big=[s for s in segs if s[1]-s[0]+1>=100]
print('big segs', [(s[0],s[1],s[1]-s[0]+1, '%.1f'%rows[s[0]]['t']) for s in big][:5])
for s in big[:2]:
    a=s[0]
    for k in [a, a+3, a+30, a+90, a+150, min(s[1],a+200)]:
        if k<len(rows): print('  row', k, rows[k]['frame'], 'cls',rows[k]['cls'],'dx',rows[k]['dx'],'dy',rows[k]['dy'],'w',rows[k]['w'])
# small w frames
small=[r for r in rows if r['cls']>0 and 10<=r['w']<=25][:3]
print('small w frames:', [(r['frame'],r['w'],r['dx'],r['dy']) for r in small])
bigw=max((r for r in rows if r['cls']>0), key=lambda r:r['w'])
print('max w:', bigw['frame'], bigw['w'], bigw['dx'], bigw['dy'])
med=[r for r in rows if r['cls']>0 and 80<=r['w']<=100][:1]
print('median w sample:', [(r['frame'],r['w'],r['dx'],r['dy']) for r in med])
