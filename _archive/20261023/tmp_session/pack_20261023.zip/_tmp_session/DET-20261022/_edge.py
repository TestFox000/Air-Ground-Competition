
import csv
rows=list(csv.DictReader(open("_tmp_session/DET-20261022/move_stats.csv", encoding="utf-8")))
rows=[r for r in rows if r["t"]]
cls=[int(r["cls"]) for r in rows]; dx=[int(r["dx"]) for r in rows]
# find miss runs and the last det dx before them
runs=[]; i=0
while i < len(rows):
    if cls[i]<=0:
        j=i
        while j<len(rows) and cls[j]<=0: j+=1
        last_dx = dx[i-1] if i>0 else None
        runs.append((i, j-i, last_dx))
        i=j
    else: i+=1
print("miss_runs", len(runs))
print("runs with |dx|>220 at entry:", sum(1 for _,_,d in runs if d is not None and abs(d)>220))
print(runs[:20])
# how many frames have |dx|>250 among det
det_dx=[d for c,d in zip(cls,dx) if c>0]
print("det frames", len(det_dx), "|dx|>250:", sum(1 for d in det_dx if abs(d)>250))
