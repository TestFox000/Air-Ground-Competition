#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""离线对照：pairs.jsonl + frame_*.jpg。
输出检出率、闪烁段、亮度分箱、cls=0 且"靶在画面内"的帧数/占比、contact sheet。
用法：python3 analyze_pairs.py --dir /tmp/pairs
不依赖 cv2；只用 PIL + numpy。"""
import argparse, json, statistics as st
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw

def fmt(x, n=2):
    return f'{x:.{n}f}'

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dir', default='/tmp/pairs')
    ap.add_argument('--max-sheet', type=int, default=20)
    a = ap.parse_args()
    d = Path(a.dir)
    rows = [json.loads(l) for l in open(d / 'pairs.jsonl', encoding='utf-8') if l.strip()]
    rows.sort(key=lambda r: r['t'])
    if not rows:
        print('no rows'); return
    im0 = Image.open(d / rows[0]['frame'])
    W, H = im0.size
    det = [r for r in rows if r.get('cls', 0) in (1, 2) and r.get('w', 0) > 0]
    miss = [r for r in rows if r not in det]
    n, nd = len(rows), len(det)
    dt = [rows[i]['t'] - rows[i-1]['t'] for i in range(1, n)]
    fps = 1.0 / st.median(dt) if dt else 0.0
    # 闪烁段
    def runs(seq):
        out, cur = [], None
        for r in seq:
            ok = r in det
            if cur is None or cur[2] != ok:
                if cur: out.append(cur)
                cur = [r['t'], r['t'], ok, 0]
            cur[1] = r['t']; cur[3] += 1
        if cur: out.append(cur)
        return out
    rs = runs(rows)
    det_runs = [x for x in rs if x[2]]
    miss_runs = [x for x in rs if not x[2]]
    # 亮度
    def bright(r):
        try:
            return float(np.asarray(Image.open(d / r['frame']).convert('L'), dtype=np.float32).mean())
        except Exception:
            return float('nan')
    for r in rows:
        r['_b'] = bright(r)
    b_all = [r['_b'] for r in rows if not np.isnan(r['_b'])]
    # 插值：cls=0 帧用前后最近检出帧
    dets = [r for r in rows if r in det]
    def pred_for(i):
        prev = next = None
        for j in range(i - 1, -1, -1):
            if rows[j] in det: prev = rows[j]; break
        for j in range(i + 1, n):
            if rows[j] in det: next = rows[j]; break
        if prev is None and next is None: return None
        if prev is None: return next
        if next is None: return prev
        t = rows[i]['t']
        span = next['t'] - prev['t']
        u = 0.0 if span <= 1e-9 else (t - prev['t']) / span
        return {k: prev[k] + (next[k] - prev[k]) * u for k in ('dx', 'dy', 'w', 'h')}
    in_frame_miss = 0
    partial_miss = 0
    sheet = []
    for i, r in enumerate(rows):
        if r in det: continue
        p = pred_for(i)
        if p is None: continue
        cx, cy = W / 2 + p['dx'], H / 2 + p['dy']
        x1, y1 = cx - p['w'] / 2, cy - p['h'] / 2
        x2, y2 = cx + p['w'] / 2, cy + p['h'] / 2
        inside = (0 <= cx <= W and 0 <= cy <= H)
        overlap = (x2 > 0 and x1 < W and y2 > 0 and y1 < H)
        if inside: in_frame_miss += 1
        elif overlap: partial_miss += 1
        if overlap and len(sheet) < a.max_sheet:
            sheet.append((r, (x1, y1, x2, y2), inside))
    # 亮度分箱检出率
    bins = [(0, 40), (40, 80), (80, 120), (120, 255)]
    print(f'=== {a.dir}: {n} 帧, {fps:.1f} fps, {W}x{H} ===')
    print(f'检出 {nd}/{n} = {100*nd/n:.1f}%  (蓝/红 cls=1/2, w>0)')
    print(f'cls=1 段 {len(det_runs)} 个, 中位 {st.median([x[1]-x[0] for x in det_runs]):.2f}s, 最长 {max(x[1]-x[0] for x in det_runs):.2f}s')
    print(f'cls=0 段 {len(miss_runs)} 个, 中位 {st.median([x[1]-x[0] for x in miss_runs]):.2f}s, 最长 {max(x[1]-x[0] for x in miss_runs):.2f}s')
    print(f'亮度 中位 {st.median(b_all):.1f} (min {min(b_all):.1f} / max {max(b_all):.1f})')
    for lo, hi in bins:
        sub = [r for r in rows if lo <= r["_b"] < hi]
        if not sub: continue
        k = sum(1 for r in sub if r in det)
        print(f'  亮度 {lo:3d}-{hi:3d}: {k}/{len(sub)} = {100*k/len(sub):.1f}%')
    print(f'cls=0 帧中"靶中心仍在画面内"(插值): {in_frame_miss}/{len(miss)} = {100*in_frame_miss/max(len(miss),1):.1f}% of misses; 部分出画 {partial_miss}')
    print('注：插值是前后最近检出帧的线性估计；contact sheet 用于人工确认。')
    # contact sheet
    if sheet:
        cols = 4; rows_n = (len(sheet) + cols - 1) // cols
        tw = 320; th = 240
        sh = Image.new('RGB', (cols * tw, rows_n * th), (30, 30, 30))
        dr = ImageDraw.Draw(sh)
        for k, (r, box, inside) in enumerate(sheet):
            try:
                im = Image.open(d / r['frame']).convert('RGB').resize((tw, th))
            except Exception:
                continue
            dr2 = ImageDraw.Draw(im)
            sx, sy = tw / W, th / H
            x1, y1, x2, y2 = [v * (sx if i % 2 == 0 else sy) for i, v in enumerate(box)]
            dr2.rectangle([x1, y1, x2, y2], outline=(255, 0, 0), width=2)
            dr2.text((4, 4), f"t={r['t']:.2f} cls0 {'IN' if inside else 'EDGE'}", fill=(255, 255, 0))
            sh.paste(im, ((k % cols) * tw, (k // cols) * th))
        out = d / 'sheet.jpg'
        sh.save(out, quality=90)
        print(f'contact sheet -> {out}')
    # 文本落盘
    with open(d / 'analyze.txt', 'w', encoding='utf-8') as f:
        f.write(f'n={n} fps={fps:.1f} det={nd} ({100*nd/n:.1f}%) in_frame_miss={in_frame_miss} partial={partial_miss}\n')
        f.write(f'det_runs={len(det_runs)} miss_runs={len(miss_runs)} bright_med={st.median(b_all):.1f}\n')
    print('analyze.txt written')


if __name__ == '__main__':
    main()
