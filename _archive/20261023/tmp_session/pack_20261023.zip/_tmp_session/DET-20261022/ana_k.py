import json, statistics
rows=[json.loads(l) for l in open('_tmp_session/DET-20261022/pairs_k.jsonl', encoding='utf-8') if l.strip()]
n=len(rows); t0=rows[0]['t']; t1=rows[-1]['t']
print('rows',n,'span %.1fs fps %.1f'%(t1-t0, n/max(1e-9,t1-t0)))
det=[r for r in rows if r['cls']>0]
print('det %d/%d = %.1f%%'%(len(det),n,100*len(det)/n if n else 0))
if det:
    dx=[r['dx'] for r in det]; dy=[r['dy'] for r in det]; w=[r['w'] for r in det]
    print('dx', min(dx), max(dx), 'span', max(dx)-min(dx))
    print('dx med %.0f'%statistics.median(dx), 'p10 %.0f'%sorted(dx)[int(.1*len(dx))], 'p90 %.0f'%sorted(dx)[int(.9*len(dx))])
    print('dy', min(dy), max(dy), 'med %.0f'%statistics.median(dy))
    print('w', min(w), max(w), 'med %.0f'%statistics.median(w))
segs=[]; cur=0
for r in rows:
    if r['cls']==0: cur+=1
    else:
        if cur: segs.append(cur); cur=0
if cur: segs.append(cur)
print('miss segs', len(segs), 'frames', sum(segs))
