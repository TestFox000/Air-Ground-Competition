import re, statistics, sys
vals=[]
cur=[]
for line in open('/tmp/cm.txt', encoding='utf-8', errors='ignore'):
    line=line.strip()
    if line.startswith('- '):
        try: cur.append(int(line[2:]))
        except: pass
        if len(cur)==4:
            vals.append(cur); cur=[]
print('samples', len(vals))
for i,name in enumerate(['Pos0','Pos1','Spd0','Spd1']):
    col=[v[i] for v in vals]
    print(name, 'min', min(col), 'max', max(col), 'med', statistics.median(col), 'span', max(col)-min(col))
