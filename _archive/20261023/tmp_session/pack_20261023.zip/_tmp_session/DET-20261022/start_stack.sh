#!/bin/bash
source /opt/ros/humble/setup.bash
source /home/duzhong/dzrobot/install/setup.bash
cd /tmp/det1022
setsid nohup ros2 launch dzactuator bringup.launch.py > /tmp/det1022/log_bringup.txt 2>&1 &
sleep 4
setsid nohup ros2 launch dzactuator camera.launch.py > /tmp/det1022/log_cam.txt 2>&1 &
sleep 3
setsid nohup ros2 launch det_node det_node.launch.py > /tmp/det1022/log_det.txt 2>&1 &
sleep 3
setsid nohup ros2 launch dzrknn_dataprocess dzrknn_dataprocess.launch.py > /tmp/det1022/log_gimbal.txt 2>&1 &
sleep 5
echo "=== NODES"
ros2 node list 2>/dev/null
echo "=== TOPICS"
ros2 topic list 2>/dev/null | grep -E "offset_center|aim|CameMo|image_raw" | head -12
