import paramiko
c = paramiko.SSHClient(); c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
c.connect("192.168.0.4", username="duzhong", password="duzhong", timeout=8, allow_agent=False, look_for_keys=False)
cmd = r'''
echo ===HOME; ls /home/duzhong | head -20
echo ===FIND; find /home/duzhong /tmp -maxdepth 3 -name 'rec_pairs.py' 2>/dev/null | head
echo ===PAIRS; ls -d /tmp/pairs* 2>/dev/null | head
echo ===PROC; ps -eo args | grep -E 'usb_cam|yolo|dzrknn|camera_node' | grep -v grep | head -6
echo ===WS; ls /home/duzhong/dzrobot/install/setup.bash 2>/dev/null; ls /home/duzhong/*/install/setup.bash 2>/dev/null | head
'''
i,o,e = c.exec_command(cmd, timeout=30)
print(o.read().decode(errors="replace"))
print("ERR:", e.read().decode(errors="replace")[:200])
