
import cv2, numpy as np, glob
files = sorted(glob.glob("_tmp_session/DET-20261022/move_frames/*.jpg"))
for f in files:
    img = cv2.imread(f)
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    for name,(s,v) in {"strict":(150,180),"loose":(80,120)}.items():
        m = cv2.inRange(hsv, np.array([95,s,v]), np.array([135,255,255]))
        n, lab, stats, cent = cv2.connectedComponentsWithStats(m, 8)
        best = max([stats[i,4] for i in range(1,n)], default=0)
        print(f.split("\\")[-1][:28], name, "px_sum", int((m>0).sum()), "max_blob", best)
    print()
