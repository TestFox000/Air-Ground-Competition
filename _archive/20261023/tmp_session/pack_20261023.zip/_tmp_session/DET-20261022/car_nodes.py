import paramiko
c = paramiko.SSHClient(); c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
c.connect("192.168.0.4", username="duzhong", password="duzhong", timeout=8, allow_agent=False, look_for_keys=False)
cmd = r'''
source /opt/ros/humble/setup.bash; source /home/duzhong/dzrobot/install/setup.bash 2>/dev/null
echo ===NODES; timeout 10 ros2 node list 2>/dev/null | head -20
echo ===STARTALL; grep -n -iE 'det|4_' /home/duzhong/dzrobot/start_all.sh 2>/dev/null | head -15
echo ===PROC; ps -eo args | grep -iE 'det|yolo|rknn' | grep -v grep | head -8
'''
i,o,e = c.exec_command(cmd, timeout=35)
print(o.read().decode(errors="replace"))
print("ERR:", e.read().decode(errors="replace")[:300])
