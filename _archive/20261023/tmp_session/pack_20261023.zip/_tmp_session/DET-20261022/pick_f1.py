import json
rows=[json.loads(l) for l in open('/tmp/pairs_field1/pairs.jsonl',encoding='utf-8') if l.strip()]
det=[r for r in rows if r['cls']>0]
print('n',len(rows),'det',len(det))
if det:
    byw=sorted(det,key=lambda r:r['w'])
    for tag,r in [('minw',byw[0]),('medw',byw[len(byw)//2]),('maxw',byw[-1])]:
        print(tag, r['frame'], 'dx',r['dx'],'dy',r['dy'],'w',r['w'],'t=%.1f'%r['t'])
