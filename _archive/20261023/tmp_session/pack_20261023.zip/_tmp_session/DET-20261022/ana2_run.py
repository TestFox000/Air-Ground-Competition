
import paramiko
c=paramiko.SSHClient(); c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
c.connect("192.168.0.4", username="duzhong", password="duzhong", timeout=8, allow_agent=False, look_for_keys=False)
i,o,e=c.exec_command("python3 /tmp/det1022/ana2.py 2>&1 | tail -12", timeout=120)
print(o.read().decode(errors="replace"))
print("ERR", e.read().decode(errors="replace")[:200])
