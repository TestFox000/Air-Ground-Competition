#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""成对录制 /image_raw + /offset_center：每帧存 JPEG + 一行 JSONL。
用法（车端）：python3 rec_pairs.py --out /tmp/pairs --dur 60
只读订阅，不发任何控制命令。"""
import argparse, json, os, time
import numpy as np
import cv2
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from std_msgs.msg import Int32MultiArray
try:
    from cv_bridge import CvBridge
except Exception:
    CvBridge = None


class PairRec(Node):
    def __init__(self, out, dur, stride):
        super().__init__('det_pair_rec')
        self.out = out
        os.makedirs(out, exist_ok=True)
        self.dur = float(dur)
        self.stride = max(1, int(stride))
        self.t0 = time.time()
        self.n_img = 0
        self.n_saved = 0
        self.last_det = None
        self.last_det_t = 0.0
        self.bridge = CvBridge() if CvBridge else None
        self.f = open(os.path.join(out, 'pairs.jsonl'), 'a', encoding='utf-8')
        self.create_subscription(Image, '/image_raw', self.on_img, 10)
        self.create_subscription(Int32MultiArray, '/offset_center', self.on_det, 10)
        self.create_timer(0.5, self.tick)
        self.get_logger().info(f'录制到 {out}，{self.dur:.0f}s，stride={self.stride}')

    def on_det(self, m):
        d = list(m.data)
        if len(d) >= 8:
            self.last_det = d[:8]
            self.last_det_t = time.time()

    def decode(self, m):
        if self.bridge is not None:
            try:
                return self.bridge.imgmsg_to_cv2(m, desired_encoding='bgr8')
            except Exception:
                pass
        raw = np.frombuffer(m.data, dtype=np.uint8)
        if m.encoding in ('yuv422_yuy2', 'yuyv', 'yuv422'):
            row = m.step // 2
            buf = raw.reshape(m.height, row)[:, :m.width * 2].reshape(m.height, m.width, 2)
            return cv2.cvtColor(buf, cv2.COLOR_YUV2BGR_YUY2)
        if m.encoding == 'rgb8':
            return cv2.cvtColor(raw.reshape(m.height, m.step)[:, :m.width * 3].reshape(m.height, m.width, 3), cv2.COLOR_RGB2BGR)
        raise RuntimeError(f'unsupported encoding {m.encoding}')

    def on_img(self, m):
        self.n_img += 1
        if (self.n_img - 1) % self.stride != 0:
            return
        t = time.time()
        try:
            img = self.decode(m)
        except Exception as e:
            self.get_logger().warn(f'decode failed: {e}')
            return
        fn = f'frame_{int((t - self.t0) * 1000):08d}.jpg'
        cv2.imwrite(os.path.join(self.out, fn), img, [cv2.IMWRITE_JPEG_QUALITY, 90])
        det = self.last_det if (self.last_det is not None and t - self.last_det_t <= 0.05) else [0] * 8
        row = {'t': round(t, 4), 'frame': fn, 'enc': m.encoding,
               'dx': int(det[0]), 'dy': int(det[1]), 'cls': int(det[2]),
               'w': int(det[3]), 'h': int(det[4]), 'a5': int(det[5]),
               'a6': int(det[6]), 'a7': int(det[7])}
        self.f.write(json.dumps(row, ensure_ascii=False) + '\n')
        self.f.flush()
        self.n_saved += 1
        if self.n_saved % 100 == 0:
            self.get_logger().info(f'saved {self.n_saved}')

    def tick(self):
        if time.time() - self.t0 >= self.dur:
            self.get_logger().info(f'结束：收到 {self.n_img} 帧，保存 {self.n_saved}')
            rclpy.shutdown()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default='/tmp/pairs')
    ap.add_argument('--dur', type=float, default=60.0)
    ap.add_argument('--stride', type=int, default=1, help='每 N 帧存 1 帧（30fps/2=15fps）')
    a = ap.parse_args()
    rclpy.init()
    n = PairRec(a.out, a.dur, a.stride)
    try:
        rclpy.spin(n)
    except KeyboardInterrupt:
        pass
    finally:
        try:
            n.f.close()
        except Exception:
            pass
        n.destroy_node()


if __name__ == '__main__':
    main()
