import json
rows=[json.loads(l) for l in open('/tmp/pairs_field1/pairs.jsonl',encoding='utf-8') if l.strip()]
det=[r for r in rows if r['cls']>0]
print('det rows chronological (t_rel,dx,dy,w):')
t0=rows[0]['t']
for i,r in enumerate(det):
    if i%6==0:
        print('%.1f  dx%5d dy%5d w%3d'%(r['t']-t0,r['dx'],r['dy'],r['w']))
