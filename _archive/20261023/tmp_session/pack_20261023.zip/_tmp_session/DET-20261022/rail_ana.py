import json, statistics
rows=[json.loads(l) for l in open('_tmp_session/DET-20261022/pairs_rail.jsonl', encoding='utf-8') if l.strip()]
n=len(rows); print('rows',n,'span %.1fs'%(rows[-1]['t']-rows[0]['t']) if n>1 else '')
det=[r for r in rows if r['cls']>0]
print('det %d/%d'%(len(det),n))
if det:
    print('w min/med/max', min(r['w'] for r in det), statistics.median([r['w'] for r in det]), max(r['w'] for r in det))
    print('dx min/max', min(r['dx'] for r in det), max(r['dx'] for r in det))
    print('dy min/med/max', min(r['dy'] for r in det), statistics.median([r['dy'] for r in det]), max(r['dy'] for r in det))
rates=[]
for i in range(1,n):
    if rows[i]['cls']>0 and rows[i-1]['cls']>0:
        dt=rows[i]['t']-rows[i-1]['t']
        if 0.02<dt<0.5: rates.append(abs(rows[i]['dx']-rows[i-1]['dx'])/dt)
if rates:
    print('dx rate px/s: med %.0f p90 %.0f max %.0f'%(statistics.median(rates), sorted(rates)[int(.9*len(rates))], max(rates)))
    for k in (600,640,660):
        print('  k=%d -> v=%.2f m/s'%(k, statistics.median(rates)/k))
# timeline sample
for i in range(0, n, max(1,n//12)):
    r=rows[i]
    print('  t=%.1f cls=%d dx=%d dy=%d w=%d'%(r['t'],r['cls'],r['dx'],r['dy'],r['w']))
