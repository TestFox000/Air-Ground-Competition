import json, statistics
rows=[json.loads(l) for l in open('/tmp/pairs_gimbal120/pairs.jsonl', encoding='utf-8') if l.strip()]
segs=[]; cur=[]
for i,r in enumerate(rows):
    if r['cls']==0: cur.append(i)
    else:
        if cur: segs.append((cur[0],cur[-1]))
        cur=[]
if cur: segs.append((cur[0],cur[-1]))
big=[s for s in segs if s[1]-s[0]+1>=60]
print('miss segs >=60 frames:', len(big), 'total frames', sum(s[1]-s[0]+1 for s in big))
for s in big:
    a=s[0]; prev=rows[a-1] if a>0 else None
    print('  dur',s[1]-s[0]+1,'start t=%.1f'%rows[a]['t'],'entry dx,dy,w:', (prev['dx'],prev['dy'],prev['w']) if prev else None)
# losses with entry w>=60 (carriage-scale) vs small
wbig=[s for s in segs if s[0]>0 and rows[s[0]-1]['w']>=60]
wsmall=[s for s in segs if s[0]>0 and rows[s[0]-1]['w']<60]
print('segs entry w>=60:', len(wbig), 'frames', sum(s[1]-s[0]+1 for s in wbig))
print('segs entry w<60 :', len(wsmall), 'frames', sum(s[1]-s[0]+1 for s in wsmall))
