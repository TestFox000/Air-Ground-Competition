import paramiko
c = paramiko.SSHClient(); c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
c.connect("duzhong.local", username="duzhong", password="duzhong", timeout=8, allow_agent=False, look_for_keys=False)
cmd = "ps -eo pid,comm,args | grep -E 'usb_cam|yolo|det|dzactuator|camera' | grep -v grep | head -10; echo ===; source /opt/ros/humble/setup.bash; source ~/dzrobot/install/setup.bash 2>/dev/null; timeout 6 ros2 topic list 2>/dev/null | grep -iE 'image_raw|offset_center|det' "
i,o,e = c.exec_command(cmd, timeout=20)
print(o.read().decode(errors='replace'))
print('ERR', e.read().decode(errors='replace')[:300])
