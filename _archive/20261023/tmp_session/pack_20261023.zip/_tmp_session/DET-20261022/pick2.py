import json
rows=[json.loads(l) for l in open('/tmp/pairs_gimbal120/pairs.jsonl', encoding='utf-8') if l.strip()]
segs=[]; cur=[]
for i,r in enumerate(rows):
    if r['cls']==0: cur.append(i)
    else:
        if cur: segs.append((cur[0],cur[-1]))
        cur=[]
if cur: segs.append((cur[0],cur[-1]))
sel=[s for s in segs if s[0]>0 and rows[s[0]-1]['w']>=60]
print('n',len(sel))
out=[]
for s in sel:
    a=s[0]; prev=rows[a-1]
    out.append((prev['frame'],a,s[1]-s[0]+1,prev['w'],prev['dx'],prev['dy'],'%.1f'%prev['t']))
for o in out[:30]: print(o)
