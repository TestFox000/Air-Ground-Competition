import json, sys, statistics, collections
rows=[]
for line in open('/tmp/pairs_gimbal120/pairs.jsonl', encoding='utf-8'):
    line=line.strip()
    if not line: continue
    try: rows.append(json.loads(line))
    except: pass
n=len(rows)
print('rows',n)
if not n: sys.exit(0)
t0=rows[0]['t']; t1=rows[-1]['t']
print('span %.1fs fps %.1f'%(t1-t0, n/max(1e-9,(t1-t0))))
det=[r for r in rows if r['cls']>0]
print('det %d / %d = %.1f%%'%(len(det), n, 100*len(det)/n))
cls=collections.Counter(r['cls'] for r in rows)
print('cls dist', dict(cls))
dx=[r['dx'] for r in det]; dy=[r['dy'] for r in det]; w=[r['w'] for r in det]
if dx:
    s=sorted(dx)
    print('dx min/med/max %d/%d/%d  p10/p90 %d/%d'%(min(dx),statistics.median(dx),max(dx),s[int(.1*len(dx))],s[int(.9*len(dx))]))
    print('dy min/med/max %d/%d/%d'%(min(dy),statistics.median(dy),max(dy)))
    print('w min/med/max %d/%d/%d'%(min(w),statistics.median(w),max(w)))
segs=[]; cur=0
for r in rows:
    if r['cls']==0: cur+=1
    else:
        if cur: segs.append(cur)
        cur=0
if cur: segs.append(cur)
print('miss_segs', len(segs))
if segs:
    lens=sorted(segs); c=collections.Counter(segs)
    print('miss len min/med/p90/max', lens[0], statistics.median(lens), lens[int(.9*len(lens))], lens[-1])
    print('len<=3:',sum(v for k,v in c.items() if k<=3),' 4-15:',sum(v for k,v in c.items() if 4<=k<=15),' >15:',sum(v for k,v in c.items() if k>15))
entries=[]
for i,r in enumerate(rows):
    if r['cls']==0 and i>0 and rows[i-1]['cls']>0:
        entries.append(rows[i-1]['dx'])
print('dx_before_loss(first 30):', entries[:30])
