#!/bin/bash
source /opt/ros/humble/setup.bash
source /home/duzhong/dzrobot/install/setup.bash
source /home/duzhong/dzrobot/dzros.env
echo "DOMAIN=$ROS_DOMAIN_ID"
ros2 node list 2>/dev/null
timeout 4 ros2 topic hz /offset_center 2>&1 | head -2
rm -rf /tmp/pairs_field1
python3 /tmp/det1022/rec_pairs.py --out /tmp/pairs_field1 --dur 25 --stride 1 > /tmp/det1022/rec_field1.log 2>&1
tail -2 /tmp/det1022/rec_field1.log
python3 /tmp/det1022/ana_field1.py 2>&1
