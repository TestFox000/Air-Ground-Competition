
import paramiko
c=paramiko.SSHClient(); c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
c.connect("192.168.0.4", username="duzhong", password="duzhong", timeout=8, allow_agent=False, look_for_keys=False)
cmd = r'''
grep -n -A2 -iE 'gimbal|dzactuator' /home/duzhong/dzrobot/start_all.sh | head -30
echo ===
grep -n -B2 -A6 'spawn()' /home/duzhong/dzrobot/start_all.sh | head -40
'''
i,o,e=c.exec_command(cmd, timeout=25)
print(o.read().decode(errors="replace"))
print("ERR", e.read().decode(errors="replace")[:200])
