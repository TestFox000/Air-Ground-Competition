
import json, os, cv2, numpy as np, statistics
d="/tmp/pairs_move"
rows=[json.loads(l) for l in open(d+"/pairs.jsonl")]
res=[]
for r in rows:
    img=cv2.imread(os.path.join(d,r["frame"]))
    if img is None: continue
    hsv=cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    m=cv2.inRange(hsv, np.array([90,60,60]), np.array([140,255,255]))
    area=int((m>0).sum())
    res.append((r["t"],r["frame"],r["cls"],area))
areas=sorted(x[3] for x in res)
print("N",len(res),"AREA p10/p50/p90", areas[len(areas)//10], areas[len(areas)//2], areas[9*len(areas)//10])
thr=300
present=[x for x in res if x[3]>=thr]; absent=[x for x in res if x[3]<thr]
tp=[x for x in present if x[2]>0]; fn=[x for x in present if x[2]<=0]
fp=[x for x in absent if x[2]>0]
print("PRESENT",len(present),"TP",len(tp),"FN",len(fn),"RATE %.4f"%(len(tp)/max(1,len(present))))
print("ABSENT",len(absent),"FP",len(fp))
runs=[]; run=0
for x in res:
    if x[3]>=thr and x[2]<=0: run+=1
    else:
        if run: runs.append(run); run=0
if run: runs.append(run)
print("FN_RUNS",len(runs),"MAX",max(runs) if runs else 0,"MED",statistics.median(runs) if runs else 0)
print("FP_RUNS", sum(1 for x in fp))
