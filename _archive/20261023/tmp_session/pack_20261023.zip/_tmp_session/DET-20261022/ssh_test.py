import paramiko, sys
hosts = ["duzhong.local", "192.168.137.79"]
pws = ["duzhong", "0d000721", "orangepi"]
for h in hosts:
    for pw in pws:
        try:
            c = paramiko.SSHClient()
            c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            c.connect(h, username="duzhong", password=pw, timeout=5, allow_agent=False, look_for_keys=False)
            i,o,e = c.exec_command("hostname; hostname -I")
            print("OK", h, pw, o.read().decode(errors="replace").strip())
            sys.exit(0)
        except Exception as ex:
            print("FAIL", h, pw, str(ex)[:80])
print("NONE")
