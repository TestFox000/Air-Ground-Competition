
import paramiko
c=paramiko.SSHClient(); c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
c.connect("192.168.0.4", username="duzhong", password="duzhong", timeout=8, allow_agent=False, look_for_keys=False)
cmd = r'''
ls /tmp/pairs_move 2>/dev/null | wc -l
cat /tmp/pairs_move/stats.csv 2>/dev/null | head -2
python3 /tmp/det1022/ana_move.py 2>&1 | tail -12
'''
i,o,e=c.exec_command(cmd, timeout=60)
print(o.read().decode(errors="replace"))
print("ERR", e.read().decode(errors="replace")[:300])
