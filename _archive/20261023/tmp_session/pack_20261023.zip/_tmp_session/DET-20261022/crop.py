import json, cv2
rows=[json.loads(l) for l in open('/tmp/snap2/pairs.jsonl') if l.strip()]
det=[r for r in rows if r['cls']>0]
# pick extreme left, mid, extreme right
mn=min(det,key=lambda r:r['dx']); mx=max(det,key=lambda r:r['dx'])
mid=min(det,key=lambda r:abs(r['dx']))
for name,row in [('left',mn),('mid',mid),('right',mx)]:
    img=cv2.imread('/tmp/snap2/'+row['frame'])
    cx,cy=320+row['dx'],240+row['dy']
    x0,y0=max(0,cx-90),max(0,cy-90)
    crop=img[y0:y0+180, x0:x0+180]
    crop=cv2.resize(crop,(360,360),interpolation=cv2.INTER_NEAREST)
    out='/tmp/snap2/crop_%s.jpg'%name
    cv2.imwrite(out,crop)
    print(name,row['frame'],'dx',row['dx'],'w',row['w'],'->',out)
