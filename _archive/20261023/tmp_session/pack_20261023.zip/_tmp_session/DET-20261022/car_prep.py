import paramiko, sys
c = paramiko.SSHClient(); c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
c.connect("192.168.0.4", username="duzhong", password="duzhong", timeout=8, allow_agent=False, look_for_keys=False)
sftp = c.open_sftp()
try:
    sftp.stat("/home/duzhong/det_probe/rec_pairs.py")
    print("rec_pairs: exists")
except IOError:
    sftp.put("_tmp_session/DET-20261022/rec_pairs.py", "/home/duzhong/det_probe/rec_pairs.py")
    print("rec_pairs: uploaded")
cmd = "ps -eo args | grep -E 'usb_cam|yolo|det_node|dzrknn|dzactuator' | grep -v grep | head -8; echo ===TOPICS; source /opt/ros/humble/setup.bash; source /home/duzhong/dzrobot/install/setup.bash 2>/dev/null; timeout 8 ros2 topic list 2>/dev/null | grep -iE 'image_raw|offset_center'"
i,o,e = c.exec_command(cmd, timeout=25)
print(o.read().decode(errors="replace"))
print("ERR:", e.read().decode(errors="replace")[:200])
