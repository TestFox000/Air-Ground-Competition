#!/bin/bash
set +u
source /opt/ros/humble/setup.bash
source /home/duzhong/dzrobot/install/setup.bash
source /home/duzhong/dzrobot/dzros.env
cd /tmp/det1022
rm -rf /tmp/pairs_gimbal120
python3 rec_pairs.py --out /tmp/pairs_gimbal120 --dur 120 --stride 1 > /tmp/pairs_gimbal120.log 2>&1
echo RC=$?
tail -2 /tmp/pairs_gimbal120.log
echo COUNT=$(ls /tmp/pairs_gimbal120 2>/dev/null | wc -l)
