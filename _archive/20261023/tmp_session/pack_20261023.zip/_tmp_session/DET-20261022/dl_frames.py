
import paramiko, csv, os
c=paramiko.SSHClient(); c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
c.connect("192.168.0.4", username="duzhong", password="duzhong", timeout=8, allow_agent=False, look_for_keys=False)
sftp=c.open_sftp()
base="_tmp_session/DET-20261022/"
sftp.get("/tmp/pairs_move/stats.csv", base+"move_stats.csv")
sftp.get("/tmp/pairs_move/pairs.jsonl", base+"move_pairs.jsonl")
rows=list(csv.DictReader(open(base+"move_stats.csv", encoding="utf-8")))
det=[r for r in rows if int(r["cls"])>0]
nod=[r for r in rows if int(r["cls"])<=0]
pick_det=[det[i] for i in (50,300,600,900)]
pick_nod=[nod[i] for i in (5, min(40,len(nod)-1), min(120,len(nod)-1), min(200,len(nod)-1))]
os.makedirs(base+"move_frames", exist_ok=True)
for i,r in enumerate(pick_det):
    sftp.get("/tmp/pairs_move/"+r["frame"], base+"move_frames/det_%d_%s"%(i,r["frame"]))
for i,r in enumerate(pick_nod):
    sftp.get("/tmp/pairs_move/"+r["frame"], base+"move_frames/nodet_%d_%s"%(i,r["frame"]))
print("DET:", [(r["frame"],r["dx"],r["dy"],r["w"],r["blur"]) for r in pick_det])
print("NODET:", [(r["frame"],r["dx"],r["dy"],r["w"],r["blur"]) for r in pick_nod])
