#!/bin/bash
set +u
source /opt/ros/humble/setup.bash
source $HOME/.bashrc >/dev/null 2>&1
source /home/duzhong/dzrobot/install/setup.bash
source /home/duzhong/dzrobot/dzros.env
export ROS_DOMAIN_ID=118
timeout 2 ros2 topic pub -r 5 /nav/manual_gimbal std_msgs/msg/UInt8 "{data: 0}" >/dev/null 2>&1
sleep 2
cd /tmp/det1022
python3 rec_aim.py --out /tmp/aimrec_track.jsonl --dur 30
echo RC=$?
wc -l /tmp/aimrec_track.jsonl
