# -*- coding: utf-8 -*-
import json,re,statistics as st
from collections import Counter
from pathlib import Path
W=Path(r'D:\User\Desktop\比赛存档\v1')
# 1) 18:34 offset echo parse
p=W/'docs/_work/TRACK-DAY-20261022/evidence/d11_1834/cap/offset.txt'
lines=p.read_text(encoding='utf-8',errors='replace').splitlines()
msgs=[]; i=0
while i<len(lines):
    if lines[i].strip()=='data:':
        vals=[]; j=i+1
        while j<len(lines) and lines[j].startswith('- '):
            try: vals.append(int(lines[j][2:].strip()))
            except: pass
            j+=1
        if len(vals)>=8: msgs.append(vals)
        i=j
    else: i+=1
cls=Counter(m[2] for m in msgs); valid=[m for m in msgs if m[2] in (1,2) and m[3]>0]
print("=== 18:34 offset cap: n",len(msgs),"cls",dict(cls),"valid",len(valid),f"({100*len(valid)/max(len(msgs),1):.0f}%)")
if valid:
    print("  w med",st.median([m[3] for m in valid]),"h med",st.median([m[4] for m in valid]),"dx med",st.median([m[0] for m in valid]),"|dx| p50/p90",st.median([abs(m[0]) for m in valid]),sorted([abs(m[0]) for m in valid])[int(.9*(len(valid)-1))])
# 2) D jsonl
ev=[json.loads(l) for l in open(W/'docs/_work/TRACK-DAY-20261022/evidence/cam/aim_rec_D.jsonl',encoding='utf-8') if l.strip()]
T0=ev[0]['t']; gates=[(e['t'],int(e['v'])) for e in ev if e['k']=='/aim/fire_gate']
ints=[]; s=None
for t,v in gates:
    if v==1 and s is None: s=t
    elif v==0 and s is not None: ints.append((s,t)); s=None
if s is not None: ints.append((s,max(e['t'] for e in ev)))
a,b=max(ints,key=lambda x:x[1]-x[0])
off=[e for e in ev if e['k']=='/offset_center' and a<=e['t']<=b]
# cls runs
runs=[]; cur=None
for e in off:
    c=int(e['v'][2])
    if cur is None or cur[2]!=c:
        if cur: runs.append(cur)
        cur=[e['t'],e['t'],c,0]
    cur[1]=e['t']; cur[3]+=1
if cur: runs.append(cur)
print("\n=== D FIRE cls runs ===")
print("  n",len(runs),"cls0 runs",sum(1 for r in runs if r[2]==0),"cls1 runs",sum(1 for r in runs if r[2]==1))
for c in (0,1):
    rr=[r for r in runs if r[2]==c]
    if rr: print(f"  cls{c}: n={len(rr)} dur med={st.median([r[1]-r[0] for r in rr]):.2f}s max={max(r[1]-r[0] for r in rr):.2f}s frames med={st.median([r[3] for r in rr])}")
# last valid before cls=0, run length vs w/|dx|
idxs={id(e):i for i,e in enumerate(off)}
rows=[]
for k,r in enumerate(runs):
    if r[2]!=0: continue
    # find index of run start
    i=next((i for i,e in enumerate(off) if e['t']>=r[0]),None)
    if not i or i==0: continue
    v=off[i-1]['v']
    if int(v[2]) in (1,2) and v[3]>0:
        rows.append((r[1]-r[0],v[3],v[0],v[4]))
print("\n=== loss run vs last-valid bbox ===")
print("  n",len(rows))
if rows:
    ws=[x[1] for x in rows]; ds=[abs(x[2]) for x in rows]
    print("  last w med",round(st.median(ws)),"|dx| med",round(st.median(ds)))
    medw=st.median(ws)
    lo=[x[0] for x in rows if x[1]<=medw]; hi=[x[0] for x in rows if x[1]>medw]
    print(f"  run dur: w<=med {st.mean(lo):.2f}s (n={len(lo)}) vs w>med {st.mean(hi):.2f}s (n={len(hi)})")
    # pearson
    def corr(a,b):
        ma,mb=st.mean(a),st.mean(b); return sum((x-ma)*(y-mb) for x,y in zip(a,b))/((sum((x-ma)**2 for x in a)*sum((y-mb)**2 for y in b))**0.5)
    print("  corr(dur,w)=",round(corr([x[0] for x in rows],ws),3),"corr(dur,|dx|)=",round(corr([x[0] for x in rows],ds),3))
# A/B rates
for f in ('aim_rec_A.jsonl','aim_rec_B.jsonl'):
    evv=[json.loads(l) for l in open(W/'docs/_work/TRACK-DAY-20261022/evidence/cam'/f,encoding='utf-8') if l.strip()]
    o=[e for e in evv if e['k']=='/offset_center']
    v=[e for e in o if int(e['v'][2]) in (1,2) and e['v'][3]>0]
    print(f"\n{f}: n={len(o)} valid={len(v)} ({100*len(v)/max(len(o),1):.0f}%) w med={st.median([e['v'][3] for e in v]) if v else 0}")
