import json
rows=[json.loads(l) for l in open('/tmp/snap2/pairs.jsonl') if l.strip()]
n=len(rows); det=[r for r in rows if r['cls']>0]
print('rows',n,'det',len(det),'%.1f%%'%(100*len(det)/n))
print('cls',{c:sum(1 for r in rows if r['cls']==c) for c in (0,1,2)})
if det:
    dx=[r['dx'] for r in det]; dy=[r['dy'] for r in det]; w=[r['w'] for r in det]
    print('dx min/max',min(dx),max(dx),'range',max(dx)-min(dx))
    print('dy min/max',min(dy),max(dy)); print('w min/max',min(w),max(w))
    # dx trend every 20th det
    seq=[r['dx'] for r in det]
    print('dx seq20:', seq[::20][:40])
    seqw=[(r['dx'],r['w'],r['cls']) for r in det]
    print('sample:', seqw[::40][:20])
    # speed: median abs frame-to-frame dx change
import statistics
if det:
    d=[abs(det[i]['dx']-det[i-1]['dx']) for i in range(1,len(det))]
    print('|ddx| median', statistics.median(d) if d else None)
