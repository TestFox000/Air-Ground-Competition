from PIL import Image
import numpy as np
im = np.array(Image.open(r'_tmp_session/DET-20261022/snap1/frame_last.jpg').convert('RGB')).astype(int)
r,g,b = im[:,:,0],im[:,:,1],im[:,:,2]
mask = (b>110)&(b-r>50)&(b-g>30)
ys,xs = np.nonzero(mask)
print('blue px', len(xs))
if len(xs):
    print('bbox x', xs.min(), xs.max(), 'w=', xs.max()-xs.min()+1, ' y', ys.min(), ys.max(), 'h=', ys.max()-ys.min()+1)
    core = (b>220)&(g>150)&(r>80)
    ys2,xs2 = np.nonzero(core)
    if len(xs2): print('core w=', xs2.max()-xs2.min()+1, 'h=', ys2.max()-ys2.min()+1, 'n=', len(xs2))
# also look at pixel values around the disc center for a sense of saturation
