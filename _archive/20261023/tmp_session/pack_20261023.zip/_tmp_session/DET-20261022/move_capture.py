
import paramiko, os, json
HOST="192.168.0.4"; USER="duzhong"; PW="duzhong"
c=paramiko.SSHClient(); c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
c.connect(HOST, username=USER, password=PW, timeout=10, allow_agent=False, look_for_keys=False)
sftp=c.open_sftp()

ana = r'''
import json, statistics, os, cv2
d="/tmp/pairs_move"
rows=[json.loads(l) for l in open(d+"/pairs.jsonl")]
out=[]; last=(320,240)
for r in rows:
    img=cv2.imread(os.path.join(d,r["frame"]), cv2.IMREAD_GRAYSCALE)
    if img is None: continue
    if r["cls"]>0:
        cx,cy=320+r["dx"],240+r["dy"]; last=(cx,cy)
    else:
        cx,cy=last
    x0=max(0,min(img.shape[1]-80,int(cx-40))); y0=max(0,min(img.shape[0]-80,int(cy-40)))
    crop=img[y0:y0+80,x0:x0+80]
    blur=float(cv2.Laplacian(crop,cv2.CV_64F).var()) if crop.size else 0.0
    out.append((r["t"],r["frame"],r["cls"],r["dx"],r["dy"],r["w"],r["h"],round(blur,1)))
with open(d+"/stats.csv","w") as f:
    f.write("t,frame,cls,dx,dy,w,h,blur\n")
    for o in out: f.write(",".join(map(str,o))+"\n")
n=len(out); det=[o for o in out if o[2]>0]; nod=[o for o in out if o[2]<=0]
print("ROWS %d DET %d RATIO %.4f"%(n,len(det),len(det)/max(1,n)))
if det: print("BLUR_DET_MED %.1f"%statistics.median([o[7] for o in det]))
if nod: print("BLUR_NODET_MED %.1f"%statistics.median([o[7] for o in nod]))
segs=[]; run=0
for o in out:
    if o[2]<=0: run+=1
    else:
        if run: segs.append(run); run=0
if run: segs.append(run)
print("MISS_SEGS %d MAXRUN %d MEDRUN %s"%(len(segs), max(segs) if segs else 0, statistics.median(segs) if segs else 0))
if det:
    print("DX_MED %.1f DY_MED %.1f W_MED %.1f"%(statistics.median([o[3] for o in det]), statistics.median([o[4] for o in det]), statistics.median([o[5] for o in det])))
'''
open("_tmp_session/DET-20261022/_ana_tmp.py","w").write(ana)
sftp.put("_tmp_session/DET-20261022/_ana_tmp.py","/tmp/det1022/ana_move.py")
os.remove("_tmp_session/DET-20261022/_ana_tmp.py")

cmd = r'''
source /opt/ros/humble/setup.bash; source /home/duzhong/dzrobot/install/setup.bash; source /home/duzhong/dzrobot/dzros.env
cd /tmp/det1022
rm -rf /tmp/pairs_move
timeout 70 python3 rec_pairs.py --out /tmp/pairs_move --dur 40 --stride 1 > /tmp/pairs_move.log 2>&1
tail -3 /tmp/pairs_move.log
python3 /tmp/det1022/ana_move.py 2>&1 | tail -20
'''
i,o,e=c.exec_command(cmd, timeout=150)
print(o.read().decode(errors="replace"))
print("ERR", e.read().decode(errors="replace")[:300])
try:
    sftp.get("/tmp/pairs_move/stats.csv", "_tmp_session/DET-20261022/move_stats.csv")
    sftp.get("/tmp/pairs_move/pairs.jsonl", "_tmp_session/DET-20261022/move_pairs.jsonl")
    print("DOWNLOADED ok")
except Exception as ex:
    print("DL FAIL", ex)
