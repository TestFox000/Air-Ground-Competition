# 联网事实来源（全部访问于 2026-10-23，本机时区 Asia/Shanghai）

| # | 来源 | 关键事实（原文要点） |
|---|------|----------------------|
| 1 | https://github.com/airockchip/rknn-toolkit2 （README） | RKNN-Toolkit2 在 PC 上把训练模型转成 RKNN，板上用 Runtime/C API 推理；**支持平台含 RK3588 系列**；支持 Python 3.6–3.12；README 标注 **Latest version: v2.5.0** |
| 2 | https://github.com/airockchip/rknn-toolkit2/releases | 版本线：v2.3.2（新增 RV1126B、自动混合精度、图优化）、v2.3.0（**RKNN-Toolkit2 support ARM64 architecture**、Lite2 支持 pip）、v1.6.0（**Support ONNX model of OPSET 12~19**） |
| 3 | https://pypi.org/project/rknn-toolkit2/ | 仅支持 **Ubuntu 18.04 / 20.04 / 22.04 / 24.04**；wheel 为 manylinux，**x86_64 与 aarch64 双架构**；当前 2.5.0 |
| 4 | https://pypi.org/pypi/rknn-toolkit2/json | 2.3.2 的发行文件：cp36/37/38/39/310/311/312 ×（x86_64 / aarch64），共 14 个 wheel；无 Windows wheel |
| 5 | https://docs.ultralytics.com/integrations/rockchip-rknn/ | 官方 RKNN 导出教程，在 **RK3588（Radxa Rock 5B）** 实测；"RKNN export supports **all seven Ultralytics tasks**"（含 pose）；INT8-only 平台需 quantize=8；**导出必须在 x86 Linux 上做，ARM64 不支持**（指 Ultralytics 封装） |
| 6 | https://github.com/airockchip/rknn_model_zoo/tree/main/examples/yolov8_pose | 官方 pose 例程：convert.py 用法 fp/i8；支持平台 RK3562/3566/3568/3576/**RK3588**/RV1126B；C 例程只支持 8bit，混合量化分两步 |

## 与本任务直接相关的结论

- RK3588 属于官方一等支持平台；ONNX opset 12 在支持区间（1.6.0+ 支持 12–19）。
- 转换工具**没有 Windows wheel**，只有 Linux（x86_64 或 aarch64）；本机 pip 探测 No matching distribution（见 commands_env.log）。
- 车端 runtime 是 2.3.2（见 02），**转换应锁 rknn-toolkit2==2.3.2**：新工具链编译出的模型版本可能高于 2.3.2 runtime 能接受的上限（模型中带 compiler/version 字段，runtime 启动时会校验）。
- Ultralytics 封装导出不支持 ARM64，但 Rockchip 原生 toolkit 自 2.3.0 起提供 aarch64 wheel ⇒ 在车上跑原生转换是"可行但非官方推荐"的备选路径。
