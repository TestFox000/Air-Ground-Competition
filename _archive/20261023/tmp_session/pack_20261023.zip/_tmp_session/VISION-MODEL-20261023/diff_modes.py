# -*- coding: utf-8 -*-
import json, os
rows = json.load(open(r"D:/User/Desktop/比赛存档/v1/_tmp_session/VISION-MODEL-20261023/eval_frames.json", encoding="utf-8"))
by = {}
for r in rows: by.setdefault(r["path"], {})[r["mode"]] = r
print("path | letterbox | stretch")
for p, d in by.items():
    l = d.get("letterbox", {}); s = d.get("stretch", {})
    ld = [(x["cls"], x["score"]) for x in l.get("detections", [])]
    sd = [(x["cls"], x["score"]) for x in s.get("detections", [])]
    if bool(ld) != bool(sd) or (ld and abs(ld[0][1]-sd[0][1]) > 0.05):
        print(os.path.basename(p), l.get("group"), ld, "|", sd, "| maxL", l.get("stats",{}).get("max_cls_score"), "maxS", s.get("stats",{}).get("max_cls_score"))
