# WSL 本地实跑记录：ONNX → RKNN(FP16) 与模拟器对齐（2026-10-23）

- 目的：在**不上车、不改 det_node、不部署**的前提下，把 `target_pose_v2_20261016.onnx` 真正转成车端可用的 `.rknn`，并证明转换没有改变模型行为。
- 结论：**转换成功**，产物 `models/target_pose_v2_20261016_fp16.rknn`（8,125,813 B），头部与现役 `light_det.rknn` 逐项同构，RKNN 模拟器 5 帧输出与 ONNX **IoU 0.995–0.998 / 分数差 ≤0.0002**；负样本 0 误检。唯一未验的是 RK3588 NPU 上的真实时延。

## 1. 环境（实测）

| 项 | 值 |
|---|---|
| WSL | 3.0.3.0，Ubuntu 26.04.1 LTS（用户 testfox111，已加入 sudo） |
| 内核 / CPU / 内存 | 6.18.54.1-1-microsoft-standard-WSL2 ｜ x86_64 ｜ 20 vCPU / 14 GB / 955 GB 可用 |
| Python | 3.12.15（Miniconda `/home/testfox111/miniconda3/envs/rknn`） |
| rknn-toolkit2 | **2.3.2**（`rknn_toolkit2-2.3.2-cp312-cp312-manylinux_2_17_x86_64.whl`，38,826,270 B，sha256 `504d7fcf…41ef`） |
| 依赖 | numpy 1.26.4 ｜ onnx **1.16.1** ｜ onnxruntime 1.26.0 ｜ torch 2.4.0(CPU) ｜ opencv 4.11.0 ｜ setuptools 70.0.0 |
| 网络 | pypi 走清华镜像（~2 MB/s）；GitHub wheel 经本机 127.0.0.1:7892 代理下载（~330 KB/s） |

## 2. 完整步骤（可复跑）

```bash
# WSL 内（一次性环境）
sudo apt-get update && sudo apt-get install -y patchelf
# Miniconda（清华镜像）+ py3.12 env
bash ~/wsl/Miniconda3-latest-Linux-x86_64.sh -b -p ~/miniconda3
~/miniconda3/bin/conda create -y -n rknn python=3.12
~/miniconda3/envs/rknn/bin/pip install --no-deps ~/wsl/rknn_toolkit2-2.3.2-cp312-*.whl
~/miniconda3/envs/rknn/bin/pip install "numpy==1.26.4" "onnx==1.16.1" "onnxruntime" "opencv-python-headless" \
  "protobuf<=4.25.4" psutil ruamel.yaml scipy tqdm fast-histogram "setuptools==70.0.0" -i https://pypi.tuna.tsinghua.edu.cn/simple
~/miniconda3/bin/conda install -y -n rknn -c https://mirrors.tuna.tsinghua.edu.cn/anaconda/cloud/conda-forge pytorch=2.4.0 "numpy<1.27"
patchelf --clear-execstack ~/miniconda3/envs/rknn/lib/python3.12/site-packages/torch/lib/libtorch_cpu.so
# 转换（scripts: ~/wsl/convert_fp16.py，与仓库 tools/ml/rknn_convert.py --no-quant 同参）
~/miniconda3/envs/rknn/bin/python ~/wsl/convert_fp16.py
```

## 3. 踩坑（每条都实际发生并已解决）

1. **WSL 首次启动挂起**：Ubuntu 26.04 的 OOBE `/usr/lib/wsl/wsl-setup` 在等"创建用户名"输入，非交互调用 `wsl.exe` 全挂（`/proc` 里见 3 个 `/init` + `wsl-setup`）；预置用户 + `wsl --terminate` 后恢复。
2. **PyPI 上 `rknn-toolkit2` 只有 1.4.9 空壳包**（1,290 B）——真 wheel 在 GitHub `airockchip/rknn-toolkit2` 仓库 `packages/x86_64/`；v2.3.2 与 v2.5.0 都有，选 2.3.2 对齐车端 runtime。
3. **onnx 1.22 报 `module 'onnx' has no attribute 'mapping'`**（toolkit2 2.3.2 仍用旧 API）→ 钉 onnx 1.16.1。
4. **conda-forge pytorch 2.4.0 的 `libtorch_cpu.so` 带可执行栈**，WSL 下 `ImportError: cannot enable executable stack` → `patchelf --clear-execstack` 解决。
5. **缺 pkg_resources**（rknn env 无 setuptools）→ `setuptools==70.0.0`。
6. `init_runtime()` 不能配 `load_rknn`（报 "not support inference on the simulator"）→ 必须 `load_onnx + build` 后在同一进程里 `init_runtime()`。

## 4. 产物与头部核对

| 项 | 值 |
|---|---|
| 文件 | `models/target_pose_v2_20261016_fp16.rknn`，**8,125,813 B**（现役 light_det.rknn 8,487,541 B） |
| sha256 | `2659d1617d9b050f187fc5a203a120e6e5672e1ab7194f833b96903f9befe7f2` |
| compiler | `2.3.2 (e045de294f@2025-04-07T19:48:25)` —— 与现役模型**逐字相同** |
| target / source | rk3588 / ONNX |
| 输入 | `images [1,3,640,640] float32`，mean `[0,0,0]`、std `[255,255,255]`、rgb2bgr False |
| 输出 | `output0 [1,9,8400]` float32（static_shape: float16 NCHW） |
| 量化 | `quant_tab` 的 scale/zero_point/qtype 全空，全文件无 `int8`/`w8a8` ⇒ **FP16 未量化，与现役一致** |

## 5. 模拟器对齐（RKNN Toolkit2 模拟器，非 NPU）

5 张真实车端帧（move_frames/snap1 蓝面，ONNX 分数 0.957–0.965）：

| 帧 | 类一致 | IoU | 分数差 | max\|Δ\|（9×8400 原始张量） |
|---|---|---|---|
| det_2_frame_00024396 | ✅ | 0.9962 | 0.0000 | 3.56 |
| det_0_frame_00001713 | ✅ | 0.9964 | 0.0000 | 2.78 |
| det_3_frame_00037466 | ✅ | 0.9969 | 0.0000 | 3.24 |
| snap1/frame_last | ✅ | 0.9953 | 0.0002 | 1.08 |
| det_1_frame_00011519 | ✅ | 0.9984 | 0.0001 | 2.42 |

- 输出形状 `[1,9,8400]`，解码（4 bbox + 2 类 + 3 kpt，conf 0.4 / NMS 0.45）与 ONNX 完全同构。
- 平均绝对差 0.055（多数落在低置信度通道），b-tensor 高位差异来自 fp16 舍入。
- x86 模拟器单帧 263–475 ms，**不代表 RK3588 NPU 时延**。

## 6. 负样本（RKNN 模拟器复测）

| 样本 | 最高蓝分 | 最高红分 | >0.4 单元 | 结论 |
|---|---|---|---|---|
| neg_blue_bucket.jpg | 0.0003 | 0.0667 | 0 | 不误检 |
| neg_buckets_row.jpg | 0.0449 | 0.0001 | 0 | 不误检 |
| neg_red_bucket.jpg | 0.0 | 0.0001 | 0 | 不误检 |
| neg_red_bucket2.jpg | 0.0 | 0.0 | 0 | 不误检 |
| neg_bucket_illus.jpg（规则图） | 0.0002 | 0.0 | 0 | 不误检 |

## 7. 必须如实说明的边界

1. **转换字节不可复现**：同一 ONNX+同参数连转 3 次，sha256 各不相同（大小同为 8,125,813 B），二进制差 1,742 B、分 414 段（集中在头部 1.7–2.1 KB 与少量后段，疑似地址/时间戳类元数据）。功能等价，但**分发要以 sha256 钉版**，不能假设"重转即同文件"。
2. **没有 NPU 数据**：模拟器是 x86 浮点仿真，RK3588 上真实帧率、算子是否落 CPU、内存峰值均未测。
3. **未上车**：未覆盖现役 `light_det.rknn`、未跑 `test_rknn.py`、未验证 `librknnrt 2.3.2` 实际加载（编译器字符串一致，风险低但非零）。
4. **转换工具版本敏感**：2.3.2 产物配 2.3.2 runtime；若换 2.5.0 工具链，需确认车端 runtime ≥2.5.0，否则可能拒载。
5. 本记录只动 WSL 与 `_tmp_session`，未改生产代码、未部署到车、未写 docs/。

## 8. 证据文件

- `08_convert_fp16_log.txt`：完整转换日志（verbose）
- `08_wsl_toolchain.txt`：环境版本
- `09_sim_verify.json`：5 帧 ONNX vs RKNN 模拟器逐帧对比
- `10_negative_rknn_sim.json`：负样本模拟器结果
- `models/target_pose_v2_20261016_fp16.rknn`：转换产物（可直接拷到车上测试）
- `12_rknn_vs_onnx.jpg`：同一帧 ONNX(绿) vs RKNN 模拟器(黄) 框对比，分数 0.9649 vs 0.9648
- `commands_wsl.log`：本轮 WSL 命令与退出码
- WSL 侧脚本：`/home/testfox111/wsl/{convert_fp16.py,sim_verify.py,neg_sim.py}`
