# -*- coding: utf-8 -*-
import onnx, json
p = r"D:/User/Desktop/air_ground_最新视觉识别模型_20261023/target_pose_v2_20261016.onnx"
m = onnx.load(p)
print("ir_version", m.ir_version)
print("producer", m.producer_name, m.producer_version)
print("opset", [(o.domain or "ai.onnx", o.version) for o in m.opset_import])
for i in m.graph.input:
    dims = [d.dim_value if d.HasField("dim_value") else d.dim_param for d in i.type.tensor_type.shape.dim]
    print("INPUT", i.name, dims, "elem", i.type.tensor_type.elem_type)
for o in m.graph.output:
    dims = [d.dim_value if d.HasField("dim_value") else d.dim_param for d in o.type.tensor_type.shape.dim]
    print("OUTPUT", o.name, dims, "elem", o.type.tensor_type.elem_type)
print("metadata", {p.key: p.value for p in m.metadata_props})
print("n_nodes", len(m.graph.node))
opset_types = {}
for n in m.graph.node:
    opset_types[n.op_type] = opset_types.get(n.op_type, 0) + 1
print("top_ops", sorted(opset_types.items(), key=lambda kv: -kv[1])[:15])
