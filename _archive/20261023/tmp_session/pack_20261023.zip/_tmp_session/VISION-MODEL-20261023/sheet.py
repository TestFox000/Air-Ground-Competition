# -*- coding: utf-8 -*-
import cv2, numpy as np, json, os
base = r"D:/User/Desktop/比赛存档/v1/_tmp_session/VISION-MODEL-20261023"
rows = json.load(open(base + "/eval_frames.json", encoding="utf-8"))
det = [r for r in rows if r["mode"] == "letterbox" and r.get("detections")]
det.sort(key=lambda r: -max(d["score"] for d in r["detections"]))
def draw(path, r):
    im = cv2.imdecode(np.fromfile(path, dtype=np.uint8), cv2.IMREAD_COLOR)
    for d in r["detections"]:
        color = (255, 120, 0) if d["cls"] == 0 else (0, 0, 255)
        cv2.rectangle(im, (int(d["x1"]), int(d["y1"])), (int(d["x2"]), int(d["y2"])), color, 2)
        cv2.putText(im, ("BLUE" if d["cls"]==0 else "RED")+f" {d['score']:.2f}", (int(d["x1"]), max(12,int(d["y1"])-5)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1)
        cv2.circle(im, (int(d["kpt"][0]), int(d["kpt"][1])), 3, (0,255,0), -1)
    return im
sel = det[:12]; tw, th, cols = 320, 240, 3
rn = (len(sel)+cols-1)//cols
sheet = np.full((rn*th, cols*tw, 3), 255, np.uint8)
for i, r in enumerate(sel):
    im = cv2.resize(draw(r["path"], r), (tw, th))
    y, x = (i//cols)*th, (i%cols)*tw
    sheet[y:y+th, x:x+tw] = im
    cv2.putText(sheet, os.path.basename(r["path"])[:30], (x+4, y+18), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0,0,0), 1)
ok, buf = cv2.imencode(".jpg", sheet, [cv2.IMWRITE_JPEG_QUALITY, 88])
buf.tofile(base + "/det_contact.jpg")
print("wrote", os.path.getsize(base + "/det_contact.jpg"))
