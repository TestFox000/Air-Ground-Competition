# VISION-MODEL-20261023 · 车端视觉换包可行性验证

- 日期 2026-10-23 ｜ 写域 `_tmp_session/VISION-MODEL-20261023/` ｜ 只读验证：未改生产代码、未部署、未连车（车/无人机当前不在同一网段：本机 192.168.0.5，dzrobot/dzsmart 均超时）。**20:19 补测：已在本机 WSL(Ubuntu 26.04) 完成 ONNX→RKNN 转换并用模拟器对齐（§3a / 11_wsl_local_test.md）**
- 验证对象：`D:\User\Desktop\air_ground_最新视觉识别模型_20261023`

## 0. 结论（先给判定）

| 问题 | 判定 |
|---|---|
| 能否换成新包？ | **GO（有条件）**：ONNX 契约与现役 det_node 逐项对齐；**ONNX→RKNN 已在本地 WSL 实跑成功**（FP16 8,125,813 B，模拟器与 ONNX IoU 0.995–0.998，见 §3a）。只差车上验证 |
| 契约是否兼容？ | **兼容**。输入 [1,3,640,640] float32 → 输出 [1,9,8400] float32；9 = 4 bbox + 2 类(0=蓝,1=红) + 1 关键点(x,y,conf)；mean 0 / std 255 与现役 RKNN 头部一致；opset 12、batch 1、无动态轴 |
| 转换路径 + 耗时 | **已实跑（WSL2 Ubuntu 26.04）**：Miniconda py3.12 + `rknn-toolkit2 2.3.2`(cp312 wheel) + 同参脚本，环境约 6 min（一次性）、**转换 2.5 s**、产物 8,125,813 B。详见 §3a / 11_wsl_local_test.md |
| 实测检出 | 113 张车端真实帧：蓝面 100%（cap_t 90/90，分数 0.93–0.94）；红面仅规则照片可测（0.507）〔未〕真车红面帧 |
| 下一步最小动作 | ①备份现役 rknn ②覆盖同名文件（hot_reload 1 s 内生效，否则重启 det_node）③车上 `test_rknn.py` 验 output0=[1,9,8400] ④一帧真图对 `/offset_center`，失败即回滚 |

## 1. 事实底座核对（与 Lead 口径的差异）

- 模型包**实际 6 个模型文件**（不是 8 个）：格号分类器 v4c_ft / v4d、hbb 7cls / d13 各 2，light_det.rknn 1，target_pose_v2 1；另有 README.md、说明.txt、2 个 current 指针。
- `light_det.rknn` md5 = `49f3700590a907994e7ee20e4d30cc13`（8,487,541 B），与 README 登记表、`dzrobot_v2/src/rknn_pt/model/light_det.rknn` **三方同哈希** ⇒ "同一份"成立。
- **说明.txt 已过期**：它写 current 指针是 7cls_distill / v4c_ft，但同目录指针文件实际是 `hbb_detector_d13_20261016.onnx` / `cell_classifier_v4d_20261015.onnx`；README 登记表也已有 d13/v4d 行（10-17）。以**指针文件 + README** 为准。
- 车端 det 链新东西确实只有 `target_pose_v2_20261016.onnx`（YOLO11n-pose 640，README 标注"升级 light_det.rknn 链路"，训练负样本含红桶/车身空标签）。

## 2. 契约实测（ONNX 直读 + CPU 推理）

ONNX 元数据：producer pytorch 2.8.0 / ultralytics 8.4.174，opset 12，input `images [1,3,640,640]` float32，output `output0 [1,9,8400]` float32，
names `{0:'blue glowing target', 1:'red glowing target'}`，`kpt_shape [1,3]`，batch=1、dynamic=False、simplify=True。

车端契约（`dzrobot_v2/src/rknn_pt/`）：
- `include/det/postprocess.h:11-19`：OBJ_CLASS_NUM=2、KPT_NUM=1、KPT_DIM=3 ⇒ num_cols = 4+2+3 = **9**
- `src/det/postprocess.cc:88-91`：cls_offset=4、kpt_offset=6、has_kpt = num_cols>=9；bbox 按 cx,cy,w,h 已解码、**不再做 sigmoid/DFL**
- `src/det/rkpt.cc:265-281`：num_preds=最大维(8400)、num_cols=n_elems/num_preds(9)，**换类别数不用改代码**
- `src/det_node.cc:247`：`msg.data[2]=res.cls+1` ⇒ 1=蓝、2=红；`include/det/postprocess.h:14` labels={blue_target, red_target}
- 消费端 `dzrknn_dataprocess.cpp:40,331-333`：`is_target_cls=(data[2]==1||2)`、`fire_only_blue_ 时 locked_cls==1` ⇒ **类序 0=蓝/1=红 必须一致**

实测输出：bbox 为像素尺度（w 最大 330）、类分数在 [0,1]、kpt 为 0..640 像素、kpt conf 0..1 ⇒ **ONNX 已内置 sigmoid 与 DFL 解码**，与 C++ 后处理假设一致（见 01_onnx_contract.txt）。
类别边距（04_class_margin.txt）：蓝面帧 blue=0.93~0.96 / red=0.0000；红面照片 blue=0.0004 / red=0.507 ⇒ 类间分数分离极干净，**新模型有望消掉旧模型的 1↔2 类抖动**（据 DET-20261022 归因，旧模型抖动根因是分数贴阈值）。

## 3. 本机工具链盘点（命令与退出码见 commands_env.log）

| 项 | 结果 |
|---|---|
| Python | 3.12.10（仅一个解释器） |
| onnxruntime | 1.31.0（CPU）✅ 1.23.2 onnx ✅ numpy 2.5.3 ✅ cv2 5.0.0 |
| WSL | ✅ **Ubuntu 26.04.1 LTS（WSL 3.0.3.0 / kernel 6.18.54.1）**，转换已在此完成（§3a） |
| Docker | ❌ 不存在（`docker: command not found`） |
| rknn-toolkit2 | Windows 不可装（无 manylinux wheel）→ **✅ WSL 内 2.3.2 已装并实跑**；PyPI 同名包 1.4.9 是 1,290 B 空壳，真 wheel 在 GitHub `airockchip/rknn-toolkit2` |
| 硬件 | x86_64 Windows；车端 librknnrt.so 为 **AArch64**、version **2.3.2** |

⇒ Windows 原生不可能完成转换；**WSL 内已完成**（§3a）。

## 3a. 本地转换实跑（WSL2 Ubuntu 26.04，2026-10-23 20:19）

- 环境：Python 3.12.15（Miniconda）｜rknn-toolkit2 **2.3.2**（cp312 wheel 38,826,270 B，sha256 504d7fcf…）｜onnx **1.16.1**（1.22 缺 `onnx.mapping`）｜onnxruntime 1.26.0｜numpy 1.26.4｜torch 2.4.0 CPU（conda-forge，需 `patchelf --clear-execstack`）｜opencv 4.11
- 命令：`rknn.config(mean=[[0,0,0]], std=[[255,255,255]], target_platform='rk3588')` + `load_onnx` + `build(do_quantization=False)` + `export_rknn`；日志 `08_convert_fp16_log.txt`，步骤见 `11_wsl_local_test.md` §2
- 产物：`models/target_pose_v2_20261016_fp16.rknn` **8,125,813 B**，sha256 `2659d161…e7f2`；头部 compiler **2.3.2 (e045de294f@2025-04-07T19:48:25)** 与现役逐字相同、target rk3588、mean 0/std 255、output0 `[1,9,8400]`、quant_tab 全空（FP16）
- 模拟器对齐（5 帧真图）：类一致、IoU **0.9953–0.9984**、分数差 ≤0.0002、max|Δ|≤3.6（均值 0.056）
- 负样本（5 张）：最高蓝分 0.045 / 红分 0.067，**0 帧 >0.4**
- 注意：转换**字节不可复现**（3 次 sha 不同、1,742 B/414 段差异，功能等价）⇒ 分发以 sha256 钉版

## 4. 转换配置（已按此实跑；为什么是 FP16 + 2.3.2）

- 由现役 `light_det.rknn` 头部解出（02_baseline_rknn_header.txt）：compiler 2.3.2 / target rk3588 / mean 0、std 255 / `quant_tab` 全空、无 int8 ⇒ **现役是 FP16 未量化**；新模型必须同配：`config(mean_values=[[0,0,0]], std_values=[[255,255,255]], target_platform='rk3588')` + `build(do_quantization=False)`。
- 仓库现成脚本 `tools/ml/rknn_convert.py --no-quant`（在 gitee 快照 `_tmp_session/gitee_ag/main/tools/ml/`），config 与基线逐字一致；本次 WSL 用同参脚本 `~/wsl/convert_fp16.py`。
- 版本必须 2.3.2：车端 runtime 2.3.2，模型头带 compiler/version，2.5.0 等新工具链产物可能被旧 runtime 拒载。
- 产物 8.13 MB（现役 8,487,541 B；新模型 2,721,454 参数，FP16 权重 5.44 MB + 图开销），实测落在预期区间。
- 车上 aarch64 venv 备选仍可用（cp310 wheel 存在），但已无必要。

## 5. 实测检出（113 张真实车端帧，阈值 conf 0.4 / NMS 0.45 = det_node 默认）

| 组 | letterbox 命中 | 说明 |
|---|---|---|
| cap_t | **90/90，分数 0.930–0.939** | 同一静止场景连续采样（框 53–55px），有效样本≈1 场景 |
| move_frames det_* | 4/4，0.957–0.965 | 蓝面近距 ~95px |
| move_frames nodet_* | 1/4 | 唯一命中的是**旧模型漏检、目标只露左缘**的帧；另 3 帧画面里确实无靶 |
| gframes | 2/8 | 2 帧有靶均检出（0.952 / 0.682，后者贴右缘、kpt conf 0.03）；无靶 6 帧 0 检出 |
| snap1 / ffield | 2/3 / 0/4 | snap1 有靶帧 0.501/0.959；ffield 全是地面无靶 |

**letterbox vs stretch（车端 rkpt.cc 实际用 stretch 拉伸，letterbox 被注释）**：113 帧中结果仅 1 帧翻转（4:3→1:1 拉伸对边缘残影略敏感），cap_t 平均最高分 0.934 vs 0.936 ⇒ **车端现用的 stretch 预处理对新模型没有实质损失**，无需改预处理代码。
关键点一致性：cap_t 关键点距框中心 7.9% 对角长（中位），kpt conf≈1.0；贴边帧 kpt 会落到画外（kpt conf 0.03），但下游 `dzrknn_dataprocess` 只消费 data[0..4]，**未用关键点**，不影响当前链路。

## 6. 负样本（"水桶不被判成蓝靶"）

| 样本 | 最高类分数 | 结论 |
|---|---|---|
| 蓝桶裁剪（3 色桶同框帧） | 0.064 | 不判 |
| 3 色桶整行裁剪 | 0.045 | 不判 |
| 红桶裁剪 ×2 | 0.000 | 不判 |
| 规则图"清理桶"插图（红/绿/蓝桶） | 0.0002 | 不判 |
| 含桶整帧（3 帧） | 只出靶 1 框 | 不判桶 |

唯一例外：把桶行裁成 540×110 长条再 stretch 到 640×640（极端 5:1 变形）会出 2 个蓝靶假框（0.91/0.88）；letterbox 同样输入 0 检出 ⇒ 属"人为极端变形"伪影，非 640×480 真实帧问题，但说明 **stretch 预处理对极端宽高比敏感**，真车若出现超宽画面需复验。

## 7. 风险 / 未验证项

1. **红面未真车验证**〔未〕：本机只有规则照片（200×290 的翻拍），red=0.507 勉强过 0.4 阈值；红面真帧分数分布未知（若上赛道后红面 0.3–0.5，会漏）。
2. **有效样本小**〔未〕：真实独立场景约 7 个，且全是蓝面中/近距；无远距（<30px）、无旋转侧视、无日落逆光。
3. **转换已实跑、NPU 未验**〔部分〕：WSL 已产出 FP16 rknn 并经模拟器对齐（§3a），但**没有 RK3588 上的真实时延/算子回退数据**；YOLO11 的 C2PSA 是否部分算子落 CPU 仍需车上实测。
4. **阈值是编译期宏**（BOX_THRESH=0.4）：若新模型分数偏低，改阈值需重编译 det_node，不能靠配置。
5. `verify_contract.py` **不覆盖车端 pose 契约**：它按输出名 `output0` 识别成 hbb 契约，对 `target_pose_v2` 报"形状不符 (1,9,8400)!=(N,11,33600)"；需补 DET_POSE 契约（否则以后每次换车端模型都会误判为红）。
6. README 中 `light_det.rknn` 行写"4 bbox + 1 cls + 4 kpt"，与代码（2 类 + 1 关键点）和实测类分数分布不符，建议更正，否则后续排障会被带偏。

## 8. 下一步最小动作（按顺序，一步一验）

1. ~~x86 转换~~ **已完成**：产物 `_tmp_session/VISION-MODEL-20261023/models/target_pose_v2_20261016_fp16.rknn`（§3a），直接进第 2 步。
2. 车上只读验证：`python3 tools/test_rknn.py <rknn> --image <一帧.jpg>` → 必须打印 `output0 shape [1,9,8400]`、max≈0.9；若 shape 变成 [1,8400,9] 则后处理解不了，**停止**。
3. 备份现役 `light_det.rknn`（md5 49F37005…CC13），覆盖同名文件（本地源码与 config 含 `hot_reload: true`，mtime 变化 1s 内自动重载；若车上版本更老则重启 det_node 一次）；跑一帧真图，确认 `/offset_center` 的 data[2]=1（蓝）、框位置与分数正常。
4. 失败回滚：把备份复制回同名文件即可（同样热加载）。

## 9. 证据清单（本目录）

`01_onnx_contract.txt` ONNX IO+契约对照 ｜ `02_baseline_rknn_header.txt` 现役 rknn 头部与 runtime ｜ `03_eval_summary.txt` 113 帧逐组结果 ｜ `04_class_margin.txt` 类分数边距 ｜ `05_negative_samples.txt` 水桶负样本 ｜ `06_web_sources.md` 6 个联网来源（2026-10-23） ｜ `07_conversion_path.md` 转换命令与耗时 ｜ `commands_env.log` 环境探测原始输出 ｜ `08_convert_fp16_log.txt`/`08_wsl_toolchain.txt` 转换日志与环境 ｜ `09_sim_verify.json` 模拟器对比 ｜ `10_negative_rknn_sim.json` 负样本模拟器 ｜ `11_wsl_local_test.md` WSL 完整记录 ｜ `models/*.rknn|*.onnx` 转换产物 ｜ `commands_wsl.log` WSL 命令与退出码 ｜ `12_rknn_vs_onnx.jpg` 同帧 ONNX/RKNN 框对比 ｜ `eval_frames.json` 逐帧检测明细 ｜ `det_contact.jpg` 前 12 个检出场景拼图 ｜ `infer_pose.py`/`batch_eval.py`/`neg_test.py` 可复跑脚本
