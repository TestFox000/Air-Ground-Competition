#!/usr/bin/env bash
# 环境与工具链盘点（只读探测），输出即证据
set -x
date -Iseconds
uname -a
python --version
python -c "import onnxruntime, numpy, cv2, onnx; print('onnxruntime', onnxruntime.__version__); print('numpy', numpy.__version__); print('cv2', cv2.__version__); print('onnx', onnx.__version__)"
python -m pip --version
wsl -l -v
docker --version
python -m pip install --dry-run --no-input rknn-toolkit2==2.3.2
python -c "import importlib.util as u; print('rknn module:', u.find_spec('rknn'))"
