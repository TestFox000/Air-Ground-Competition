# -*- coding: utf-8 -*-
import json, os
rows = json.load(open(r"D:/User/Desktop/比赛存档/v1/_tmp_session/VISION-MODEL-20261023/eval_frames.json", encoding="utf-8"))
for r in rows:
    if r["group"] == "move_frames" and r["mode"] == "letterbox":
        print(os.path.basename(r["path"]), [(d["cls"], d["score"], round(d["w"],1), round(d["h"],1)) for d in r["detections"]], "max=", r["stats"]["max_cls_score"])
