# 转换路径（本机不可执行，给可复制的命令）

## 0. 基线参数（从现役 light_det.rknn 头部还原，必须一致）

- compiler 2.3.2 ｜ target_platform=rk3588 ｜ 输入 images [1,3,640,640]
- mean_values=[[0,0,0]] ｜ std_values=[[255,255,255]] ｜ rgb2bgr=False
- 量化：**无**（quant_tab 为空、输入 dtype float32）⇒ 用 FP16，不要 INT8
- 输出 output0 [1,9,8400] float32

## A. 首选：x86_64 Ubuntu 22.04/24.04（云端 4090 训练机就是 Linux x86）

```bash
python3 -m venv ~/rknn232 && . ~/rknn232/bin/activate
pip install -U pip
pip install rknn-toolkit2==2.3.2          # 与车端 runtime 2.3.2 对齐
# 仓库自带脚本（gitee 仓 tools/ml/rknn_convert.py，已核对 mean/std 与基线一致）
python tools/ml/rknn_convert.py \
  --onnx models/release/target_pose_v2_20261016.onnx \
  --out  models/release/target_pose_v2_20261016.rknn \
  --no-quant
```

产物预期：~8–9 MB（现役 8,487,541 B；新模型 2.72M 参数，FP16 权重 5.44 MB + 图/头开销）。

## B. 备选：直接在车上（aarch64）venv 里转 + 立刻上 NPU 验证

```bash
python3 -m venv /tmp/rknn232 && . /tmp/rknn232/bin/activate
pip install rknn-toolkit2==2.3.2          # cp310/cp311/cp312 aarch64 wheel 存在
python3 tools/ml/rknn_convert.py --onnx target_pose_v2_20261016.onnx \
  --out target_pose_v2_20261016.rknn --no-quant
python3 tools/test_rknn.py target_pose_v2_20261016.rknn --image <一帧.jpg>
# 期望打印 output0 shape [1,9,8400]、max≈0.9；即证明输出布局/后处理契约成立
```

注意：Ultralytics 官方说 ARM64 不支持"它的导出封装"，Rockchip 原生 toolkit 2.3.0+ 提供 aarch64 wheel；
车上安装只进 /tmp venv，不动系统包。

## C. 若要 INT8（不建议首轮）

```bash
# dataset.txt：每行一张图绝对路径，50–200 张真实场景帧（含蓝/红面、水桶、空场景）
python tools/ml/rknn_convert.py --onnx ... --out ... --dataset dataset.txt
```
风险：关键点回归对量化敏感；现役基线本身是 FP16，INT8 是"变更第二个变量"，不符合"一次只改一个变量"。

## D. 耗时估计

| 步骤 | x86 机器 | 车上 aarch64 |
|---|---|---|
| 建 venv + 装 wheel | 3–10 min | 5–15 min |
| FP16 转换（无校准集） | 1–3 min | 5–15 min |
| 上 NPU 验证（test_rknn.py） | 需在车上 | 即时 |
| 现场 A/B（一帧真图） | — | 5 min |
