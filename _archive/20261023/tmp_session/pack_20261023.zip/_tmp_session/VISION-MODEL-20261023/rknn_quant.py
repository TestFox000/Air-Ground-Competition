# -*- coding: utf-8 -*-
import re
p = r"D:/User/Desktop/比赛存档/v1/dzrobot_v2/src/rknn_pt/model/light_det.rknn"
data = open(p, "rb").read()
txt = re.sub(rb"[^ -~]", b".", data[:1800]).decode("latin1")
print(txt)
print("=== keyword counts")
for kw in [b"quant", b"int8", b"w8a8", b"float16", b"fp16", b"hybrid", b"dataset"]:
    print(kw, data.count(kw), [m.start() for m in re.finditer(kw, data)][:6])
