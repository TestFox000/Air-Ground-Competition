# -*- coding: utf-8 -*-
"""Pose ONNX smoke test: verify [1,9,8400] contract + decode like det_node/postprocess.cc."""
import json, sys, time
import numpy as np
import cv2
import onnxruntime as ort

MODEL = r"D:/User/Desktop/air_ground_最新视觉识别模型_20261023/target_pose_v2_20261016.onnx"
sess = ort.InferenceSession(MODEL, providers=["CPUExecutionProvider"])
IN = sess.get_inputs()[0].name
OUT = sess.get_outputs()[0].name
print("input", IN, sess.get_inputs()[0].shape, "output", OUT, sess.get_outputs()[0].shape)

def letterbox(im, size=640, color=114):
    h, w = im.shape[:2]
    r = min(size / h, size / w)
    nw, nh = int(round(w * r)), int(round(h * r))
    resized = cv2.resize(im, (nw, nh), interpolation=cv2.INTER_LINEAR)
    canvas = np.full((size, size, 3), color, np.uint8)
    dw, dh = (size - nw) // 2, (size - nh) // 2
    canvas[dh:dh+nh, dw:dw+nw] = resized
    return canvas, r, dw, dh

def stretch(im, size=640):
    return cv2.resize(im, (size, size), interpolation=cv2.INTER_LINEAR), im.shape[1]/size, 0, 0

def nms(boxes, thr=0.45):
    boxes = sorted(boxes, key=lambda b: -b["score"])
    keep = []
    for b in boxes:
        drop = False
        for k in keep:
            if k["cls"] != b["cls"]:
                continue
            ix1, iy1 = max(b["x1"], k["x1"]), max(b["y1"], k["y1"])
            ix2, iy2 = min(b["x2"], k["x2"]), min(b["y2"], k["y2"])
            iw, ih = max(0, ix2-ix1), max(0, iy2-iy1)
            inter = iw*ih
            ua = (b["x2"]-b["x1"])*(b["y2"]-b["y1"]) + (k["x2"]-k["x1"])*(k["y2"]-k["y1"]) - inter
            if ua > 0 and inter/ua > thr:
                drop = True; break
        if not drop: keep.append(b)
    return keep

def run(path, mode="letterbox", conf=0.4):
    try:
        buf = np.fromfile(path, dtype=np.uint8)
        im = cv2.imdecode(buf, cv2.IMREAD_COLOR)
    except Exception as e:
        return {"path": path, "error": f"read fail: {e}"}
    if im is None: return {"path": path, "error": "read fail: decode"} 
    h0, w0 = im.shape[:2]
    if mode == "letterbox":
        canvas, scale, dw, dh = letterbox(im)
        fwd = lambda x, y: ((x-dw)/scale, (y-dh)/scale)
    else:
        canvas, sx, sy, _ = stretch(im)
        fwd = lambda x, y: (x*(w0/640.0), y*(h0/640.0))
    blob = canvas[:, :, ::-1].transpose(2, 0, 1)[None].astype(np.float32) / 255.0
    t0 = time.time()
    out = sess.run([OUT], {IN: blob})[0]
    dt = (time.time()-t0)*1000
    ch = out[0]  # [9, 8400]
    boxes = []
    for n in range(ch.shape[1]):
        scores = ch[4:6, n]
        ci = int(np.argmax(scores)); s = float(scores[ci])
        if s < conf: continue
        cx, cy, bw, bh = ch[0, n], ch[1, n], ch[2, n], ch[3, n]
        if bw <= 1 or bh <= 1: continue
        x1, y1 = fwd(float(cx-bw/2), float(cy-bh/2))
        x2, y2 = fwd(float(cx+bw/2), float(cy+bh/2))
        kx, ky, kc = ch[6, n], ch[7, n], ch[8, n]
        kx2, ky2 = fwd(float(kx), float(ky))
        boxes.append({"cls": ci, "score": round(s, 4), "x1": round(x1,1), "y1": round(y1,1),
                      "x2": round(x2,1), "y2": round(y2,1), "w": round(x2-x1,1), "h": round(y2-y1,1),
                      "kpt": [round(kx2,1), round(ky2,1), round(float(kc),4)]})
    boxes = nms(boxes)
    stats = {"max_cls_score": round(float(ch[4:6].max()), 4),
             "min_cls_score": round(float(ch[4:6].min()), 4),
             "bbox_w_range": [round(float(ch[2].min()),2), round(float(ch[2].max()),2)],
             "kpt_conf_range": [round(float(ch[8].min()),4), round(float(ch[8].max()),4)]}
    return {"path": path, "mode": mode, "size": [w0, h0], "ms": round(dt,1),
            "detections": boxes, "stats": stats, "raw_shape": list(out.shape)}

if __name__ == "__main__":
    with open(sys.argv[1], "r", encoding="utf-8") as f:
        args = json.load(f)
    res = [run(a["p"], a.get("mode","letterbox"), a.get("conf",0.4)) for a in args]
    with open(sys.argv[2], "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=1)
    print(json.dumps(res, ensure_ascii=False, indent=1))