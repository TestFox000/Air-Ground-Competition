# -*- coding: utf-8 -*-
import struct, onnx
from onnx import numpy_helper
lib = r"D:/User/Desktop/比赛存档/v1/dzrobot_v2/src/rknn_pt/lib/librknnrt.so"
with open(lib, "rb") as f:
    hdr = f.read(20)
    f.seek(18); mach = struct.unpack("<H", f.read(2))[0]
print("ELF class", hdr[4], "machine 0x%x" % mach, {0x3e:"x86-64",0xb7:"AArch64",0x28:"ARM"}.get(mach,"?"))
m = onnx.load(r"D:/User/Desktop/air_ground_最新视觉识别模型_20261023/target_pose_v2_20261016.onnx")
tot=0; cnt=0
for init in m.graph.initializer:
    n=1
    for d in init.dims: n*=d
    tot += n; cnt += 1
print("initializers", cnt, "params", tot, "fp32 MB", round(tot*4/1e6,2), "fp16 MB", round(tot*2/1e6,2))
