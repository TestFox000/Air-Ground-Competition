# -*- coding: utf-8 -*-
import json, os
import numpy as np
rows = json.load(open(r"D:/User/Desktop/比赛存档/v1/_tmp_session/VISION-MODEL-20261023/eval_frames.json", encoding="utf-8"))
sel = [r for r in rows if r["group"]=="cap_t" and r["mode"]=="letterbox" and r.get("detections")]
offs=[]; scores=[]; kconf=[]; sizes=[]
for r in sel:
    d = max(r["detections"], key=lambda x: x["score"])
    cx=(d["x1"]+d["x2"])/2; cy=(d["y1"]+d["y2"])/2
    dx=d["kpt"][0]-cx; dy=d["kpt"][1]-cy
    diag=((d["w"]**2+d["h"]**2)**0.5)
    offs.append(((dx**2+dy**2)**0.5)/diag); scores.append(d["score"]); kconf.append(d["kpt"][2]); sizes.append((d["w"],d["h"]))
print("cap_t n=",len(sel))
print("score min/med/max", round(min(scores),3), round(float(np.median(scores)),3), round(max(scores),3))
print("kpt conf min/med", round(min(kconf),4), round(float(np.median(kconf)),4))
print("kpt-center offset / diag: med", round(float(np.median(offs)),3), "max", round(max(offs),3))
ws=[s[0] for s in sizes]; hs=[s[1] for s in sizes]
print("box w min..max", round(min(ws),1), round(max(ws),1), " h", round(min(hs),1), round(max(hs),1))
print("classes", set(d["cls"] for r in sel for d in r["detections"]))
