# -*- coding: utf-8 -*-
import cv2, numpy as np, json, os
from infer_pose import run
base = r"D:/User/Desktop/比赛存档/v1/_tmp_session/VISION-MODEL-20261023"
g = r"D:/User/Desktop/比赛存档/v1/_tmp_session/DET-20261022"

def load(p):
    return cv2.imdecode(np.fromfile(p, dtype=np.uint8), cv2.IMREAD_COLOR)
def save(p, im):
    ok, buf = cv2.imencode(".jpg", im)
    buf.tofile(p)

# crop bucket regions
f = g + "/gframes/frame_00002371.jpg"
im = load(f)
print("frame size", im.shape)
save(base + "/neg_buckets_row.jpg", im[210:320, 80:620])
save(base + "/neg_blue_bucket.jpg", im[220:310, 430:560])
save(base + "/neg_red_bucket.jpg", im[215:315, 90:210])
# red bucket close-up from frame_00002755 (top left)
im2 = load(g + "/gframes/frame_00002755.jpg")
save(base + "/neg_red_bucket2.jpg", im2[0:80, 20:140])
# bucket illustration from rules
im4 = load(r"D:/User/Desktop/比赛存档/v1/_tmp_session/gitee_ag/main/reference/members/hjy/原始资料/rules/image4.png")
save(base + "/neg_bucket_illus.jpg", im4)

jobs = [
 {"p": base + "/neg_buckets_row.jpg", "mode": "letterbox"},
 {"p": base + "/neg_blue_bucket.jpg", "mode": "letterbox"},
 {"p": base + "/neg_red_bucket.jpg", "mode": "letterbox"},
 {"p": base + "/neg_red_bucket2.jpg", "mode": "letterbox"},
 {"p": base + "/neg_bucket_illus.jpg", "mode": "letterbox"},
 {"p": base + "/neg_buckets_row.jpg", "mode": "stretch"},
]
for j in jobs:
    r = run(j["p"], j["mode"], 0.2)
    print(os.path.basename(j["p"]), j["mode"], "n=", len(r["detections"]),
          "max=", r["stats"]["max_cls_score"], [(d["cls"], d["score"], round(d["w"],1), round(d["h"],1)) for d in r["detections"]])
