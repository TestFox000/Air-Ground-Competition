# -*- coding: utf-8 -*-
import onnx, json
m = onnx.load(r"D:/User/Desktop/air_ground_最新视觉识别模型_20261023/target_pose_v2_20261016.onnx")
names = [n.name for n in m.graph.node]
heads = sorted(set(n.rsplit(".",3)[0] for n in names if n.startswith("model.22")))
print("head prefixes:", heads[:20])
print("sample head nodes:", [n for n in names if n.startswith("model.22")][:12])
print("output node:", [n for n in m.graph.node if "output0" in n.output])
