# -*- coding: utf-8 -*-
import json, collections, glob, os
for p in sorted(glob.glob(r"D:/User/Desktop/比赛存档/v1/_tmp_session/DET-20261022/aimrec_*.jsonl")):
    c = collections.Counter(); ncls=collections.Counter(); n=0
    for line in open(p, encoding="utf-8", errors="replace"):
        try: d=json.loads(line)
        except: continue
        if d.get("k") != "offset": continue
        v=d["v"]; n+=1
        if len(v)>2: c[v[2]]+=1
    print(os.path.basename(p), "offset msgs", n, "cls(data[2])", dict(c))
