# -*- coding: utf-8 -*-
import re
p = r"D:/User/Desktop/比赛存档/v1/dzrobot_v2/src/rknn_pt/model/light_det.rknn"
data = open(p, "rb").read()
print("size", len(data))
print("head hex", data[:64].hex(" "))
print("head ascii", data[:64])
# find ascii markers
for pat in [b"output0", b"images", b"8400", b"output", b"dims", b"rknn"]:
    idx = [m.start() for m in re.finditer(pat, data)][:5]
    print(pat, idx)
# print windows around 'output0' or 'images'
for pat in [b"output0", b"images"]:
    for i in [m.start() for m in re.finditer(pat, data)][:1]:
        print("---", pat, "at", i, data[i-96:i+160])
