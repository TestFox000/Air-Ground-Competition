# -*- coding: utf-8 -*-
p = r"D:/User/Desktop/比赛存档/v1/dzrobot_v2/src/rknn_pt/model/light_det.rknn"
data = open(p, "rb").read()
# dump printable region 600-2200
import re
chunk = data[560:2400]
text = re.sub(rb"[^ -~]", b".", chunk).decode("latin1")
print(text)
