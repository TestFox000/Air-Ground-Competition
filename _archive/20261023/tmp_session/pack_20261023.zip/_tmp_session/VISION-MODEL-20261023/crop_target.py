# -*- coding: utf-8 -*-
from PIL import Image
im = Image.open(r"D:/User/Desktop/比赛存档/v1/_tmp_session/gitee_ag/main/reference/members/hjy/原始资料/rules/image1.png").convert("RGB")
print(im.size)
# right-side two target photos
im.crop((505, 90, 705, 380)).save(r"D:/User/Desktop/比赛存档/v1/_tmp_session/VISION-MODEL-20261023/target_red_crop.jpg", quality=95)
im.crop((710, 90, 910, 380)).save(r"D:/User/Desktop/比赛存档/v1/_tmp_session/VISION-MODEL-20261023/target_blue_crop.jpg", quality=95)
print("cropped")
