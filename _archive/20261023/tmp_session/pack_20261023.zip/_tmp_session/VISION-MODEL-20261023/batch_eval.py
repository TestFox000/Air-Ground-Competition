# -*- coding: utf-8 -*-
"""Batch evaluate target_pose_v2 on local car-camera frames (letterbox vs stretch)."""
import os, json, glob
import numpy as np
import cv2
from infer_pose import run, sess, IN, OUT

ROOT = r"D:/User/Desktop/比赛存档/v1/_tmp_session"
OUTDIR = r"D:/User/Desktop/比赛存档/v1/_tmp_session/VISION-MODEL-20261023"
dirs = {
    "cap_t": ROOT + r"/DET-20261022/cap_t",
    "gframes": ROOT + r"/DET-20261022/gframes",
    "move_frames": ROOT + r"/DET-20261022/move_frames",
    "ffield": ROOT + r"/DET-20261022/ffield",
    "snap1": ROOT + r"/DET-20261022/snap1",
}
files = []
for name, d in dirs.items():
    for f in sorted(glob.glob(d + "/*.jpg")):
        files.append((name, f))

rows = []
for name, f in files:
    for mode in ("letterbox", "stretch"):
        r = run(f, mode=mode, conf=0.4)
        r["group"] = name
        rows.append(r)
with open(OUTDIR + "/eval_frames.json", "w", encoding="utf-8") as fh:
    json.dump(rows, fh, ensure_ascii=False, indent=1)

# summary
import collections
summ = collections.defaultdict(lambda: collections.Counter())
for r in rows:
    key = (r["group"], r["mode"])
    summ[key]["imgs"] += 1
    summ[key]["hit"] += 1 if r.get("detections") else 0
print("group mode imgs hit hitrate  avg_best_score")
for k, c in sorted(summ.items()):
    scores = [max([d["score"] for d in r.get("detections", [])] or [0]) for r in rows if (r["group"], r["mode"]) == k]
    print(k[0], k[1], c["imgs"], c["hit"], round(c["hit"]/c["imgs"],3), round(float(np.mean(scores)),3))

# annotated contact sheet: top detections (letterbox), plus stretch counterparts
det = [r for r in rows if r["mode"] == "letterbox" and r.get("detections")]
det.sort(key=lambda r: -max(d["score"] for d in r["detections"]))
print("frames with letterbox detections:", len(det), "of", len(files))

def draw(path, r):
    im = cv2.imdecode(np.fromfile(path, dtype=np.uint8), cv2.IMREAD_COLOR)
    for d in r["detections"]:
        color = (255, 80, 0) if d["cls"] == 0 else (0, 0, 255)  # blue target BGR, red
        cv2.rectangle(im, (int(d["x1"]), int(d["y1"])), (int(d["x2"]), int(d["y2"])), color, 2)
        label = ("BLUE" if d["cls"] == 0 else "RED") + f" {d['score']:.2f}"
        cv2.putText(im, label, (int(d["x1"]), max(12, int(d["y1"])-5)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1)
        cv2.circle(im, (int(d["kpt"][0]), int(d["kpt"][1])), 3, (0, 255, 0), -1)
    return im

sel = det[:12]
tw, th = 320, 240
cols = 3
rows_n = (len(sel) + cols - 1) // cols
sheet = np.full((rows_n*th, cols*tw, 3), 255, np.uint8)
for i, r in enumerate(sel):
    im = draw(r["path"], r)
    im = cv2.resize(im, (tw, th))
    y, x = (i//cols)*th, (i%cols)*tw
    sheet[y:y+th, x:x+tw] = im
    cv2.putText(sheet, os.path.basename(r["path"])[:28], (x+4, y+18), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0,0,0), 1)
cv2.imwrite(OUTDIR + "/det_contact.jpg", sheet, [cv2.IMWRITE_JPEG_QUALITY, 88])
print("wrote det_contact.jpg")

# per-frame listing for positives >0.4 in both modes
for r in det[:20]:
    keys = [x for x in rows if x["path"] == r["path"] and x["mode"] == "stretch"]
    st = keys[0] if keys else None
    print(os.path.basename(r["path"]), [(d["cls"], d["score"], d["w"], d["h"]) for d in r["detections"]],
          "| stretch:", [(d["cls"], d["score"], d["w"], d["h"]) for d in (st or {}).get("detections", [])])
