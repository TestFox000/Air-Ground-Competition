# -*- coding: utf-8 -*-
import re, sys
def strs(p, minlen=4):
    data = open(p, "rb").read()
    return re.findall(rb"[ -~]{%d,}" % minlen, data)
lib = r"D:/User/Desktop/比赛存档/v1/dzrobot_v2/src/rknn_pt/lib/librknnrt.so"
s = [x.decode("latin1") for x in strs(lib)]
hits = [x for x in s if re.search(r"(?i)librknnrt|rknn.?version|^1\.6\.|^2\.[0-9]+\.[0-9]+|version.*[0-9]\.[0-9]", x)]
print("LIB candidates:")
for h in hits[:20]: print("  ", h[:160])
print("--- first 25 strings")
for x in s[:25]: print("  ", x[:120])

rk = r"D:/User/Desktop/比赛存档/v1/dzrobot_v2/src/rknn_pt/model/light_det.rknn"
s2 = [x.decode("latin1") for x in strs(rk)]
print("\nRKNN candidates:")
for x in s2:
    if re.search(r"(?i)rknn|version|v[0-9]\.[0-9]", x) and len(x) < 200:
        print("  ", x[:160])
print("--- first 20")
for x in s2[:20]: print("  ", x[:120])
