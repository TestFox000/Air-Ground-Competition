# -*- coding: utf-8 -*-
from PIL import Image, ImageDraw
import glob, os
files = sorted(glob.glob(r"D:/User/Desktop/比赛存档/v1/_tmp_session/gitee_ag/main/reference/members/hjy/原始资料/rules/image*.png"))
files = [f for f in files if not f.endswith('.bmp')]
cols, rows = 4, 4
tw, th = 480, 260
sheet = Image.new("RGB", (cols*tw, rows*th), "white")
d = ImageDraw.Draw(sheet)
for i, f in enumerate(files[:cols*rows]):
    im = Image.open(f).convert("RGB")
    im.thumbnail((tw-6, th-20))
    x, y = (i%cols)*tw, (i//cols)*th
    sheet.paste(im, (x+3, y+16))
    d.text((x+4, y+2), os.path.basename(f)+f" {Image.open(f).size}", fill="black")
out = r"D:/User/Desktop/比赛存档/v1/_tmp_session/VISION-MODEL-20261023/rules_contact.jpg"
sheet.save(out, quality=85)
print(out, len(files))
