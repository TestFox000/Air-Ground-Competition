# -*- coding: utf-8 -*-
import numpy as np, cv2, onnxruntime as ort
from infer_pose import letterbox, sess, IN, OUT
base = r"D:/User/Desktop/比赛存档/v1/_tmp_session/VISION-MODEL-20261023"
g = r"D:/User/Desktop/比赛存档/v1/_tmp_session/DET-20261022"
paths = [
    g + "/cap_t/frame_00000041.jpg",
    g + "/move_frames/det_0_frame_00001713.jpg",
    g + "/gframes/frame_00002371.jpg",
    g + "/gframes/frame_00050827.jpg",
    g + "/move_frames/nodet_1_frame_00006676.jpg",
    base + "/target_red_crop_2x.jpg",
    base + "/target_blue_crop.jpg",
]
for p in paths:
    im = cv2.imdecode(np.fromfile(p, np.uint8), cv2.IMREAD_COLOR)
    canvas, scale, dw, dh = letterbox(im)
    blob = canvas[:, :, ::-1].transpose(2,0,1)[None].astype(np.float32)/255.0
    ch = sess.run([OUT], {IN: blob})[0][0]
    best = int(np.argmax(ch[4:6].max(axis=0)))
    b, r = float(ch[4, best]), float(ch[5, best])
    print(f"{p.split('/')[-1]:<34} best_anchor={best:5d} blue={b:.4f} red={r:.4f} ratio={max(b,r)/max(1e-6,min(b,r)):.1f} bbox=({ch[0,best]:.0f},{ch[1,best]:.0f},{ch[2,best]:.0f},{ch[3,best]:.0f})")
