# -*- coding: utf-8 -*-
import json, collections
p = r"D:/User/Desktop/比赛存档/v1/_tmp_session/DET-20261022/aimrec_track.jsonl"
c = collections.Counter(); n=0
sample=None
for line in open(p, encoding="utf-8", errors="replace"):
    line=line.strip()
    if not line: continue
    try: d=json.loads(line)
    except: continue
    n+=1
    if sample is None: sample=d
    if "cls" in d: c[d["cls"]]+=1
print("lines", n, "keys", list(sample.keys())[:15])
print("cls counts", dict(c))
print("sample", json.dumps(sample, ensure_ascii=False)[:800])
