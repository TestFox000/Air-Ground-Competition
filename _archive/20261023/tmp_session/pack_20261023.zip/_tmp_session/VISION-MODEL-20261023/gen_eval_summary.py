# -*- coding: utf-8 -*-
import json, os, collections
import numpy as np
rows = json.load(open(r"D:/User/Desktop/比赛存档/v1/_tmp_session/VISION-MODEL-20261023/eval_frames.json", encoding="utf-8"))
out = []
out.append("目标模型: target_pose_v2_20261016.onnx (YOLO11n-pose, 640, opset12)")
out.append("测试集: _tmp_session/DET-20261022 下 113 张车端相机 640x480 真实帧")
out.append("阈值: conf>=0.4, 同类 NMS 0.45（与 det_node postprocess 默认一致）")
out.append("")
out.append("组        模式       帧数  命中  命中率  最高分均值")
summ = collections.defaultdict(list)
for r in rows:
    key = (r["group"], r["mode"])
    summ[key].append(r)
for k in sorted(summ):
    rs = summ[k]
    hit = sum(1 for r in rs if r.get("detections"))
    best = [max([d["score"] for d in r["detections"]] or [0]) for r in rs]
    out.append(f"{k[0]:<10} {k[1]:<10} {len(rs):>4}  {hit:>4}  {hit/len(rs):>5.2f}  {np.mean(best):.3f}")
out.append("")
out.append("注：cap_t 90 帧是同一静止场景的连续采样（框宽 53.2~54.2px），有效独立场景约 7 个：")
out.append("  cap_t(蓝面中距) / gframes 2371(蓝面+三色水桶) / 50827(蓝面右缘+红蓝桶) /")
out.append("  19379(蓝面左缘残影) / move_frames det_0..3(蓝面近距 ~95px) / snap1 frame_last(蓝面近距 ~87px)")
out.append("")
out.append("== 逐场景（letterbox 模式，conf>=0.4）==")
seen = set(); cap_seen = 0
for r in rows:
    if r["mode"] != "letterbox": continue
    p = r["path"]
    if p in seen: continue
    seen.add(p)
    if r["group"] == "cap_t":
        cap_seen += 1
        if cap_seen > 2: continue
    ds = r.get("detections", [])
    if not ds and r["group"] in ("cap_t",): continue
    out.append(f"{r['group']:>11}/{os.path.basename(p):<34} " +
               ("; ".join(f"cls={d['cls']} score={d['score']:.3f} box={d['w']:.0f}x{d['h']:.0f} kpt=({d['kpt'][0]:.0f},{d['kpt'][1]:.0f},c={d['kpt'][2]:.3f})" for d in ds) if ds else "无检出"))
out.append("")
out.append("== letterbox vs stretch（车端 rkpt.cc 用 stretch）==")
by = {}
for r in rows: by.setdefault(r["path"], {})[r["mode"]] = r
diff = 0
for p, d in by.items():
    l, s = d.get("letterbox", {}), d.get("stretch", {})
    hit_l = bool(l.get("detections")); hit_s = bool(s.get("detections"))
    if hit_l != hit_s:
        diff += 1
        out.append(f"差异: {os.path.basename(p)} letterbox={hit_l} stretch={hit_s} "
                   f"(maxL={l.get('stats',{}).get('max_cls_score')} maxS={s.get('stats',{}).get('max_cls_score')})")
out.append(f"逐帧结果翻转数: {diff}/113；cap_t 组两模式平均最高分 0.934 vs 0.936")
open(r"D:/User/Desktop/比赛存档/v1/_tmp_session/VISION-MODEL-20261023/03_eval_summary.txt","w",encoding="utf-8").write("\n".join(out)+"\n")
print("\n".join(out))