# -*- coding: utf-8 -*-
import cv2, numpy as np
from infer_pose import run
base = r"D:/User/Desktop/比赛存档/v1/_tmp_session/VISION-MODEL-20261023"
img = r"D:/User/Desktop/比赛存档/v1/_tmp_session/gitee_ag/main/reference/members/hjy/原始资料/rules/image1.png"
for c in (0.15, 0.25):
    r = run(img, "letterbox", c)
    print("image1 conf", c, "->", [(d["cls"], d["score"], round(d["w"],1), round(d["h"],1), round(d["kpt"][2],3)) for d in r["detections"]])
# upscale red crop
im = cv2.imdecode(np.fromfile(base + "/target_red_crop.jpg", np.uint8), cv2.IMREAD_COLOR)
big = cv2.resize(im, (400, 580), interpolation=cv2.INTER_CUBIC)
ok, buf = cv2.imencode(".jpg", big, [cv2.IMWRITE_JPEG_QUALITY, 95]); buf.tofile(base + "/target_red_crop_2x.jpg")
for c in (0.15, 0.25, 0.4):
    r = run(base + "/target_red_crop_2x.jpg", "letterbox", c)
    print("red2x conf", c, "->", [(d["cls"], d["score"], round(d["w"],1), round(d["h"],1), round(d["kpt"][2],3)) for d in r["detections"]])
