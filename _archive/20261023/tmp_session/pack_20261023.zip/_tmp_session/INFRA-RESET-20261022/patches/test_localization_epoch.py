# -*- coding: utf-8 -*-
# 草案：新增到 tests/test_localization.py 末尾（⑯ 节），沿用现有 build()/FakeBridge/FakeClock，
# 不新增假车。运行（Windows）：
#   set PYTHONPATH=src\dzbrain && python src\dzbrain\tests\test_localization.py
# 需要在文件头 import 里加：EV_POSE_EPOCH（dzbrain.core.events）
#                       P_MOTION_LIMIT（已在 line 36 的 import 里）
#
# 契约：位姿源换 epoch（serial_reader 重启 / reset 授权重锚）后的第一帧只做基线，
#       不判"单帧跳变"、不发 EV_TASK_FAULT；同 epoch 内的同样跳变必须照旧判故障。

section("⑯ 位姿源换 epoch：reset/重启首帧不得判故障；同 epoch 仍必须报（带牙）")


def _epoch_run(seq_after: str | None, *, yaw_deg: float = 0.0, ticks: int = 3,
               push_reset: bool = False):
    """两帧：基线(-130.7°) → 跳变帧(yaw_deg)。seq_after=None 表示不换 epoch。"""
    task, bridge, bb, bus, clock = build(
        overrides={"fix": {"anchor_at_waypoint": False}}, seed_pose=False)
    seq = {"v": "10.0"}                       # 老会话
    bridge.pose_epoch = lambda: seq["v"]      # 鸭子类型：实现侧用 getattr 懒查
    faults = bus.subscribe("f", [EV_TASK_FAULT], maxsize=32)
    bus.subscribe("e", [EV_POSE_EPOCH], maxsize=32)

    bridge.set_pose(0.175, 3.675, math.radians(-130.7))
    clock.advance(0.05)
    task.tick()                               # 基线帧

    if seq_after is not None:
        seq["v"] = seq_after                  # 位姿源换会话
    bridge.set_pose(0.175, 3.675, math.radians(yaw_deg))
    clock.advance(0.05)                       # dt=0.05 ⇒ 若判就是 2614°/s
    task.tick()

    if push_reset:
        task._epoch_sub      # 只确认订阅存在（事件由 Mission 发；此处直接调 bus）
        bus.publish(EV_POSE_EPOCH, source="MissionTask", why="reset",
                    block="D11", yaw=0.0)
        clock.advance(0.05)
        task.tick()
    for _ in range(ticks - 1):
        clock.advance(0.05)
        task.tick()
    return task, bridge, bb, bus, clock, faults


# ---- ⑯.1 换 epoch：不判故障、不发 TASK_FAULT、软停等复位 ----
t1, b1, bb1, bus1, ck1, f1 = _epoch_run("11.0")
check("⑯.1 换 epoch 首帧不判故障（yaw_untrusted=False）", t1.yaw_untrusted is False)
check("⑯.1 不向 Safety 发 EV_TASK_FAULT（0 条）", len(f1.poll(32)) == 0)
check("⑯.1 计一次重基线", t1.yaw_epoch_rebaselines == 1,
      f"got {t1.yaw_epoch_rebaselines}")
_ml = bb1.get(P_MOTION_LIMIT)
check("⑯.1 换 epoch 未授权 ⇒ 软停 P_MOTION_LIMIT.speed_mps==0",
      isinstance(_ml, dict) and _ml.get("speed_mps") == 0.0, f"got {_ml!r}")
check("⑯.1 软停原因可解释（reason=yaw_epoch）",
      isinstance(_ml, dict) and _ml.get("reason") == "yaw_epoch", f"got {_ml!r}")

# ---- ⑯.2 带牙：同 epoch 的同样跳变必须照旧判故障 ----
t2, b2, bb2, bus2, ck2, f2 = _epoch_run(None)
_ev2 = f2.poll(32)
check("⑯.2 同 epoch 1 帧跳 130.7° 仍判故障（yaw_untrusted=True）",
      t2.yaw_untrusted is True)
check("⑯.2 且发过 1 条 EV_TASK_FAULT", len(_ev2) == 1, f"got {len(_ev2)}")
check("⑯.2 reason=yaw_jump（不是包络类）", t2._yaw_reason == "yaw_jump",
      f"got {t2._yaw_reason!r}")

# ---- ⑯.3 epoch 变 + reset 授权：撤销软停 ----
t3, b3, bb3, bus3, ck3, f3 = _epoch_run("11.0", push_reset=True)
check("⑯.3 收到 reset 授权后 P_MOTION_LIMIT 撤为 None",
      bb3.get(P_MOTION_LIMIT) is None)
check("⑯.3 且仍未判故障", t3.yaw_untrusted is False)
check("⑯.3 未向 Safety 发 EV_TASK_FAULT", len(f3.poll(32)) == 0)

# ---- ⑯.4 不自动撤软停（与 Safety"刻意不自动恢复"同向）----
t4, b4, bb4, bus4, ck4, f4 = _epoch_run("11.0", ticks=20)   # 20 帧安静
check("⑯.4 安静 20 帧也不自动撤软停（必须显式 reset）",
      isinstance(bb4.get(P_MOTION_LIMIT), dict)
      and bb4.get(P_MOTION_LIMIT).get("speed_mps") == 0.0)

# ---- ⑯.5 降级：老替身无 pose_epoch() ⇒ 行为与今天逐位一致（⑫.2/⑫.3 仍全过）----
task5, bridge5, bb5, bus5, clock5 = build(
    overrides={"fix": {"anchor_at_waypoint": False}}, seed_pose=False)
bridge5.set_pose(0.175, 3.675, math.radians(-130.7)); clock5.advance(0.05); task5.tick()
bridge5.set_pose(0.175, 3.675, math.radians(0.0));    clock5.advance(0.05); task5.tick()
check("⑯.5 无 epoch 能力的桥：行为不变（130.7° 跳变照旧判故障）",
      task5.yaw_untrusted is True and task5._yaw_reason == "yaw_jump")

# ---- ⑯.6 联动 Safety：换 epoch 的 3 拍内不得进 SAFE_STOP（草案示意）----
# 接线方式照 test_safety.py 的 §① 构造（同一 bus/bb）；此处只给判据：
#   check("⑯.6 换 epoch 不触发 SAFE_STOP", safety.stopped is False)
#   check("⑯.6 P_SAFETY.ok 仍为 True", safety_state.ok is True)

# 预期：⑯ 共 14 条 check 全 PASS；⑫.2/⑫.3（真实片段/静止漂移）不动。
finish()
