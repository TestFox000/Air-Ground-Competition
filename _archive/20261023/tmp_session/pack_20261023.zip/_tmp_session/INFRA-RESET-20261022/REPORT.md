# R0 · reset→航向守卫 SAFE_STOP 闩锁：根治草案 + reset 语义治理

> 只读分析：内部只读 `dzrobot_v2/src`、`dzrobot_v2/config`、`docs/_work/TRACK-DAY-20261022/evidence`；本目录外未写任何文件，未 git、未 SSH、未连车。
> 结论分档：**[已证]** 有日志/代码行号可复算 · **[推测]** 有依据但未闭环 · **[未验证]** 需现场抓数据。

## 0. 一句话结论

130.7° 不是传感器跳变，也不是车在转：它是 **serial_reader 会话换纪元（重启/复位后原点重锚）** 造成的一次**坐标系原点跳变**，被守卫当成"单帧物理跳变"→ 立刻判故障 → `EV_TASK_FAULT` → Safety **永久锁存**（代码内无外部 clear 入口）。根治点不在"跳变阈值"，而在**给守卫一个"位姿源已换 epoch（授权不连续）"的信号**；否则任何一次 reset/重启都会重演，且每次都要重启 dzbrain 才能动车。

## 1. 复现算式（真实数值，可复算）

### 1.1 日志事实（`evidence/cam/7_path_A.log`）

| 行 | 事实 |
|---|---|
| 139 | `[T] D11 IDLE (0.175,3.675) yaw-131.3 v0.000 ... 安全OK` ← 跳变前最后一次遥测 |
| 141 | `🧭❌ 航向失去可信（yaw_jump）：单帧 yaw 跳变 130.7° > 阈值 30.0°（帧间隔角速度 2317.6°/s，v=0.00 m/s）` |
| 153 | `[T] D11 SAFE_STOP ... yaw-0.6` ← 跳变后第一次遥测 |
| 154 | `✅ 航向守卫自动恢复：连续 20 个新帧可信 … Safety 若已锁存，需显式 clear_safety()` |
| 171/183 | 载入 2 点路线 → `阶段 SAFE_STOP → DRIVE` → 又 `阶段 DRIVE → SAFE_STOP` |
| 185 | `到位吸附：D11（航点 #1）偏差 0.000 m → 锚回格心 (0.175,3.675)，yaw 不变 -0.015 rad` |
| 189→597 | 遥测一路 `SAFE_STOP` 直到日志结束（yaw −0.9°→−7.3° 只是静止漂移） |

### 1.2 三个数怎么拼出 130.7°

遥测 yaw = `P_POSE.yaw`，而 `P_POSE.yaw` 已加过固定 trim `yaw_trim_deg=-0.6`
（`tasks/localization.py:390-391`；值见 `config/robot.yaml:446,880`）。两帧共享同一 trim ⇒ 差值里抵消：

```
跳变前原始帧  M₁ = −131.3 − (−0.6) = −130.7°
跳变后原始帧  M₂ =   −0.6 − (−0.6) =    0.0°  ← 全新原点
跳变量        Δ  = |M₂ − M₁| = 0.0 − (−130.7) = 130.7°   ✓ 与 :141 的 130.7 逐位一致
帧间隔        dt = 130.7 / 2317.6 = 0.0564 s            ← 只有 ~1 个 20 Hz 帧
```

**为什么这是"原点重锚"而不是"车转了"**：0.0564 s 内转 130.7° = **2317.6°/s = 40.4 rad/s**。
本车静止档包络只有 **45°/s**（`localization.py:113` `_DEFAULT_YAW_STATIC_DPS`，`:764-767` 取用），
即本次跳变是物理上界的 **51 倍**；且 v=0.00 m/s、位置 (0.175,3.675) 一毫米没动。**[已证]**

### 1.3 "offset 回默认"这条链怎么落在这个数上

- `serial_reader.py:135` 默认 `dr_yaw_off = π/2 = 90.0°`；
- `:48` `HEADING_YAWS['x']=0.0` ⇒ `reset:D11,x` 的目标航向 = **0°**；
- `:181-183` 复位式：`off ← off + target − (yaw_rel + off)`，target=0、off=90 ⇒ **off = −yaw_rel**；
- 令 `yaw_rel = −130.7°`（即 M₁）⇒ **off = 130.7°** —— 与跳变量恰好同一个数；
- 节点重启后 `off` 回 **90.0°**、且 `imu_yaw_init` 重捕（`:149-153`）⇒ published yaw_rel 从 −130.7° 归 **0**。

所以"offset 回默认"确实是**同一个原点事件**的两个面（复位把 off 设成 130.7，重启把它打回 90 并把 yaw 相对原点清零）。**[已证]**
但要写清：**仓库源码里 off 并不进发布四元数** —— `:236-242` 只发布 `yaw_rel`，off 只喂 DR 方向积分（`:221-223`）与 5 Hz 诊断打印（`:248-249`）。真正被重启丢弃的**有效原点**是 `imu_yaw_init`。**修复必须挂在"位姿源换 epoch"，只给 dr_yaw_off 做斜坡不会消掉这次跳变。** **[已证（源码口径）]**

### 1.4 反证：不是传感器、也不是这次跳变导致 Safety

- 同一 IMU 源；若真是陀螺，40 rad/s 会超过量程并伴随加速度异常，日志无任何 IMU 告警。**[推测]**
- 跳变后 yaw≈0 是"新会话原点"，与同日另一次干净启动一致：`7_path_B.log:64` 起步 yaw −0.9°。**[已证]**
- Safety 锁存**不是**守卫闩锁造成的：守卫在 :154 已自动恢复 20 帧，Safety 仍 STOP（`:156-222`）——它是被 :141-147 的 `EV_TASK_FAULT` 锁死的。**[已证]**

> ⚠️ 一处**未验证**的口径缺口：`io/contract.py:129-133` 明写发布 yaw 要 `+π/2` 得地图 yaw，若部署副本也如此，重启后 M 应≈+90° 而非 0°。实测 0° 说明**部署副本与本地源在这条换算上可能不一致**（或 serial_reader 实际发布的是 map−90 口径）。现场 30 秒可定论：`ros2 topic echo /odom/localization --once` 抓四元数，与遥测 yaw 对照。在这之前，本报告的"130.7=原点差"结论与口径无关（它只依赖两帧 yaw 之差）。

## 2. 三候选修法对比（Q2）

| | (a) 守卫 re-baseline（无信号自愈） | (b) reset 时给 offset 做斜坡 | (c) **epoch/事件驱动的"授权不连续"清窗**（推荐） |
|---|---|---|---|
| 改动点 | `localization.py:702-760`：大跳变时直接 `_yaw_prev=None` + 不计故障 | `serial_reader.py:181-183`：off 每帧 ≤5° 逼近；若扩展到 yaw 原点则需持久化 `imu_yaw_init` | `serial_reader.py`（帧带 session 号）+ `mission.py:2798-2809`（复位发事件）+ `localization.py:664-760`（换 epoch 才重基线）+ `events.py`/`ros_io.py` 各 2~3 行 |
| 正常行驶灵敏度 | **塌成 0**：静止/低速的一切 >30° 跳变都不再报——正是 A2/L8 那一类 | 不变（但也没修好，见右） | **不变**：阈值 60/45/30/20 拍一字不改，只豁免"带 epoch 的那一帧" |
| A2 79.8°/s 误判争议（台账 D-029:97-100） | 会顺带把 A2 型遮掉 ⇒ 等于翻案，且无新证据 | 无影响（A2 不是复位场景） | **无影响**：A2/L8 均无 epoch 变化，判据与今天逐位一致 ⇒ 保住 D-029 "不能判误触发"的裁决 |
| 测试改动 | 现有 ⑫.2/⑫.3 全部要改判据，等于重写守卫测试 | car_localization 无测试基建，需新起 ROS 测试 | 新增 6 case（`test_localization` 5 + `test_safety` 1），现有 ⑫ 全不动 |
| 风险 | 拿掉守卫的核心价值；**误报变漏报**，真正重定位/绑架不再停车 | **修不到点**：off 不进发布 yaw（§1.3）；若改 yaw 原点斜坡，等于让车在几秒内"慢慢转 130°"，控制与投影全被带偏，斜坡速率>包络仍会触发 | 依赖 serial_reader 真的发布 epoch（否则降级为现状）；epoch hold 与 `_update_drift_guard` 的 `_limit_state` 去重契约必须统一（见 §3.4） |

**推荐 (c)**。不是 (a)：它把"守卫"改成"不设防"，用一次误报换来对所有绑架/重定位的失明，而 A2/L8 恰恰是这套守卫存在的理由（D-029 已裁定不能判误触发，也无新证据翻案）。
不是 (b)：它修的是**位置积分方向**，不是**发布 yaw 的原点**；斜坡只是把一次阶跃摊成一段错误航向，既消不掉 :141 的跳变，还会在斜坡期间把投影/前视全部带偏。

## 3. 推荐方案：diff 草案 + 测试草案（Q3）

### 3.1 契约（新增一条，写进 P1 接口约定）
> 位姿帧携带 **epoch**（同一 epoch 内 yaw 原点连续；epoch 变 = 原点被授权重锚）。守卫只在**同 epoch 内**比较帧；跨 epoch 的第一帧只做基线，不判故障、不发 `EV_TASK_FAULT`。跨 epoch 后若未收到 `reset:`（`EV_POSE_EPOCH`），以 `P_MOTION_LIMIT=0` **软停**（可自愈、不惊动 Safety），收到复位即撤销。

### 3.2 diff 草案
见 `patches/localization_epoch_guard.diff`（5 文件 / +49 −6）。要点：
1. `serial_reader.py`：`out_msg.child_frame_id = f"base_link#{self.session}"}`，复位时 `self.session += 1`（**不加话题、不改消息类型**，用已有字段承载 epoch，零 QoS 影响）。
2. `io/ros_io.py`：`on_odom` 存 `msg.child_frame_id`，新增 `pose_epoch()`（FakeBridge 无此方法时 `getattr` 自动降级）。
3. `core/events.py`：`EV_POSE_EPOCH`。
4. `tasks/mission.py:_reset_belief`：写完 P_POSE 后 `bus.publish(EV_POSE_EPOCH, why="reset", block=..., yaw=...)`。
5. `tasks/localization.py`：`setup()` 订阅；`tick()` 里先 `_drain_epoch()`；`_update_yaw_guard` 在 `dt` 判定前插 epoch 分支（`_yaw_prev` 重基线 + return），并置 `yaw_epoch_pending=True`；收到 `EV_POSE_EPOCH` 时 `reset_yaw_guard()` + 撤 hold。

### 3.3 测试草案（按 tests 现有纯脚本风格）
见 `patches/test_localization_epoch.py`：复用 `build()/FakeBridge/FakeClock`，用 `bridge.pose_epoch = lambda: seq` 注入。case 与预期断言：

| # | 场景 | 预期 |
|---|---|---|
| ⑯.1 | epoch 0→1，单帧 yaw −130.7→0（v=0） | `yaw_untrusted is False`；`EV_TASK_FAULT` **0 条**；`yaw_epoch_rebaselines==1`；`P_MOTION_LIMIT.speed_mps==0`（pending） |
| ⑯.2 | **同 epoch** 同样跳变（带牙反证） | `yaw_untrusted is True`；`EV_TASK_FAULT` 1 条；reason `yaw_jump` |
| ⑯.3 | epoch 变后收到 `EV_POSE_EPOCH`（reset） | hold 撤销（`P_MOTION_LIMIT is None`）；`yaw_untrusted False` |
| ⑯.4 | epoch 变但无 reset，随后 20 帧安静 | 不自动撤 hold（必须显式 reset；与 Safety "不自动恢复"一致） |
| ⑯.5 | 无 `pose_epoch` 能力的 FakeBridge（老替身） | 行为与今天逐位一致（⑫.2/⑫.3 全过） |
| ⑯.6 | 联动 `SafetyTask`：epoch 变后 3 拍 | `safety.stopped is False`（不进 SAFE_STOP） |

### 3.4 实现注意（必须写进实现卡）
- `P_MOTION_LIMIT` 已有**唯一写者** `_update_drift_guard`（`localization.py:1228-1326`，用 `_limit_state` 去重）。epoch hold 必须**并入同一个 state 元组**，不许第二个 `bb.set` 抢写（否则去重契约破裂、限速抖动）。
- 若不想动 serial_reader（最小 v0）：只做 mission 的 `EV_POSE_EPOCH` + localization 换事件重基线，**能救"brain 已跑再 reset"这一种**，救不了"重启 serial_reader"——而 10-22 现场正是后者。所以 v0 只能当止血，不能当根治。

## 4. SAFE_STOP 能不能不改代码清掉？（Q4）

**不能。锁存点：`tasks/safety.py:432-436`（`if first: self.stopped = True`）。**
- 恢复入口只有方法 `clear_safety()`（`:190-214`），而**全仓零调用者**（grep `clear_safety|EV_SAFETY_CLEAR`：除 `safety.py` 自身与 `tests/test_safety.py` 外无命中；`main.py` 无 `create_service`/`create_client`）。**[已证]**
- 自动恢复被刻意禁止：`:155-165`（条件解除只计数，不恢复）；故障原因经 `:326`（`_fault_reasons`）并入 reasons，`:502-509` 只要 `EV_TASK_FAULT` 过一次就永久有因。**[已证]**

**现场最小重启步骤**（不改代码）：
```bash
cd ~/dzrobot
cp -a ~/robot_logs/7_path.log ~/robot_logs/7_path.$(date +%H%M).log   # start_all 会覆盖日志+默认 --force
grep -E '^\s*auto_start' config/robot.yaml    # 确认 false；为 true 则先改，否则起栈 10 s 后自行发车
./start_all.sh stop        # 勿 pkill（会漏杀）
./start_all.sh start       # 或 restart；起栈后盯 7_path.log 的"安全系统就绪"
```
⚠️ **不要用** `tools/restart_node.sh path`——它指向旧核 `path_executor`（`docs/使用手册`：`restart_node.sh path` 指旧核；改路线/速度必须 `start_all.sh restart`）。**[已证（文档）]**

## 5. 副项：`/nav/waypoint` 单发丢失（Q5）

- **不是 QoS 不兼容**：`/nav/waypoint` = `QOS_EVENT`（`contract.py:73`）= depth 10 / **reliable** / **volatile**（`:40`）；`ros2 topic pub` 默认同族，能通。**[已证]**
- **不是 dzbrain 丢命令**：`ros_io.py:318-322` 入队上限 32，`take_waypoint_commands` 每拍取 8（`:455-459`），Mission 10 Hz；`mission.py:3893-3899` 一条坏命令只告警不崩。**[已证]**
- **最小解释**：`--once` 的发布者**建端点→发→立刻退出**，DDS 端到端匹配/发送窗口极短；volatile 意味着"匹配前发出的样本不重传"。C/B 两轮"没收到"最可能是**发车时 dzbrain 订阅还没建好**（`7_path_A.log:23-24` 位姿就绪门都要等 2 s）；D 轮连发 6 次才中，符合"匹配是概率事件"。**[推测，机制合理但无抓包]**
- **现场规程**：连发 **≥4 次**、间隔 ≥0.5 s；**判据只看日志行**（不是看命令退出码）：
  - 送达：`路线载入[多点命令]：路线[多点命令] N 点 / X m`（`mission.py:2824`，实见 :171）或 `复位 belief：<BLOCK> (<x>, <y>) yaw=<deg>°`（`:2809`）；
  - 收到但非法：`⚠️ 外部命令无效（已忽略）...`（`:3899`）；
  - 两者都没有 = 没送达，继续发。
  ```bash
  for i in 1 2 3 4; do ros2 topic pub --once /nav/waypoint std_msgs/msg/String "{data: '多点 E11 D11'}"; sleep 0.6; done
  tail -f ~/robot_logs/7_path.log | grep -E '路线载入|复位 belief|外部命令无效'
  ```
- **可选代码修复**（低成本、不动语义）：Mission 载入路线后把 `_cmd_stats`（`total/accepted/rejected`）写进遥测行，现场	extbf{看遥测}即可判送达；或把 `EV_ROUTE_LOADED` 中继成一个 ROS ack 话题（新增契约，需评审）。**不建议**给 `/nav/waypoint` 换 transient_local——发布侧不配合就永远不兼容。

## 6. 风险与未验证

1. **[未验证]** 部署副本 vs `src` 的 `+π/2` 口径（§1.4）——**最优先**现场抓一帧四元数；它决定"重启后地图 yaw 是否正确"，比本次闩锁更根本。
2. **[未验证]** 重启是否为"旧进程未死+新进程已起"的重叠（dt=0.056 s 更像两发布者交错而非干净重启的空窗）。若是，现场重启脚本必须先 kill 再 start（`start_all.sh stop` 已是进程组 TERM，问题可能出在单独 `ros2 run` 的 ad-hoc 重启）。
3. **[已证]** 副生缺陷：`7_path_A.log:173` 载入路线时 Mission 报 `SAFE_STOP → DRIVE`，下一拍又回 `DRIVE → SAFE_STOP`（Mission 载入路径 `mission.py:3922/3933` 未复查 `P_SAFETY`，`_write_phase` 的检查在 `:3688-3697`）。车没动，但遥测会短暂误报阶段，排障时容易看错。
4. **[推断]** A2/L8 与本方案无冲突：两者都没有 epoch 变化，判据不动；建议把"本方案上线后 A2/L8 回放仍报"写成卡的验收项（现有 ⑫.2/⑫.3 即覆盖）。
5. **[风险]** epoch 若被 `child_frame_id` 承载，RViz/TF 消费者若拿它当坐标系名会看到 `base_link#12`；本项目 TF 不使用该字段（无 `tf` 广播），但上线前应 grep 一次全仓消费者。

## 附：证据索引
- 日志：`docs/_work/TRACK-DAY-20261022/evidence/cam/7_path_A.log:139,141,153,154,171,183,185,189,597`；`.../cam/7_path_B.log:64`
- 守卫：`tasks/localization.py:113,664-760,762-767,778-816,818-844,1228-1326`
- 复位：`tasks/mission.py:2798-2809,3893-3939,3688-3697`；`car_localization/serial_reader.py:48,62,135,149-153,181-183,221-223,236-249`
- 安全：`tasks/safety.py:155-165,190-214,326,403-446,502-509`
- 接口：`io/contract.py:40,73,129-133`；`io/ros_io.py:229-239,318-322,455-459`
- 台账：`dzrobot_v2/docs/决策台账.md:97-100`（D-029：不调阈值、A2 不能判误触发、PIVOT 非原地转）
