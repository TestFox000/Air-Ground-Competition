#!/bin/bash
# 1) 给无人机布局发送器穿上 best_effort QoS（与车端 QOS_LINK 对齐）
sshpass -p duzhong ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null duzhong@192.168.137.52 'bash -s' <<"EOF"
set -e
cd ~/dzlink_tools
cp -n layout_batches.py layout_batches.py.bak_qos 2>/dev/null || true
grep -q "BEST_EFFORT" layout_batches.py && echo "already patched" || python3 - <<'PY'
import re, io
p = 'layout_batches.py'
s = open(p, encoding='utf-8').read()
s = s.replace("from std_msgs.msg import String",
  "from std_msgs.msg import String\nfrom rclpy.qos import QoSProfile, ReliabilityPolicy")
s = s.replace("self.pub = self.create_publisher(String, TOPIC_IN, 10)",
  "self.pub = self.create_publisher(String, TOPIC_IN, QoSProfile(depth=10, reliability=ReliabilityPolicy.BEST_EFFORT))")
s = s.replace("self.sub = self.create_subscription(String, TOPIC_OUT, self.on_car, 50)",
  "self.sub = self.create_subscription(String, TOPIC_OUT, self.on_car, QoSProfile(depth=50, reliability=ReliabilityPolicy.BEST_EFFORT))")
open(p, 'w', encoding='utf-8').write(s)
print("patched qos")
PY
pkill -f layout_batches.py 2>/dev/null || true
sleep 1
LOG=logs/layout_$(date +%Y%m%d_%H%M%S).log
nohup python3 -u layout_batches.py > $LOG 2>&1 &
echo "restarted layout pid=$! log=$LOG"
sleep 4
tail -8 $LOG
EOF
