#!/bin/bash
echo "=== 车端 config: drone / step / mission ==="
grep -nE "^  drone:|^  step:|enabled:|auto_start:|wait_timeout_s|pose_ready_wait_s|odom_watch_s" ~/dzrobot/config/robot.yaml | head -40
echo "=== 车端 topic 契约 ==="
grep -n "drone_in" ~/dzrobot/src/dzbrain/dzbrain/io/contract.py | head
echo "=== 车端机器人在不在 N10（日志最近启动横幅） ==="
grep -a "起点\|N10\|mission_reset\|布局" ~/robot_logs/7_path.log | tail -8
