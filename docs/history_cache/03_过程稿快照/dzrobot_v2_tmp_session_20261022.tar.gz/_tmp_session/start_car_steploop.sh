#!/bin/bash
cd ~/dzrobot
echo "=== stop ==="
bash start_all.sh stop 2>&1 | tail -5
sleep 2
echo "=== restart (hardware 6 nodes + map-mode dzbrain) ==="
bash start_all.sh restart > ~/robot_logs/start_layout_$(date +%H%M%S).log 2>&1
tail -6 ~/robot_logs/7_path.log 2>/dev/null
sleep 5
echo "=== kill map-mode dzbrain ==="
pkill -f "dzbrain.main" 2>/dev/null || true
sleep 2
pkill -9 -f "dzbrain.main" 2>/dev/null || true
sleep 1
echo "=== launch layout-mode dzbrain ==="
source /opt/ros/humble/setup.bash
source ~/dzrobot/install/setup.bash
source ~/dzrobot/dzros.env
cd ~/dzrobot
nohup python3 -u -m dzbrain.main --config ~/dzrobot/config/robot.yaml --force > ~/robot_logs/8_steploop.log 2>&1 &
echo "launched pid=$!"
sleep 22
echo "=== 8_steploop.log tail ==="
tail -60 ~/robot_logs/8_steploop.log
echo "=== procs ==="
pgrep -af "dzbrain.main|det_node|dzactuator_node" | head -10
