#!/bin/bash
source /opt/ros/humble/setup.bash
source ~/dzrobot/dzros.env
cd ~/dzrobot
echo "===PROC==="
pgrep -af 'python3 -u -m dzbrain.main'
pgrep -af 'layout_batches_p1'
echo "===HEAD==="
head -40 ~/robot_logs/7_path_p1.log 2>/dev/null
echo "===TAIL==="
tail -25 ~/robot_logs/7_path_p1.log 2>/dev/null
echo "===SENDER==="
tail -12 ~/robot_logs/layout_p1.log 2>/dev/null
