#!/bin/bash
echo "=== 8_steploop.log 头部 60 行 ==="
head -60 ~/robot_logs/8_steploop.log
echo "=== 步进/段/规划 关键行 ==="
grep -aE "步进|StepLoop|段|规划|WAIT|布局|target" ~/robot_logs/8_steploop.log | head -40
echo "=== 行数 ==="
wc -l ~/robot_logs/8_steploop.log
