#!/bin/bash
sshpass -p duzhong ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null duzhong@192.168.137.52 'sed -n "80,200p" ~/dzlink_tools/layout_batches.py' 2>/dev/null
