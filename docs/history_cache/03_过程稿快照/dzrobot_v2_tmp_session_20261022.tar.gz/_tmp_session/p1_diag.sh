#!/bin/bash
echo "===WHO==="
who
echo "===PROCS==="
ps -ef | grep -E 'qoder|merged_workspace|start_all|ros2 launch|dzactuator|serial_reader|layout_batches|dzbrain|cam_viewer' | grep -v grep | head -25
echo "===SYSTEMD==="
systemctl list-units --type=service --state=running 2>/dev/null | grep -iE 'dz|robot|ros' | head -10
echo "===CRON==="
crontab -l 2>/dev/null
echo "===UPTIME==="
uptime
