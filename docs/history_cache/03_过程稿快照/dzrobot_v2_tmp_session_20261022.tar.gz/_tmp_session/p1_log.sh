#!/bin/bash
LOG=/home/duzhong/robot_logs/7_path_p1.log
echo "===FIRST60==="
head -60 "$LOG" 2>/dev/null
echo "===LAYOUTLINES==="
grep -an 'field_layout' "$LOG" 2>/dev/null | head -25
echo "===V2==="
grep -an 'v2' "$LOG" 2>/dev/null | head -10
echo "===PLAN==="
grep -an '规划\|步进\|布局' "$LOG" 2>/dev/null | head -25
