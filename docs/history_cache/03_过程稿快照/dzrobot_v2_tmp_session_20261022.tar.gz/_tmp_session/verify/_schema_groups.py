# -*- coding: utf-8 -*-
import sys, collections
sys.path.insert(0, "src/dzbrain")
from dzbrain.core.config import SCHEMA
c = collections.Counter(k.split(".",1)[0] for k in SCHEMA)
print("SCHEMA keys:", len(SCHEMA))
for k,v in c.most_common(): print("%-24s %d" % (k,v))
