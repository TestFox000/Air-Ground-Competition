# -*- coding: utf-8 -*-
import ast, pathlib
base = pathlib.Path("src/dzbrain/dzbrain")
for rel in ["tasks/localization.py","tasks/safety.py","tasks/tracker.py","tasks/mission.py","tasks/aim.py","tasks/drone.py","tasks/fix.py"]:
    src = (base/rel).read_text(encoding="utf-8", errors="replace")
    doc = ast.get_docstring(ast.parse(src)) or ""
    print("="*20, rel)
    lines = [l.rstrip() for l in doc.strip().splitlines()]
    print("\n".join(lines[:70]))
