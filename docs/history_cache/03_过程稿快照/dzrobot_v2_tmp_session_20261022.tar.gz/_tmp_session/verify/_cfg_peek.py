# -*- coding: utf-8 -*-
import re, hashlib
for p in ["config/robot.yaml", "config/map.yaml"]:
    b = open(p, "rb").read()
    t = b.decode("utf-8", "replace")
    print("==", p, "bytes", len(b), "sha", hashlib.sha256(b).hexdigest()[:12], "crlf", b.count(b"\r\n"))
    if p.endswith("robot.yaml"):
        for key in ["mission_blocks", "tokens:", "engine", "auto_plan_enabled", "cruise_speed_mps"]:
            hits = [l.strip() for l in t.splitlines() if key in l]
            print(" ", key, hits[:4])
        m = re.search(r"mission_blocks:\s*(.*)", t)
        if m:
            v = m.group(1)
            print("  mission_blocks len:", len(v), "commas:", v.count(","))
            print("  first 160:", v[:160])
    else:
        for l in t.splitlines():
            if any(k in l for k in ["start:", "end:", "bridges:", "mines:", "obstacles:", "targets:", "barrier"]):
                print(" ", l.strip()[:160])
