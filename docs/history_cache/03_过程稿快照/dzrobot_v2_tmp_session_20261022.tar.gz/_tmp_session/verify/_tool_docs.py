# -*- coding: utf-8 -*-
import ast, pathlib
for p in sorted(pathlib.Path("tools").glob("*.py")):
    try:
        src = p.read_text(encoding="utf-8", errors="replace")
        doc = ast.get_docstring(ast.parse(src)) or ""
    except Exception as e:
        doc = "PARSE_ERR " + str(e)
    first = " / ".join([l.strip() for l in doc.strip().splitlines() if l.strip()][:2])
    print("%-28s %s" % (p.name, first[:220]))
