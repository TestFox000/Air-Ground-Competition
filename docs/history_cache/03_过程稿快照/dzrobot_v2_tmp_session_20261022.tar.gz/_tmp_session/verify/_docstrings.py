# -*- coding: utf-8 -*-
import ast, pathlib
base = pathlib.Path("src/dzbrain/dzbrain")
for rel in ["tasks/localization.py","tasks/safety.py","tasks/tracker.py","tasks/mission.py","tasks/aim.py","tasks/fix.py","tasks/drone.py","tasks/telemetry.py",
            "route/planner.py","route/validate.py","route/physics.py","pursuit/path.py","pursuit/controller.py","scout/__init__.py","io/contract.py","tools/sim.py"]:
    p = base / rel
    if not p.exists(): continue
    src = p.read_text(encoding="utf-8", errors="replace")
    m = ast.parse(src)
    doc = ast.get_docstring(m) or ""
    first = " / ".join([l.strip() for l in doc.strip().splitlines() if l.strip()][:4])
    funcs = [n.name for n in m.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))]
    print("### %s | %d lines | %d top-defs" % (rel, len(src.splitlines()), len(funcs)))
    print("  DOC:", first[:500])
    print("  DEF:", ", ".join(funcs[:18]))
