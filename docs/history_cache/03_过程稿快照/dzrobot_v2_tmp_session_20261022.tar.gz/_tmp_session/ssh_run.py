import sys, os, paramiko
host, user, arg = sys.argv[1], sys.argv[2], sys.argv[3]
cand = [os.environ.get("SSHKEY"), "C:/Users/TestFox/.ssh/id_rsa", "C:/Users/TestFox/.ssh/id_ed25519",
        os.path.expanduser("~/.ssh/id_rsa"), os.path.expanduser("~/.ssh/id_ed25519")]
keys = [k for k in cand if k and os.path.exists(k)]
if not keys:
    print("NO_KEY_FOUND", cand); sys.exit(3)
c = paramiko.SSHClient()
c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
last = None
for k in keys:
    try:
        c.connect(host, username=user, key_filename=k, timeout=8, banner_timeout=8, auth_timeout=8, look_for_keys=False, allow_agent=False)
        last = None
        break
    except Exception as e:
        last = e
if last is not None:
    print("CONN_FAIL:", type(last).__name__, last); sys.exit(2)
sftp = c.open_sftp()
if arg.startswith("@"):
    local = arg[1:]
    remote = "/tmp/_dsh_%d.sh" % os.getpid()
    sftp.put(local, remote)
    cmd = "bash " + remote
elif arg.startswith("<<"):
    remote = "/tmp/_dsh_%d.sh" % os.getpid()
    with sftp.open(remote, "w") as f:
        f.write(arg[2:])
    cmd = "bash " + remote
else:
    cmd = arg
_, out, err = c.exec_command(cmd, timeout=300, get_pty=False)
o = out.read().decode("utf-8", "replace"); e = err.read().decode("utf-8", "replace")
sys.stdout.buffer.write(o.encode("utf-8"))
if e.strip():
    sys.stdout.buffer.write(("\n[stderr]\n" + e).encode("utf-8"))
c.close()
