# -*- coding: utf-8 -*-
import os, sys, io, time, tarfile, paramiko

HOST, USER = "192.168.137.79", "duzhong"
KEYS = [os.environ.get("SSHKEY"), "C:/Users/TestFox/.ssh/id_rsa", "C:/Users/TestFox/.ssh/id_ed25519"]
KEY = [k for k in KEYS if k and os.path.exists(k)][0]

src = r"D:/User/Desktop/比赛存档/v1/dzrobot_v2/src/dzbrain"
tar_local = r"D:/User/Desktop/比赛存档/v1/dzrobot_v2/_tmp_session/dzbrain_src.tgz"

def make_tar():
    with tarfile.open(tar_local, "w:gz") as t:
        for root, dirs, files in os.walk(src):
            dirs[:] = [d for d in dirs if d != "__pycache__"]
            for f in files:
                if f.endswith(".pyc"):
                    continue
                p = os.path.join(root, f)
                t.add(p, arcname=os.path.relpath(p, src))
    return os.path.getsize(tar_local)

size = make_tar()
print("tar bytes:", size)

c = paramiko.SSHClient()
c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
c.connect(HOST, username=USER, key_filename=KEY, timeout=10, look_for_keys=False, allow_agent=False)
sftp = c.open_sftp()
sftp.put(tar_local, "/tmp/dzbrain_src.tgz")

def run(cmd, timeout=600):
    _, out, err = c.exec_command(cmd, timeout=timeout)
    o = out.read().decode("utf-8", "replace"); e = err.read().decode("utf-8", "replace")
    return o, e

ts = time.strftime("%Y%m%d_%H%M%S")
o, e = run(f"mkdir -p ~/dzrobot/_backups && tar czf ~/dzrobot/_backups/dzbrain_src_{ts}.tgz -C ~/dzrobot/src dzbrain && ls -l ~/dzrobot/_backups/dzbrain_src_{ts}.tgz")
print("[backup]", o.strip(), e.strip()[:200])

o, e = run("cd ~/dzrobot/src && tar xzf /tmp/dzbrain_src.tgz && ls dzbrain && md5sum dzbrain/main.py")
print("[extract]", o.strip()[:400], e.strip()[:300])

o, e = run("cd ~/dzrobot && source /opt/ros/humble/setup.bash && colcon build --packages-select dzbrain 2>&1 | tail -25", timeout=900)
print("[build]", o.strip()[-2000:])
c.close()
