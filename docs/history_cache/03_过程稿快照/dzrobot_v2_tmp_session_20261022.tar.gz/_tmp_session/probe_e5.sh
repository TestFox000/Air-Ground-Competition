#!/bin/bash
echo "=== 段 305 前后（E5） ==="
grep -an "E5\|v305\|段 305" ~/robot_logs/9_steploop_layout.log | tail -20
echo
echo "=== F5 停站期间 开火/瞄 ==="
grep -an "F5\|停站\|SETTLE\|ACQUIRE\|FIRE" ~/robot_logs/9_steploop_layout.log | tail -15
echo
echo "=== 云台日志 F5 时段 ==="
tail -25 ~/robot_logs/5_gimbal.log
