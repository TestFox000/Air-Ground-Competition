#!/bin/bash
cd ~/dzrobot/src/dzbrain
find . -type f \( -name '*.py' -o -name '*.toml' -o -name '*.cfg' -o -name '*.txt' \) -not -path '*/__pycache__/*' | sed 's|^\./||' | sort | while read f; do echo "$(md5sum "$f" | cut -d' ' -f1) $f"; done
