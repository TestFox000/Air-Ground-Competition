#!/bin/bash
sleep 20
echo "=== 车：段落相关 ==="
grep -aE "段规划|段 [0-9]+ 下发|到达|WAIT_INFO|SEGMENT_DONE|SAFE_STOP|ROS_LOST" ~/robot_logs/9_steploop_layout.log | tail -12
echo "=== 车：最新遥测 ==="
grep -a "^\[T\]" ~/robot_logs/9_steploop_layout.log | tail -6
echo "=== 机：最新 15 行 ==="
sshpass -p duzhong ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null duzhong@192.168.137.52 'tail -15 $(ls -t ~/dzlink_tools/logs/layout_next2_*.log | head -1)' 2>/dev/null
