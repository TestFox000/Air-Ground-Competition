#!/bin/bash
sshpass -p duzhong ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null duzhong@192.168.137.52 'bash -s' <<"EOF"
echo "=== procs ==="
pgrep -af layout_batches.py
echo "=== newest log ==="
L=$(ls -t ~/dzlink_tools/logs/layout_next2_*.log 2>/dev/null | head -1)
echo "$L"
tail -20 "$L"
EOF
