
import re, yaml, glob, os
p = r'D:\User\Desktop\比赛存档\v1\dzrobot_v2\config\robot.yaml'
raw = open(p, encoding='utf-8').read()
d = yaml.safe_load(raw)
# keys of interest
def find(d, keys, path=''):
    out=[]
    if isinstance(d, dict):
        for k,v in d.items():
            kp = f'{path}.{k}' if path else k
            if k in keys: out.append((kp, v))
            out += find(v, keys, kp)
    elif isinstance(d, list):
        for i,v in enumerate(d): out += find(v, keys, f'{path}[{i}]')
    return out
keys = {'pivot_angle_deg','pivot_enabled','pid_kp','pid_ki','pid_kd','pivot_dist_m','arrival_m','pivot_timeout_s','yaw_static_dps','yaw_rate_floor_dps','cruise'}
for kp,v in find(d, keys): print(f'{kp} = {v}')
mb = d.get('mission_blocks') or d.get('route',{}).get('tokens')
if isinstance(mb, list):
    print('mission_blocks len =', len(mb))
    print('first 10:', ' '.join(map(str,mb[:10])))
print('--- hand_v3 refs ---')
for f in glob.glob(r'D:\User\Desktop\比赛存档\v1\dzrobot_v2\**\*.yaml', recursive=True) + glob.glob(r'D:\User\Desktop\比赛存档\v1\dzrobot_v2\**\*.txt', recursive=True):
    if '_tmp_session' in f or 'node_modules' in f: continue
    try: t=open(f,encoding='utf-8',errors='ignore').read()
    except: continue
    if 'hand_v3' in t: print('FOUND in', f)
print('--- run8-11 logs ---')
for pat in [r'D:\User\Desktop\比赛存档\v1\dzrobot_v2\_tmp_session\**\*run1*', r'D:\User\Desktop\比赛存档\v1\dzrobot_v2\_tmp_session\**\*run8*', r'D:\User\Desktop\比赛存档\v1\dzrobot_v2\_tmp_session\**\*run9*']:
    for f in glob.glob(pat, recursive=True)[:20]: print(f)
