#!/bin/bash
# stop the interfering vision/gimbal/cam_viewer stack; keep chassis + localization
kill 11689 11683 11685 11687 2>/dev/null
pkill -f 'dzrknn_dataprocess.launch.py' 2>/dev/null
pkill -f 'det_node.launch.py' 2>/dev/null
pkill -f 'dzjudgment.launch.py' 2>/dev/null
pkill -f 'cam_viewer.py' 2>/dev/null
sleep 2
echo "===ENV==="
for pid in 8795 8880; do
  echo "PID $pid"
  tr '\0' '\n' < /proc/$pid/environ 2>/dev/null | grep -E 'ROS_DOMAIN_ID|RMW_IMPLEMENTATION|ROS_LOCALHOST_ONLY'
done
echo "===D118==="
source /opt/ros/humble/setup.bash
source /home/duzhong/dzrobot/dzros.env
echo "ROS_DOMAIN_ID=$ROS_DOMAIN_ID DZ_ROS_DOMAIN=$DZ_ROS_DOMAIN"
ros2 topic info /odom/localization -v 2>&1 | head -12
echo "===D0==="
ROS_DOMAIN_ID=0 ros2 topic info /odom/localization -v 2>&1 | head -8
echo "===PROC==="
ps -ef | grep -E 'cam_viewer|det_node|dzrknn|dzjudgment|dzactuator|serial_reader' | grep -v grep | head -12
