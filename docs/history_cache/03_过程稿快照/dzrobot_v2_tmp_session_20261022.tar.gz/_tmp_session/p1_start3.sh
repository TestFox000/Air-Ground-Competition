#!/bin/bash
source /opt/ros/humble/setup.bash
source ~/dzrobot/dzros.env
source ~/dzrobot/install/setup.bash
cd ~/dzrobot

if [ -f ~/robot_logs/pids/7_path_p1.pid ]; then kill "$(cat ~/robot_logs/pids/7_path_p1.pid)" 2>/dev/null; fi
pkill -f 'python3 -u -m dzbrain.main' 2>/dev/null
sleep 2

if ! pgrep -f 'python3 -u /home/duzhong/layout_batches_p1.py' >/dev/null; then
  setsid nohup python3 -u /home/duzhong/layout_batches_p1.py > ~/robot_logs/layout_p1.log 2>&1 &
  echo $! > ~/robot_logs/pids/layout_p1.pid
  sleep 2
fi

setsid nohup bash /home/duzhong/run_dzbrain_p1.sh > ~/robot_logs/7_path_p1.log 2>&1 &
echo $! > ~/robot_logs/pids/7_path_p1.pid
sleep 18

echo "===T==="
grep -aF '[T]' ~/robot_logs/7_path_p1.log | tail -8
echo "===EV==="
grep -aE 'v1|v2|L8|DRIVE|WAIT|布局' ~/robot_logs/7_path_p1.log | tail -12
echo "===SENDER==="
tail -10 ~/robot_logs/layout_p1.log 2>/dev/null
