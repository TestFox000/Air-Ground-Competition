#!/bin/bash
echo "=== start_all.sh 关键行 ==="
sed -n '150,235p' ~/dzrobot/start_all.sh
echo "=== 是否支持 layout 模式 ==="
grep -n "LAYOUT\|--map\|MAP_PATH\|no-map" ~/dzrobot/start_all.sh | head -20
