#!/bin/bash
sshpass -p duzhong ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null duzhong@192.168.137.52 'bash -s' <<"EOF" 2>&1
echo "=== procs ==="
ps -ef | grep -E "dzlink|supervisor|layout|dzuav|px4" | grep -v grep | head -10
echo "=== dzlink.env ==="
cat ~/dzlink_tools/dzlink.env 2>/dev/null | head -20
echo "=== dzbrain_pkg ==="
ls ~/dzlink_tools/dzbrain_pkg 2>/dev/null | head -20
echo "=== field_layout 出现处 ==="
grep -rl "field_layout" ~/dzlink_tools ~/dzbrain* 2>/dev/null | head -10
echo "=== layout_batches.py 头部 ==="
head -25 ~/dzlink_tools/layout_batches.py 2>/dev/null
EOF
