#!/bin/bash
echo "=== 车端最后 30 行 ==="
tail -30 ~/robot_logs/9_steploop_layout.log
