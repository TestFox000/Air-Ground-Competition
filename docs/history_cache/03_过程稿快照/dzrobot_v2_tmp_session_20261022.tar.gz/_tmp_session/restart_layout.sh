#!/bin/bash
sshpass -p duzhong ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null duzhong@192.168.137.52 'bash -s' <<"EOF"
source ~/dzlink_tools/dzlink.env
source /opt/ros/humble/setup.bash
cd ~/dzlink_tools
pkill -f layout_batches.py 2>/dev/null || true
sleep 1
LOG=logs/layout_$(date +%Y%m%d_%H%M%S).log
nohup python3 -u layout_batches.py > $LOG 2>&1 &
echo "restarted pid=$! log=$LOG"
sleep 5
pgrep -af layout_batches.py
echo "--- log tail ---"
tail -12 $LOG
EOF
