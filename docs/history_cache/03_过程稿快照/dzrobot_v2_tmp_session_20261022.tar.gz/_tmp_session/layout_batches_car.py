#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""layout_batches.py — 十批布局发送器（无人机侧，地面停放，只发点位信息）

按用户 2026-10-18 的分批表：
  批1 L..N 行7-11 (15)   批2 I..K 行7-11 (15)   批3 F..H 行7-11 (15)   批4 C..E 行7-11 (15)
  批5 A..B 行7-11 (10)   批6 A..B 行1-6 (12)    批7 C..E 行1-6 (18)    批8 F..H 行1-6 (18)
  批9 I..K 行1-6 (18)    批10 L..N 行1-6 (18)   合计 154 格
节奏：第 1 批立即（车启动门要等首份布局），之后每 10 s 一批。
目标格：known 图上"任务目标优先"（雷/射击停站/终点）→ 规划不了回退侦察前沿。
车每完成一段（MissionTask 阶段 DRIVE/STOP → IDLE）就推进检查点并下发新版本。
重发：当前布局每 1 s 重发一次（同版本，车端幂等），车重启后也能马上接上。
"""
import json
import os
import sys
import time

# car-side: dzbrain 由 install/setup.bash 提供

import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from rclpy.qos import QoSProfile, ReliabilityPolicy

from dzbrain.scout.layout import (
    TruthMap, MissionTarget, build_layout, plan_mission_route,
    mission_checkpoints, reachable_cells, frontier_target,
)
from dzbrain.core.config import Config

MAP_PATH = os.path.expanduser('~/dzrobot/config/map.yaml')
TOPIC_IN = '/dzlink/drone_to_car'
TOPIC_OUT = '/dzlink/car_to_drone'
BATCH_PERIOD_S = 10.0
RETRANSMIT_S = 1.0

BATCHES = [
    [f'{c}{r}' for c in 'LMN' for r in range(7, 12)],
    [f'{c}{r}' for c in 'IJK' for r in range(7, 12)],
    [f'{c}{r}' for c in 'FGH' for r in range(7, 12)],
    [f'{c}{r}' for c in 'CDE' for r in range(7, 12)],
    [f'{c}{r}' for c in 'AB' for r in range(7, 12)],
    [f'{c}{r}' for c in 'AB' for r in range(1, 7)],
    [f'{c}{r}' for c in 'CDE' for r in range(1, 7)],
    [f'{c}{r}' for c in 'FGH' for r in range(1, 7)],
    [f'{c}{r}' for c in 'IJK' for r in range(1, 7)],
    [f'{c}{r}' for c in 'LMN' for r in range(1, 7)],
]


class Sender(Node):
    def __init__(self):
        super().__init__('layout_batches')
        self.truth = TruthMap.load(MAP_PATH)
        self.cfg = Config.from_dict({})
        self.pub = self.create_publisher(String, TOPIC_IN, QoSProfile(depth=10, reliability=ReliabilityPolicy.BEST_EFFORT))
        self.sub = self.create_subscription(String, TOPIC_OUT, self.on_car, QoSProfile(depth=50, reliability=ReliabilityPolicy.BEST_EFFORT))
        self.known: set[str] = set()
        if os.environ.get('LAYOUT_KNOWN_ALL') == '1':
            ac = getattr(self.truth, 'all_cells', None)
            if callable(ac):
                self.known = set(ac())
            elif ac:
                self.known = set(ac)
            else:
                self.known = {f'{c}{r}' for c in 'ABCDEFGHIJKLMN' for r in range(1,12)}
        self.version = int(os.environ.get('LAYOUT_VERSION_BASE','0'))
        self.layout: dict | None = None
        self.batch_idx = int(os.environ.get('LAYOUT_BATCH_IDX','0'))
        self.car_block = os.environ.get('LAYOUT_CAR_BLOCK', self.truth.start)
        self.phase = ''
        self.t0: float | None = None
        self.covered: set[str] = set()
        if os.environ.get('LAYOUT_COVERED'):
            self.covered = set(os.environ['LAYOUT_COVERED'].split(','))
        self.done_stops: set[str] = set()
        self.target: MissionTarget | None = None
        self.last_pub = 0.0
        self._last_state_seq = -1
        self.timer = self.create_timer(0.25, self.tick)
        if self.batch_idx >= len(BATCHES):
            self.target = self.decide()
            self.publish_layout('resume')
        self.log(f'START truth start={self.truth.start} end={self.truth.end} '
                 f'mines={sorted(self.truth.mines)} stops={sorted(self.truth.targets)}')
        if self.known and not self.batch_idx < len(BATCHES):
            self.target = self.decide()
            self.publish_layout('resume')
        else:
            self.add_batch()

    def log(self, msg: str) -> None:
        line = time.strftime('%H:%M:%S ') + msg
        print(line, flush=True)

    # ---------------- 车状态 ----------------
    def on_car(self, msg: String) -> None:
        try:
            d = json.loads(msg.data)
        except Exception:
            return
        if not isinstance(d, dict) or d.get('type') != 'car_state':
            return
        seq = int(d.get('seq') or 0)
        if seq == self._last_state_seq:
            return
        self._last_state_seq = seq
        block = str(d.get('block') or '').strip().upper()
        if block:
            self.car_block = block
        new_phase = str(d.get('phase') or '')
        prev = self.phase
        self.phase = new_phase
        if new_phase != prev:
            self.log(f'CAR phase {prev!r} -> {new_phase!r} block={self.car_block}')
        # ★2026-10-18 D1 修复后：车端 phase 来自 StepLoop（DRIVING/SEGMENT_DONE/WAIT_INFO/FINISH），
        #   drone.py 已改为上报 P_CAR_STATE，不再有 MissionTask 的 DRIVE/STOP → IDLE。
        if new_phase == 'SEGMENT_DONE' and prev != 'SEGMENT_DONE':
            self.on_segment_done()
        elif new_phase == 'FINISH' and prev != 'FINISH':
            self.log('FINISH end reached')
        elif new_phase == 'WAIT_INFO' and prev != 'WAIT_INFO':
            # ★实跑发现：车到站后 SEGMENT_DONE 窗口极短（一个 tick 内就转 WAIT_INFO），
            #   1.4 Hz 的车状态采样会漏掉它。车状态里的 block 已到 target ⇒ 视为段完成。
            if self.target is not None and self.car_block == self.target.block:
                self.log(f'WAIT_INFO at target {self.car_block}（漏采 SEGMENT_DONE）→ 视为段完成')
                self.on_segment_done()
            else:
                self.log(f'CAR WAIT_INFO block={self.car_block}（规划失败/无目标，等新布局）')

    # ---------------- 目标决策 ----------------
    def decide(self):
        known = set(self.known)
        car = self.car_block or self.truth.start
        planned = None
        try:
            planned = plan_mission_route(
                known, self.truth, from_block=car,
                covered_mines=self.covered, done_stops=self.done_stops,
                cfg=self.cfg, max_stops=2, max_seconds=2.0)
        except Exception as exc:  # noqa: BLE001
            self.log(f'plan err {type(exc).__name__}: {exc}')
        if planned:
            engine, tokens = planned
            cps = mission_checkpoints(tokens, self.truth,
                                      covered_mines=self.covered,
                                      done_stops=self.done_stops, max_stops=2)
            dist = reachable_cells(known | {car}, self.truth, car)
            for cp in cps:
                if cp.block in dist:
                    self.log(f'decide: mission checkpoint {cp.block} kind={cp.kind} engine={engine}')
                    return cp
        fb = frontier_target(known, self.truth, car,
                             covered_mines=self.covered, done_stops=self.done_stops)
        if fb is not None:
            self.log(f'decide: frontier {fb.block} kind={fb.kind}')
            return fb
        return MissionTarget(self.truth.end, 'end')

    def publish_layout(self, reason: str) -> None:
        self.version += 1
        target = self.target.block if self.target else ''
        layout = build_layout(
            self.truth, self.known, version=self.version, ts=time.time(),
            car_block=self.car_block, segment_id=self.version,
            target_cell=target, covered_mines=self.covered,
            done_stops=self.done_stops, cfg=self.cfg, max_stops=2)
        self.layout = layout
        self.send()
        self.log(f'PUB v{self.version} known={len(self.known)} target={target} '
                 f'kind={self.target.kind if self.target else "?"} reason={reason}')

    def send(self) -> None:
        if self.layout is None:
            return
        msg = String()
        msg.data = json.dumps(self.layout, ensure_ascii=False, separators=(',', ':'))
        self.pub.publish(msg)
        self.last_pub = time.monotonic()

    # ---------------- 事件 ----------------
    def add_batch(self) -> None:
        if self.batch_idx >= len(BATCHES):
            return
        batch = BATCHES[self.batch_idx]
        self.known |= set(batch)
        self.batch_idx += 1
        self.log(f'BATCH {self.batch_idx}/10 +{len(batch)} known={len(self.known)}')
        self.target = self.decide()
        self.publish_layout(f'batch{self.batch_idx}')

    def on_segment_done(self) -> None:
        if self.target is None:
            return
        block = self.car_block
        tgt = self.target.block
        if block != tgt:
            self.log(f'segment done at {block} (target was {tgt}) — keep target')
            return
        kind = self.target.kind
        if kind == 'mine':
            self.covered.add(block)
        elif kind == 'stop':
            self.done_stops.add(block)
        self.log(f'SEGMENT DONE {block} kind={kind} covered={len(self.covered)}/8 done_stops={len(self.done_stops)}/2')
        if block == self.truth.end or (kind == 'end'):
            self.log('FINISH end reached')
            return
        self.target = self.decide()
        self.publish_layout(f'done:{block}')

    def tick(self) -> None:
        now = time.monotonic()
        if self.t0 is None:
            if self.phase:
                self.t0 = now
                self.log(f't0 set (car phase {self.phase!r}); batch2 at +10s')
        elif self.batch_idx < len(BATCHES):
            due = self.t0 + BATCH_PERIOD_S * self.batch_idx
            if now >= due:
                self.add_batch()
        if now - self.last_pub >= RETRANSMIT_S:
            self.send()


def main() -> int:
    rclpy.init()
    node = Sender()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        try:
            rclpy.shutdown()
        except Exception:
            pass
    return 0


if __name__ == '__main__':
    sys.exit(main())