#!/bin/bash
sleep 35
echo "=== 车：段落/停站 ==="
grep -aE "段规划|段 [0-9]+ 下发|到达|WAIT_INFO|SEGMENT_DONE|SAFE_STOP|ROS_LOST|开火|发射|命中" ~/robot_logs/9_steploop_layout.log | tail -16
echo "=== 车：最近遥测 6 行 ==="
grep -a "^\[T\]" ~/robot_logs/9_steploop_layout.log | tail -6
echo "=== 机：最近 12 行 ==="
sshpass -p duzhong ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null duzhong@192.168.137.52 'tail -12 $(ls -t ~/dzlink_tools/logs/layout_next2_*.log | head -1)' 2>/dev/null
