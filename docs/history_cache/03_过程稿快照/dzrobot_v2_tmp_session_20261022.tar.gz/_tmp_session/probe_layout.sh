#!/bin/bash
echo "=== drone: layout_batches 关键段 ==="
sshpass -p duzhong ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null duzhong@192.168.137.52 'sed -n "1,80p" ~/dzlink_tools/layout_batches.py' 2>/dev/null
echo "=== drone: 启动方式/README ==="
sshpass -p duzhong ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null duzhong@192.168.137.52 'grep -n "__main__\|argparse\|def main\|INPUT\|argv" ~/dzlink_tools/layout_batches.py | head -20; echo ---; ls ~/dzlink_tools/*.sh; echo ---; ls ~/dzlink_tools/perception | head' 2>/dev/null
echo "=== car: 7_path.log 尾部 ==="
tail -25 ~/robot_logs/7_path.log 2>/dev/null
echo "=== car: 当前 dzbrain 进程 ==="
pgrep -af "dzbrain.main" | head -3
