#!/bin/bash
cd /home/duzhong
set +u
source /opt/ros/humble/setup.bash
source /home/duzhong/dzrobot/install/setup.bash
set -u
export ROS_DOMAIN_ID=118
pkill -f 'dzbrain.main' 2>/dev/null || true
pkill -f 'p1_test_layout.py' 2>/dev/null || true
sleep 2
nohup timeout 240 python3 -u /home/duzhong/p1_test_layout.py > /tmp/p1_test_layout.log 2>&1 &
sleep 3
nohup python3 -u -m dzbrain.main --config /home/duzhong/dzrobot/config/robot.yaml --force > /tmp/dzbrain_p1.log 2>&1 &
echo started
