#!/bin/bash
set -e
cd /home/duzhong/dzrobot
source /opt/ros/humble/setup.bash
source install/setup.bash
source dzros.env
exec python3 -u -m dzbrain.main --config /home/duzhong/dzrobot/config/robot.yaml --map /tmp/__no_map_for_steploop__.yaml --force
