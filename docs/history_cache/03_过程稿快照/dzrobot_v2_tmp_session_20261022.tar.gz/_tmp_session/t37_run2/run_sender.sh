#!/bin/bash
cd /home/duzhong/dzlink_tools || exit 1
. ./dzlink.env
. /opt/ros/humble/setup.bash
exec python3 -u layout_batches.py
