#!/bin/bash
source /opt/ros/humble/setup.bash
source ~/dzrobot/dzros.env
source ~/dzrobot/install/setup.bash
cd ~/dzrobot

# kill stale SSH wrapper shells that contain 'dzbrain.main' in their cmdline
kill 10406 11229 12346 12706 2>/dev/null
sleep 1

# make sure the layout sender is alive
if ! pgrep -f 'python3 -u /home/duzhong/layout_batches_p1.py' >/dev/null; then
  setsid nohup python3 -u /home/duzhong/layout_batches_p1.py > ~/robot_logs/layout_p1.log 2>&1 &
  echo $! > ~/robot_logs/pids/layout_p1.pid
  sleep 2
fi

setsid nohup bash /home/duzhong/run_dzbrain_p1.sh > ~/robot_logs/7_path_p1.log 2>&1 &
echo $! > ~/robot_logs/pids/7_path_p1.pid
sleep 18

echo "===HEAD==="
head -20 ~/robot_logs/7_path_p1.log 2>/dev/null
echo "===T==="
grep -aF '[T]' ~/robot_logs/7_path_p1.log | tail -8
echo "===EV==="
grep -aE 'v1|L8|DRIVE|WAIT' ~/robot_logs/7_path_p1.log | tail -10
echo "===SENDER==="
tail -10 ~/robot_logs/layout_p1.log 2>/dev/null
