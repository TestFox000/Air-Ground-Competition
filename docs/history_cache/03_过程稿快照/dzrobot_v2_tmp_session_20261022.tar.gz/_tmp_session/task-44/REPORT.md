# task-44 · T-HEAD 航向闩锁修复报告

> 卡号：task-44（T-HEAD）｜owner：forensics｜日期：2026-10-19｜状态：本地完成，未 commit / 未部署 / 未实车
> 写域：`tasks/localization.py` + `tests/test_localization.py` + `tests/test_drift.py` + 本报告。
> 未改 `config/**`、`main.py`、`mission.py`；`frozen.json` 的 localization.py 登记由 Lead 预先加入（card `T-HEAD/task-44`），本次未再改。

## 0. 一句话结论

A2 的 79.8°/s @ v=0.19 是**差速底盘正常转向**，旧 `Ackermann + 恒定 floor` 模型把上限压到 75.8°/s 而误停；
改为差速包络 `max(60, 525×v)` 后 A2 不误停，14:59 K9 真事故（120.3°/s @ 0.112）与单帧 90° 跳变仍会停；
闩锁由「永久」改为「连续 20 个可信新帧自动复位 + `reset_yaw_guard()` 人工复位」。

## 1. 根因（证据）

- 实车日志根仓 `_tmp_session/report_20261018/7_path.log`:1129-1144：
  - `[T] A1 DRIVE ... yaw131.3 v0.314 st+29.2` → 下一段 `段26 s10.57`；
  - `🧭❌ 航向失去可信（yaw_rate_over_kinematic）：yaw 79.8°/s > 运动学上限 75.8°/s（v=0.19 m/s，Ackermann 极限 40.6°/s）`；
  - 随后 `SAFE_STOP`，整轮停在 26/55；之后 yaw 显示 `-142.7`（停车后仍有航向跳变）。
- 旧判据：`ω_max = margin·v·tan(δmax)/L + yaw_rate_floor_dps`，把差速底盘当成 Ackermann；
  A2 时 v=0.19 的 Ackermann 极限仅 40.6°/s，加 floor 后 75.8°/s，**79.8 只超 4°/s**。
- 旧闩锁：`yaw_untrusted=True` 后**永不复位**（docstring 明写「与 Safety 不自动恢复同语义」），
  即使条件消失，后续所有运行都带病；这是「永久锁死」的直接来源。
- ★如实说明：A2 日志里 yaw 从 131.3 到 -142.7 的跳变幅度很大，**不排除该次也是航向链跳变而非正常过弯**；
  本轮按 Lead 裁决把它当「正常差速转向」处理；若后续证明是跳变，IMU 矛盾判据是唯一兜底（见 §5 风险）。

## 2. 改法（localization.py）

### 2.1 差速底盘偏航率包络（替换 Ackermann + floor）

```
v < yaw_min_speed_mps(0.03) : limit = yaw_static_dps(45)
v >= yaw_min_speed_mps       : limit = max(yaw_diff_spin_dps(60),
                                        yaw_diff_gain_dps_per_mps(525) × v)
```

- 60°/s：差速底盘低速/原地转向能力（正常 PIVOT 约 30~58°/s）；
- 525°/s per m/s：A2 实测 79.8/0.19 = 420，取 +25% 余量；
- 45°/s：静止期（v<0.03）上限，保留 14:59 事故静止段 169.2°/s 的检出；
- 新增代码常量：`_DEFAULT_YAW_DIFF_GAIN_DPS_PER_MPS / _DEFAULT_YAW_DIFF_SPIN_DPS /
  _DEFAULT_YAW_JUMP_DEG / _DEFAULT_YAW_CLEAR_TICKS / _DEFAULT_YAW_IMU_CHECK_DPS`；
  可用未登记键 `localization.yaw_diff_*`、`yaw_jump_deg`、`yaw_clear_ticks`、`yaw_imu_check_dps` 覆盖（本轮未改 config）。
- 旧 SCHEMA 键 `yaw_kin_margin / yaw_rate_floor_dps / yaw_abs_floor_dps` 已不再被代码读取，**清理属后续 config 卡**，本卡未动。

### 2.2 新增判据

1. **单帧跳变**：`|Δyaw| > yaw_jump_deg(30°)` ⇒ 立即判故障（reason `yaw_jump`），不等 3 帧；
2. **IMU 交叉核对**：位姿率 > `yaw_imu_check_dps(30)` 且 IMU `|gz| < 0.35×位姿率` ⇒ `yaw_pose_imu_mismatch`；
   无 IMU/过期自动降级为纯位姿判据；
3. 原有帧间隔/位姿连续性/连续 N 帧闸保留。

### 2.3 闩锁可恢复

- 故障后仍走 `P_MOTION_LIMIT{speed_mps:0}` + `EV_TASK_FAULT`（Safety 锁存 SAFE_STOP 的既有通路不变）；
- **自动复位**：连续 `yaw_clear_ticks(20)` 个可信新帧 ⇒ `yaw_untrusted=False`，撤销限速请求；
- **人工复位**：新增 `reset_yaw_guard(now=None)`，清闩锁/原因/计数并写 `P_MOTION_LIMIT=None`；
- 复位只清「航向守卫」；Safety 的 SAFE_STOP 仍需显式 `clear_safety()`（刻意不自动恢复，见 safety.py 顶部语义）。
- 遥测新增：`yaw_guard_recoveries / yaw_manual_resets / yaw_clear_ticks / yaw_jump_deg /
  yaw_diff_gain_dps_per_mps / yaw_diff_spin_dps / yaw_last_dyaw_deg`；
  `P_MOTION_LIMIT` 载荷新增 `yaw_guard_recoveries`。

## 3. A2 复跑数据

> 说明：A2 的原始 5 Hz 帧序列未落盘，以下用**事故数字重建**的恒定圆弧帧回放（v=0.19、yaw=79.8°/s、dt=0.2、40 帧），
> 只验证判据边界，不冒充原始轨迹。

| 项 | 旧模型 | 新模型 |
|---|---|---|
| v | 0.19 m/s | 0.19 m/s |
| 实测 yaw 率 | 79.8°/s | 79.8°/s |
| 上限 | 75.8°/s（Ackermann 40.6 + floor；日志实值） | **99.7°/s**（525×0.19） |
| 超限样本 | ≥3 → 判故障 | **0** |
| 结果 | `yaw_untrusted=True`、停 26/55 | **`yaw_untrusted=False`、P_MOTION_LIMIT=None** |

测试输出：`A2 案例... [untrusted=False bad=0 samples=39 max=79.8 limit=99.7]`。

## 4. 回归对照（真事故 / 真跳变仍停）

| 用例 | 输入 | 结果 |
|---|---|---|
| 14:59 K9 事故片段 | 33 帧真实片段，峰值 120.3°/s | 仍判 `yaw_rate_over_diff`，trip ≤ 5.0 s |
| 静止期被转 | 真实静止片段，峰值 169.2°/s | 仍判 `yaw_static_rotation`，trip 0.6 s |
| 单帧真跳变 | 平稳 4 帧 + 单帧 +90° | **立即** `yaw_jump`，P_MOTION_LIMIT=0、EV_TASK_FAULT 1 条 |
| 静止正常转向 | 40°/s（低于 45） | 不误报（bad=0） |
| 正常 90° 转弯 | 0.35 m/s、73.7°/s | 不误报（上限 183.7） |
| 遥控接管 | 静止 169°/s + manual_override | 只记账，不判故障 |
| 闩锁恢复 | 169°/s 片段 → 25 帧干净 | 20 帧后 `untrusted=False`、recoveries=1、limit=None |
| 人工复位 | 同上 → `reset_yaw_guard()` | untrusted=False、resets=1、reason='' |

## 5. 风险与未决（如实）

1. **A2 日志本身可疑**：yaw 131.3 → -142.7（约 -274°，归一化 -86°）不似单纯过弯；
   若实为航向链跳变，新模型会把 79.8°/s 的持续变化当可信 —— IMU 矛盾判据是唯一兜底；
   下次实车必须抓 A2 的 `[T]`/telemetry 与 IMU gz 对照，确认这次到底是转向还是跳变。
2. **差速包络增益 525 是标定值**（420 + 25%），不是从底盘固件推出来的；换底盘/换电机/改轮距后需重标。
3. **静止上限 45°/s 未提高**：若现场 PIVOT 实际超过 45°/s 且 v<0.03，仍可能误停；本轮未实车验证。
4. 自动复位只清守卫，Safety 仍锁存；现场恢复流程仍是「先查原因 → `clear_safety()`」。
5. 未跑全量 37 套（当前基线 13 套红，task-44 只保证相关套件与门禁）。

## 6. 测试命令与结果（2026-10-19）

```powershell
cd D:\User\Desktop\比赛存档\v1\dzrobot_v2
$env:PYTHONIOENCODING='utf-8'
python src\dzbrain\tests\test_localization.py   # 171/171 全部通过  exit 0
python src\dzbrain\tests\test_drift.py          # 24/24 全部通过    exit 0
python src\dzbrain\tests\test_safety.py         # 190/190 全部通过  exit 0
python src\dzbrain\tests\test_motion_limit.py   # 15/17（2 红为既有 C 类：5.2/5.3，见下）
python tools\wf\check.py                         # GREEN exit 0
```

- `test_motion_limit` 的 2 条失败与 10-18 全量回归基线**逐条相同**（`_tmp_full_regression/test_motion_limit.py.log`:26-30）：
  5.2 期望 drift_slow_after/drift_stop_after/boundary 旧值；5.3 期望 44 点路线。**不是本卡引入**。
- `check.py`：

```
冻结区脏文件: 1
  [OK ] src/dzbrain/dzbrain/tasks/localization.py
  [OK ] 文档链接 checked files: 76 broken: 0
  [OK ] 复用门禁 新文件: 0  未登记: 0  存量 tools 未登记(warn): 14
结果: GREEN
```

（另有 2 条 WARN：main.py/drone.py 的 frozen 登记已失效，属 car-stepper 卡，未动。）

## 7. diff 摘要（相对本卡开始前快照）

| 文件 | 行数 |
|---|---|
| `src/dzbrain/dzbrain/tasks/localization.py` | +161 / −91 |
| `src/dzbrain/tests/test_localization.py` | +103 / −5 |
| `src/dzbrain/tests/test_drift.py` | +24 / −2 |
| 本报告 | 新增（未跟踪） |

## 8. 回滚点

- 编辑前快照：`C:\Users\TestFox\AppData\Local\Temp\task44_preedit\`（localization.py / test_localization.py / test_drift.py / frozen.json）。
- 未 commit；回滚命令：

```powershell
cd D:\User\Desktop\比赛存档\v1\dzrobot_v2
git checkout -- src/dzbrain/dzbrain/tasks/localization.py src/dzbrain/tests/test_localization.py src/dzbrain/tests/test_drift.py
```

## 9. 未做 / 后续卡

- 未实车、未部署、未 commit；
- 旧 SCHEMA 三键（kin_margin/rate_floor/abs_floor）清理 → config 卡；
- A2 实车复跑（抓 IMU gz 对照）→ 下次跑车卡；
- `test_motion_limit` 5.2/5.3 重钉 → 既有 C 类，按 D-023 处理；
- 全量 37 套 → 按 D-023 的 13 套分批收口，不在本卡范围。