# v4.0-closeout 冻结区在途验证（2026-10-18）

> 卡：`v4.0-closeout`｜owner：schema-owner｜到期：2026-10-20
> 范围：3 个冻结区文件（pose_stale 事故修复）
> 环境：Windows / Python 3.12；`PYTHONPATH=dzrobot_v2/src/dzbrain`、`PYTHONIOENCODING=utf-8`
> 工作区：HEAD **`f883c52`**（本卡提交）；提交前基线 `193567a`

## 1. 改动摘要（`git diff --stat`）

```
 src/dzbrain/dzbrain/core/config.py |  10 ++
 src/dzbrain/dzbrain/io/ros_io.py   | 116 ++++++++++++++++++++
 src/dzbrain/dzbrain/main.py        | 267 ++++++++++++++++++++++++++++++++++++-
 3 files changed, 392 insertions(+), 1 deletion(-)
```

| 文件 | 改动 | 对应冻结登记理由 |
|---|---|---|
| `core/config.py:538-546` | 新增 `step.pose_ready_wait_s`（默认 8.0 s，0=关闭）与 `step.odom_watch_s`（默认 6.0 s，0=关闭），均带 SCHEMA 范围 | 位姿就绪门 + 运行期看门狗 |
| `io/ros_io.py:29-38` | 新增 `REQUIRED_SUBSCRIPTIONS` 单一清单（9 个逻辑句柄）与 `required_subscription_topics()`；新增 `WATCHED_TOPICS`/`ros_env()`/`env_problems()` 自检纯函数 | 订阅清单 + 启动自检计数 |
| `main.py` | 新增 `STEP_PHASE_ROS_LOST`、`_odom_watch()`、`_to_ros_lost()`、`_wait_for_pose_ready()`、启动自检；`run_live` 把 `ros_lost` 映射为 **exit 5**（另有环境/就绪失败 exit 5） | 退出码 5 + 运行期看门狗 |

## 2. 复跑命令与结果（全部实跑）

### 2.1 牙测试（本卡主套）

```powershell
cd D:\User\Desktop\比赛存档\v1\dzrobot_v2
$env:PYTHONPATH='D:\User\Desktop\比赛存档\v1\dzrobot_v2\src\dzbrain'; $env:PYTHONIOENCODING='utf-8'
python src\dzbrain\tests\test_stepper.py ; $LASTEXITCODE
```

**实测：`结果：92/92 全部通过 ✅`，exit 0。** 其中直接覆盖本卡：

- 13.1 订阅契约：`/odom/localization` 在必订清单里（QoS `best_effort depth=10`）；
- 13.2 布局模式装配：Localization/Safety/Tracker/Mission 都在组内；
- 13.3 组内任务持有**同一个** bridge 实例（无二次构造丢订阅）；
- 13.4/13.5 注入一帧 odom ⇒ `P_POSE` 被覆盖、`P_POSE_RAW`/`P_ODOM_AGE` 同时落盘；
- 13.6 无 odom ⇒ 位姿就绪门 False，并打印 `ros2 topic info` / `ros2 node list` / `/proc/self/environ` 三条诊断；
- 13.7/13.8 域号分叉（`ROS_DOMAIN_ID=0` vs `DZ_ROS_DOMAIN=118`）报 error；一致时只告警；
- 13.9 ★ DRIVING 中断流 ⇒ `STEP_PHASE_ROS_LOST`；
- 13.10 `ROS_LOST` 后主循环返回 `ros_lost`（`run_live` 映射 exit 5）；
- 13.11 ★ 布局模式缺 odom ⇒ `run_live` **rc=5**、`step_calls=0`；
- 13.12 同一装配下 odom 就绪 ⇒ 门放行、进入步进循环并正常收尾（rc=0）。

### 2.2 关联回归

| 套件 | 结果 | 备注 |
|---|---|---|
| `test_drone.py` | **174/174 exit 0** | 无人机/布局链路无回归 |
| `test_core.py` | **56/56 exit 0** | Lead 已在 `6eef608` 按「重钉=对齐真源、不降低判据」把 `aim.lead_time_s` 断言从 0.0 改到 0.27（仍要求参数段生效且与真源一致）。**本卡三文件不涉及该断言** |
| `tools/wf/check.py` | **GREEN exit 0** | 收口后冻结区仅剩 cpp 一条 in_flight（见 §2.4） |

### 2.3 收口提交与门禁

```powershell
git add -- src/dzbrain/dzbrain/core/config.py src/dzbrain/dzbrain/io/ros_io.py src/dzbrain/dzbrain/main.py
git commit -m "v4.0-closeout：位姿就绪门 + ROS_LOST 看门狗 + 订阅自检"
# => f883c52（3 files changed, 392 insertions(+), 1 deletion(-)）

python tools\wf\check.py ; $LASTEXITCODE
# => 冻结区脏文件: 1 / [OK] src/dzrknn_dataprocess/...cpp / 结果: GREEN / EXIT=0
```

`tools/wf/frozen.json` 已删掉本卡 3 条 in_flight（config.py/ros_io.py/main.py），保留 `gimbal-patch` 的 cpp 一条；该文件改动**未单独提交**（工作区 M），由 Lead 决定是否随工作流收口入库。

### 2.4 关键值实测

```powershell
python -c "from dzbrain.core.config import Config; c=Config.load('config/robot.yaml'); print(c.get('step.pose_ready_wait_s'), c.get('step.odom_watch_s'))"
# => 8.0 6.0
```

## 3. 结论与回滚点

- **结论：本卡三文件已提交 `f883c52`；test_stepper 92/92、test_drone 174/174、test_core 56/56 全绿；`tools/wf/check.py` GREEN（冻结区仅剩 cpp 一条）。不满足“证不出来”的回滚条件。**
- 回滚点（若 Lead 判定需要）：`git revert f883c52`（或 `git restore --source=f883c52^ -- <三个文件>`），并恢复 `tools/wf/frozen.json` 中三条 in_flight；执行前备份 `git diff f883c52^ f883c52 > _tmp_session/v4.0-closeout/rollback.patch`。
- **未验证项（必须如实记录）**：车端/ROS 图上的真实 DDS 行为（本机无 rclpy）——只验证了纯函数与替身测试；车端放行前需在车上跑 `start_all.sh`，看启动自检（订阅清单/域号）与缺 odom 时 exit 5 的诊断输出。**此项不影响 Python 层收口，但必须跟着卡走上车补验。**
