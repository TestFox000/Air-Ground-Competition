#!/bin/bash
cd ~/dzrobot
cp -n config/robot.yaml config/robot.yaml.bak_steploop 2>/dev/null
sed -i 's/^    auto_plan_enabled: false/    auto_plan_enabled: true/' config/robot.yaml
grep -n "auto_plan_enabled" config/robot.yaml | head -3
pkill -f "dzbrain.main" 2>/dev/null || true
sleep 2
pkill -9 -f "dzbrain.main" 2>/dev/null || true
sleep 1
source /opt/ros/humble/setup.bash
source ~/dzrobot/install/setup.bash
source ~/dzrobot/dzros.env
cd ~/dzrobot
nohup python3 -u -m dzbrain.main --config ~/dzrobot/config/robot.yaml --map /tmp/__no_map_for_steploop__.yaml --force > ~/robot_logs/9_steploop_layout.log 2>&1 &
echo "launched pid=$!"
sleep 25
echo "=== 关键行 ==="
grep -aE "布局模式|步进|场地布局|段|规划|WAIT|出发|phase|IDLE|DRIVE|STOP" ~/robot_logs/9_steploop_layout.log | head -40
echo "=== tail ==="
tail -20 ~/robot_logs/9_steploop_layout.log
