# task-42 / T-D1B：段完成回报闩锁 + D-022 完整布局例外 · 交付

> 写域：`src/dzbrain/dzbrain/main.py`、`src/dzbrain/tests/test_stepper.py`、`tools/wf/frozen.json`（卡字段）。未 commit、未部署。

## 1. 改了什么

### 1.1 段完成回报闩锁（main.py）
- 新增状态：`_done_seq`（单调递增）、`_done_latch`（最后完成单：segment_id/block/stop_kind/skipped/elapsed_s/seq/replay）、`_last_done_replay_at`、`_done_replay_stopped`。
- `_mark_segment_done()`：每完成一段 → `_done_seq += 1`，闩锁字段；`P_CAR_STATE` 增加顶层 `done_seq` 与 `done` 字典（phase 语义不变）。
- `_maybe_replay_done()`：**WAIT_INFO 等新布局期间**按 `step.done_replay_s`（`cfg.get` 缺省 1.0s，0=关）1 Hz 重发同一份闩锁（`replay` 计数 +1、force 发布）；phase 仍是 WAIT_INFO。
- `_stop_done_replay()`：新布局到达（`_poll_layout` version bump）、开新段（`_plan` 下发成功）、FINISH/SAFE_STOP/ROS_LOST 时停止重发并清闩锁；`done_seq` 不重置。
- `status()` 增 `done_seq` / `done` / `done_replay_stopped`。

### 1.2 同格停站段 = 有效段（recon 段 6 形态）
- `_plan()` 的 `from_cell == target_cell` 分支：**计入 `segments_started`**、打一行「同格停站（0 token）」日志、分类 stop_kind 后发 SEGMENT_DONE 完成单（`skipped=True`），不再只是“空段”。
- 这样 recon 的 `F4(mine) → F4(stop)` 第 6 段能正常回报（含 done_seq/stop_kind），机端检查点继续推进。

### 1.3 D-022 完整布局例外
- 新增 `_layout_is_complete()`：`known` 去重后 ≥ `MAP_ROWS*MAP_COLS`（154）**或** `coverage.complete is True` **或** `coverage_complete` 真。
- `_plan()` 新鲜度判定：过期但**完整** ⇒ 允许规划，并打一次「D-022 视为静态场地信息」说明（`_layout_complete_noted` 去抖，新布局到达重置）；过期且 partial ⇒ 仍 `WAIT_INFO(layout_stale)`。
- `normalize_step_layout()` 透传 `coverage` / `coverage_complete`（否则 D-022 的 coverage 判据在车端永远看不到）。

## 2. 验收输出（本机实跑，日志在 accept_*.log）

```
python src\dzbrain\tests\test_stepper.py   → exit 0，115/115 全部通过（原 101 全保留 + §15 新增 14 条）
python src\dzbrain\tests\test_drone.py     → exit 0，174/174 全部通过
python -m dzbrain.main --bench --seconds 3  → exit 0（0 error）
python tools\wf\check.py                   → exit 0，GREEN（冻结区 1 项已登记）
```

§15 新增覆盖（对应卡面 5 类 + Lead 追加 recon 2 类）：
- 15.1 完成单跨 tick 保持；15.2 WAIT_INFO 1 Hz 重发且 phase 不变；
- 15.3/15.4/15.5 同格停站段有效（done_seq 1→2、skipped、计入台账、闩锁可重发）；15.6 新布局到达停止重发并进下一段；
- 15.7/15.8 完整布局（known=154）过期可规划且只说明一次；15.9 coverage.complete 也放行；15.10 partial 过期仍 WAIT；
- 15.11/15.12 recon 批次 `target_cell=''` 不规划、全 known 首 target 才规划；
- 15.13/15.14 recon 段 6 同格射击停站（C9）→ `skipped=True` + `stop_kind='shoot'` + 1 Hz 重发。

## 3. 需要 Lead 决策/后续（写域外）

1. **链路转发缺口**：`tasks/drone.py:1101-1104` 的 `_car_state_fields()` 白名单只转发 `segment_id/known_count/target_cell/stop_kind/version/reason`，**不含 `done`/`done_seq`** ⇒ 本轮闩锁在 `/dzlink/car_to_drone` 上暂时看不到（机端只能靠 WAIT_INFO+block 兜底）。建议另开一行卡把 `done`/`done_seq` 加进白名单（并注意 payload 体积：done 是小 dict）。
2. `step.done_replay_s` 与 `step.layout_ttl_s` 一样走 `cfg.get` 缺省（未改 config/SCHEMA，符合“默认值在代码里”的约定）；如需现场调参再登记 SCHEMA。
3. D-022 与 D-015② 的冲突由 D-022 部分推翻（已在台账），本卡按 D-022 实现：partial 过期不续跑、完整布局例外放行。