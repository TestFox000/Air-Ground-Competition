#!/bin/bash
sshpass -p duzhong ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null duzhong@192.168.137.52 'bash -s' <<"EOF"
source ~/dzlink_tools/dzlink.env
source /opt/ros/humble/setup.bash
cd ~/dzlink_tools
cp -n layout_batches.py layout_batches.py.bak_resume 2>/dev/null || true
python3 - <<'PY'
import re
p='layout_batches.py'
s=open(p,encoding='utf-8').read()
# 1) FINISH 也算段末（车端 DroneTask 上报的是 MissionTask phase）
if "prev in ('DRIVE', 'STOP') and new_phase in ('IDLE', '')" in s:
    s = s.replace("if prev in ('DRIVE', 'STOP') and new_phase in ('IDLE', ''):",
                  "if prev in ('DRIVE', 'STOP') and new_phase in ('IDLE', '', 'FINISH'):")
# 2) 支持从“全图已知 + 指定版本”续跑（热补测多段，不重启车）
s = s.replace("        self.known: set[str] = set()\n        self.version = 0",
 "        self.known: set[str] = set()\n        if os.environ.get('LAYOUT_KNOWN_ALL') == '1':\n            self.known = set(self.truth.all_cells() if hasattr(self.truth,'all_cells') else [f'{c}{r}' for c in 'ABCDEFGHIJKLMN' for r in range(1,12)])\n        self.version = int(os.environ.get('LAYOUT_VERSION_BASE','0'))")
s = s.replace("        self.batch_idx = 0", "        self.batch_idx = int(os.environ.get('LAYOUT_BATCH_IDX','0'))")
s = s.replace("        self.car_block = self.truth.start", "        self.car_block = os.environ.get('LAYOUT_CAR_BLOCK', self.truth.start)")
# 3) 启动后直接按已知全图决策一次
s = s.replace("        self.add_batch()\n\n    def log", "        if self.known and not self.batch_idx < len(BATCHES):\n            self.target = self.decide()\n            self.publish_layout('resume')\n        else:\n            self.add_batch()\n\n    def log")
open(p,'w',encoding='utf-8').write(s)
print('patched resume mode')
PY
pkill -f layout_batches.py 2>/dev/null || true
sleep 1
LOG=logs/layout_resume_$(date +%Y%m%d_%H%M%S).log
LAYOUT_KNOWN_ALL=1 LAYOUT_VERSION_BASE=100 LAYOUT_BATCH_IDX=10 LAYOUT_CAR_BLOCK=H8 nohup python3 -u layout_batches.py > $LOG 2>&1 &
echo "restarted pid=$! log=$LOG"
sleep 6
tail -12 $LOG
EOF
