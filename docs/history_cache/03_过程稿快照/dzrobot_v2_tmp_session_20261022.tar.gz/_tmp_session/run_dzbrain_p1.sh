#!/bin/bash
source /opt/ros/humble/setup.bash
source ~/dzrobot/dzros.env
source ~/dzrobot/install/setup.bash
cd ~/dzrobot
exec env PYTHONUNBUFFERED=1 PYTHONIOENCODING=utf-8 python3 -u -m dzbrain.main --config ~/dzrobot/config/robot.yaml --map ~/dzrobot/config/map.yaml.absent --force
