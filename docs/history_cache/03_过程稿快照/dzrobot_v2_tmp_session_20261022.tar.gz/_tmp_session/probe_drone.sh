#!/bin/bash
sshpass -p duzhong ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null duzhong@192.168.137.52 '
hostname
echo "--- home ---"
ls ~
echo "--- dzlink ---"
ls ~/dzlink_tools 2>/dev/null
echo "--- procs ---"
pgrep -af "dzlink|dzbrain|supervisor" | head -5
echo "--- dzbrain pkg ---"
ls -d ~/dzbrain ~/dzrobot 2>/dev/null
' 2>&1
