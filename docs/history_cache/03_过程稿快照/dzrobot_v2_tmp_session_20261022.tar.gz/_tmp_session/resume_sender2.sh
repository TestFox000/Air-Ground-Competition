#!/bin/bash
sshpass -p duzhong ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null duzhong@192.168.137.52 'bash -s' <<"EOF"
source ~/dzlink_tools/dzlink.env
source /opt/ros/humble/setup.bash
cd ~/dzlink_tools
python3 - <<'PY'
p='layout_batches.py'
s=open(p,encoding='utf-8').read()
old = """        self.known: set[str] = set()
        if os.environ.get('LAYOUT_KNOWN_ALL') == '1':
            self.known = set(self.truth.all_cells() if hasattr(self.truth,'all_cells') else [f'{c}{r}' for c in 'ABCDEFGHIJKLMN' for r in range(1,12)])
        self.version = int(os.environ.get('LAYOUT_VERSION_BASE','0'))"""
new = """        self.known: set[str] = set()
        if os.environ.get('LAYOUT_KNOWN_ALL') == '1':
            ac = getattr(self.truth, 'all_cells', None)
            if callable(ac):
                self.known = set(ac())
            elif ac:
                self.known = set(ac)
            else:
                self.known = {f'{c}{r}' for c in 'ABCDEFGHIJKLMN' for r in range(1,12)}
        self.version = int(os.environ.get('LAYOUT_VERSION_BASE','0'))"""
assert old in s, 'known block not found'
s = s.replace(old, new)
old2 = """        self.timer = self.create_timer(0.25, self.tick)"""
new2 = """        self.timer = self.create_timer(0.25, self.tick)
        if self.batch_idx >= len(BATCHES):
            self.target = self.decide()
            self.publish_layout('resume')"""
assert old2 in s, 'timer block not found'
s = s.replace(old2, new2)
open(p,'w',encoding='utf-8').write(s)
print('patched ok')
PY
pkill -f layout_batches.py 2>/dev/null || true
sleep 1
LOG=logs/layout_resume_$(date +%Y%m%d_%H%M%S).log
LAYOUT_KNOWN_ALL=1 LAYOUT_VERSION_BASE=100 LAYOUT_BATCH_IDX=10 LAYOUT_CAR_BLOCK=H8 nohup python3 -u layout_batches.py > $LOG 2>&1 &
echo "restarted pid=$! log=$LOG"
sleep 6
tail -14 $LOG
EOF
