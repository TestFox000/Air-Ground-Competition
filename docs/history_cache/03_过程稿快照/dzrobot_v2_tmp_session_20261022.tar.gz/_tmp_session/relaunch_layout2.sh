#!/bin/bash
cd ~/dzrobot
echo "=== auto_plan_enabled 全部出现 ==="
grep -n "auto_plan_enabled" config/robot.yaml
sed -i '749s/auto_plan_enabled: false/auto_plan_enabled: true/' config/robot.yaml
echo "=== 改后 ==="
sed -n '749p' config/robot.yaml
pkill -f "dzbrain.main" 2>/dev/null || true
sleep 2
pkill -9 -f "dzbrain.main" 2>/dev/null || true
sleep 1
source /opt/ros/humble/setup.bash
source ~/dzrobot/install/setup.bash
source ~/dzrobot/dzros.env
cd ~/dzrobot
nohup python3 -u -m dzbrain.main --config ~/dzrobot/config/robot.yaml --map /tmp/__no_map_for_steploop__.yaml --force > ~/robot_logs/9_steploop_layout.log 2>&1 &
echo "launched pid=$!"
sleep 20
echo "=== 关键行 ==="
grep -aE "布局模式|步进|场地布局|第 1 份|规划|WAIT|target|阶段=|段[0-9]" ~/robot_logs/9_steploop_layout.log | head -30
echo "=== tail ==="
tail -12 ~/robot_logs/9_steploop_layout.log
