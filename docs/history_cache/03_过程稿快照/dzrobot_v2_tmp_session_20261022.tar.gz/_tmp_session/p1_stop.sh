#!/bin/bash
if [ -f ~/robot_logs/pids/7_path_p1.pid ]; then kill "$(cat ~/robot_logs/pids/7_path_p1.pid)" 2>/dev/null; fi
if [ -f ~/robot_logs/pids/layout_p1.pid ]; then kill "$(cat ~/robot_logs/pids/layout_p1.pid)" 2>/dev/null; fi
pkill -f 'python3 -u -m dzbrain.main' 2>/dev/null
pkill -f 'python3 -u /home/duzhong/layout_batches_p1.py' 2>/dev/null
sleep 3
echo "===STATE==="
source /opt/ros/humble/setup.bash
source ~/dzrobot/dzros.env
timeout 4 ros2 topic echo /current_vel_state --once 2>&1 | head -10
echo "===ODOM==="
timeout 4 ros2 topic echo /odom --once 2>&1 | grep -E 'x:|y:|z:|linear|angular' | head -8
echo "===LAST==="
grep -aF '[T]' ~/robot_logs/7_path_p1.log | tail -3
echo "===PROC==="
pgrep -af 'dzbrain.main|layout_batches_p1' | head -5
