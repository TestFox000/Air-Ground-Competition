#!/bin/bash
sshpass -p duzhong ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null duzhong@192.168.137.52 'pkill -f layout_batches.py; echo sender_stopped' 2>/dev/null
sed -i '749s/auto_plan_enabled: true/auto_plan_enabled: false/' ~/dzrobot/config/robot.yaml
echo "car auto_plan_enabled: $(sed -n '749p' ~/dzrobot/config/robot.yaml | awk '{print $2}')"
echo "car dzbrain: $(pgrep -af 'dzbrain.main' | head -1)"
echo "drone sender: $(sshpass -p duzhong ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null duzhong@192.168.137.52 'pgrep -fc layout_batches.py' 2>/dev/null)"
