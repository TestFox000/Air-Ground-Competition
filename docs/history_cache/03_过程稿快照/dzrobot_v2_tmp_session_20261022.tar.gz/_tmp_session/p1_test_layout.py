#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""P1 预检：只发 known=batch1、target_cell="" 的布局 v1（车应 WAIT_INFO，不动）。"""
import json, os, sys, time
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from rclpy.qos import QoSProfile, ReliabilityPolicy
from dzbrain.scout.layout import TruthMap, build_layout
from dzbrain.core.config import Config

BATCH1 = [f'{c}{r}' for c in 'LMN' for r in range(7, 12)]

class P(Node):
    def __init__(self):
        super().__init__('p1_test_layout')
        self.truth = TruthMap.load(os.path.expanduser('~/dzrobot/config/map.yaml'))
        self.cfg = Config.from_dict({})
        self.pub = self.create_publisher(String, '/dzlink/drone_to_car',
                                        QoSProfile(depth=10, reliability=ReliabilityPolicy.BEST_EFFORT))
        self.layout = build_layout(self.truth, set(BATCH1), version=1, ts=time.time(),
                                   car_block='N10', segment_id=1, target_cell='',
                                   covered_mines=set(), done_stops=set(), cfg=self.cfg, max_stops=2)
        print('TEST layout known=%d target=%r bridges=%s' % (len(self.layout['known']), self.layout['target_cell'], self.layout['bridges']), flush=True)
        self.create_timer(1.0, self.send)
        self.send()
    def send(self):
        m = String(); m.data = json.dumps(self.layout, ensure_ascii=False, separators=(',', ':'))
        self.pub.publish(m)

def main():
    rclpy.init(); n = P()
    try: rclpy.spin(n)
    except KeyboardInterrupt: pass
    finally:
        n.destroy_node()
        try: rclpy.shutdown()
        except Exception: pass

if __name__ == '__main__':
    main()
