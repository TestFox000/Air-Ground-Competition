#!/bin/bash
sshpass -p duzhong ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null duzhong@192.168.137.52 'bash -s' <<"EOF"
source ~/dzlink_tools/dzlink.env
source /opt/ros/humble/setup.bash
cd ~/dzlink_tools
python3 - <<'PY'
p='layout_batches.py'
s=open(p,encoding='utf-8').read()
# 删掉上一版插错位置的 covered 读取
import re
s = s.replace("""
        if os.environ.get('LAYOUT_COVERED'):
            self.covered = set(os.environ['LAYOUT_COVERED'].split(','))""", "")
old = "        self.covered: set[str] = set()"
new = old + """
        if os.environ.get('LAYOUT_COVERED'):
            self.covered = set(os.environ['LAYOUT_COVERED'].split(','))"""
assert old in s
s = s.replace(old, new, 1)
open(p,'w',encoding='utf-8').write(s)
print('moved covered env after declaration')
PY
pkill -f layout_batches.py 2>/dev/null || true
sleep 1
LOG=logs/layout_next2_$(date +%Y%m%d_%H%M%S).log
LAYOUT_KNOWN_ALL=1 LAYOUT_VERSION_BASE=300 LAYOUT_BATCH_IDX=10 LAYOUT_CAR_BLOCK=H8 LAYOUT_COVERED=H8 nohup python3 -u layout_batches.py > $LOG 2>&1 &
echo "restarted pid=$! log=$LOG"
sleep 6
tail -12 $LOG
EOF
