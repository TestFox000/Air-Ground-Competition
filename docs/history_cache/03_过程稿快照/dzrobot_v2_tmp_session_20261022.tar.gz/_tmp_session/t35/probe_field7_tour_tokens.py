# -*- coding: utf-8 -*-
import sys, pathlib, yaml
REPO = pathlib.Path(r"D:\User\Desktop\比赛存档\v1\dzrobot_v2")
sys.path.insert(0, str(REPO/"src"/"dzbrain"))
from dzbrain.core.config import Config
from dzbrain.tasks import mission as MT
from dzbrain.route import planner as P
MAP = pathlib.Path(r"D:/User/Desktop/比赛存档/v1/dzrobot_v2/_tmp_session/t35/map7_t24.yaml")
raw = yaml.safe_load(MAP.read_text(encoding="utf-8"))
cfg0 = Config.load(str(REPO/"config/robot.yaml"))
cfg = cfg0.override("planner.map_path", str(MAP)).override("planner.engine","tour")
o = MT.plan_route_from_config(cfg, log=lambda s: None)
print("tour tokens:", " ".join(o.tokens))
spec = P.load_map(raw)
print("second(C9):", P.second_shoot_stop(spec, P.Grid(spec), "C9", P._shoot_accept(cfg)))
print("C5 in route:", "C5" in [t.replace("*","").split(":")[0] for t in o.tokens])
print("closure:", P.ensure_second_shoot_stop(o.tokens, raw, cfg)[1:])
