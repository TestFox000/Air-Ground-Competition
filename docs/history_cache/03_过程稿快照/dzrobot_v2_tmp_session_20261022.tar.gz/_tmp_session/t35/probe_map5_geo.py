# -*- coding: utf-8 -*-
import sys, pathlib, yaml
REPO = pathlib.Path(r"D:\User\Desktop\比赛存档\v1\dzrobot_v2")
sys.path.insert(0, str(REPO/"src"/"dzbrain"))
from dzbrain.core.config import Config
from dzbrain.route import planner as PL
from dzbrain.core import geometry as geo
MAP5 = REPO/"_tmp_session/t35/map5_700d61c.yaml"
spec = PL.load_map(yaml.safe_load(MAP5.read_text(encoding="utf-8")))
print("center", PL.plate_center_m(spec), "normal", PL.plate_face_normal_m(spec))
for b in ("D3","G3","C6","H6","C4","H5","C5","E5","F5"):
    print(b, geo.block_to_meters(b), "side", PL.plate_side_of(spec,b), "dist", round(PL.shoot_stop_distance(b,spec),4))
cfg = Config.load(str(REPO/"config/robot.yaml"))
cands = PL.shoot_candidates(spec, PL.Grid(spec), PL._shoot_accept(cfg))
cover = PL.covering_stops(spec, cands, PL._shoot_accept(cfg))
for c in cands:
    print("cand",c,"side",PL.plate_side_of(spec,c),"d",round(PL.shoot_stop_distance(c,spec),4),"cover",cover.get(c))
