# -*- coding: utf-8 -*-
import sys, pathlib, json
REPO = pathlib.Path(r"D:\User\Desktop\比赛存档\v1\dzrobot_v2")
sys.path.insert(0, str(REPO/"src"/"dzbrain"))
from dzbrain.core.config import Config
from dzbrain.tasks.mission import plan_route_from_config
from dzbrain.route.parser import parse_token
MAP5 = REPO/"_tmp_session/t35/map5_700d61c.yaml"
cfg = Config.load(str(REPO/"config/robot.yaml"))
for eng in ("tracker-safe","tour"):
    c = cfg.override("planner.map_path", str(MAP5)).override("planner.engine", eng)
    o = plan_route_from_config(c, log=lambda s: None)
    stars = [t for t in o.tokens if t.endswith("*")]
    print(eng, "ok=", o.ok, "engine=", o.engine, "tokens=", len(o.tokens), "len=%.2f" % o.route_len_m,
          "stars=", stars, "pivots=", sum(1 for t in o.tokens if "PIVOT" in t), "err=", o.error[:80],
          "shoot_stops=", getattr(o,"shoot_stops",None), "added=", getattr(o,"second_stop_added",None))
