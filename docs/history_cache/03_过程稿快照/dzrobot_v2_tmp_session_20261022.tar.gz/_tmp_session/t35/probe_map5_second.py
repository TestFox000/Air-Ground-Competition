# -*- coding: utf-8 -*-
import sys, pathlib
REPO = pathlib.Path(r"D:\User\Desktop\比赛存档\v1\dzrobot_v2")
sys.path.insert(0, str(REPO/"src"/"dzbrain"))
from dzbrain.core.config import Config
from dzbrain.route import planner as PL
from dzbrain.route.parser import parse_mission
MAP5 = REPO/"_tmp_session/t35/map5_700d61c.yaml"
cfg = Config.load(str(REPO/"config/robot.yaml"))
import yaml
spec = PL.load_map(yaml.safe_load(MAP5.read_text(encoding="utf-8")))
print("targets", spec.targets, "center", PL.plate_center_m(spec), "normal", PL.plate_face_normal_m(spec))
primary="D3"
print("primary side", PL.plate_side_of(spec, primary))
cands = PL.shoot_candidates(spec, PL.Grid(spec), PL._shoot_accept(cfg))
print("candidates", [(c, PL.plate_side_of(spec,c), round(PL.shoot_stop_distance(c, spec),4)) for c in cands])
print("second", PL.second_shoot_stop(spec, PL.Grid(spec), primary, PL._shoot_accept(cfg)))
from dzbrain.tasks.mission import plan_route_from_config
for eng in ("tracker-safe","tour"):
    c = cfg.override("planner.map_path", str(MAP5)).override("planner.engine", eng)
    o = plan_route_from_config(c, log=lambda s: None)
    print(eng, "tokens", o.tokens)
    print("  note fields", {k:getattr(o,k) for k in dir(o) if 'second' in k or 'shoot' in k})
