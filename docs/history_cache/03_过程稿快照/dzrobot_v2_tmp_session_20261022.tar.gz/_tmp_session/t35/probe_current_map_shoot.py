# -*- coding: utf-8 -*-
import sys, pathlib, yaml
REPO = pathlib.Path(r"D:\User\Desktop\比赛存档\v1\dzrobot_v2")
sys.path.insert(0, str(REPO/"src"/"dzbrain"))
from dzbrain.core.config import Config
from dzbrain.route import planner as PL
from dzbrain.core import geometry as geo
spec = PL.load_map(yaml.safe_load((REPO/"config/map.yaml").read_text(encoding="utf-8")))
cfg = Config.load(str(REPO/"config/robot.yaml"))
print("targets", spec.targets, "center", PL.plate_center_m(spec), "normal", PL.plate_face_normal_m(spec))
cands = PL.shoot_candidates(spec, PL.Grid(spec), PL._shoot_accept(cfg))
print("cands", [(c, PL.plate_side_of(spec,c), round(PL.shoot_stop_distance(c,spec),4)) for c in cands])
cover = PL.covering_stops(spec, cands, PL._shoot_accept(cfg))
for c in cands: print("cand",c,"side",PL.plate_side_of(spec,c),"d",round(PL.shoot_stop_distance(c,spec),4),"cover",cover.get(c))
for primary in cands:
    s = PL.second_shoot_stop(spec, PL.Grid(spec), primary, PL._shoot_accept(cfg))
    print("primary",primary,"-> second",s)
