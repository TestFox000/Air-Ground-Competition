# -*- coding: utf-8 -*-
import sys, pathlib
REPO = pathlib.Path(r"D:\User\Desktop\比赛存档\v1\dzrobot_v2")
sys.path.insert(0, str(REPO/"src"/"dzbrain"))
from dzbrain.core.config import Config
from dzbrain.route import planner as P
cfg = Config.load(str(REPO/"config/robot.yaml"))
raw = {"map": {
 "name":"field7-t24","start":"N10","end":"N5","barrier_col_from":"D",
 "barrier_row_hi":6,"barrier_row_lo":7,
 "mines":["B1","A2","I2","C3","E3","G5","I8","H9"],
 "obstacles":["D5","I6","A7","F8","B9","F10","H10","A11"],
 "targets":["D7","E7"],"bridges":["K4","K10"]}}
for fn,name in ((P.plan_route_tracker_safe,"tracker-safe"),):
    try:
        r = fn(raw, cfg, max_seconds=10.0)
        stars=[t for t in r.tokens if t.endswith("*")]
        print(name,"ok tokens",len(r.tokens),"len",r.polyline_m,"stars",stars,"pivots",sum('PIVOT' in t for t in r.tokens),"shoot2",getattr(r,"shoot_stop2",None))
    except Exception as e:
        print(name,"EXC",type(e).__name__,e)
