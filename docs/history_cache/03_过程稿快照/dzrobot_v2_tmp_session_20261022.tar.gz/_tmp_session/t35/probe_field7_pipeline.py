# -*- coding: utf-8 -*-
import sys, pathlib, yaml
REPO = pathlib.Path(r"D:\User\Desktop\比赛存档\v1\dzrobot_v2")
sys.path.insert(0, str(REPO/"src"/"dzbrain"))
from dzbrain.core.config import Config
from dzbrain.tasks import mission as MT
from dzbrain.route.parser import parse_token
cfg0 = Config.load(str(REPO/"config/robot.yaml"))
raw = {"map": {"name":"field7-t24","start":"N10","end":"N5","barrier_col_from":"D",
 "barrier_row_hi":6,"barrier_row_lo":7,
 "mines":["B1","A2","I2","C3","E3","G5","I8","H9"],
 "obstacles":["D5","I6","A7","F8","B9","F10","H10","A11"],
 "targets":["D7","E7"],"bridges":["K4","K10"]}}
MAP = pathlib.Path(r"D:/User/Desktop/比赛存档/v1/dzrobot_v2/_tmp_session/t35/map7_t24.yaml")
MAP.write_text(yaml.safe_dump(raw, allow_unicode=True, sort_keys=False), encoding="utf-8")
for eng in ("tracker-safe","tour"):
    cfg = cfg0.override("planner.map_path", str(MAP)).override("planner.engine", eng)
    o = MT.plan_route_from_config(cfg, log=lambda s: None)
    stars=[t for t in o.tokens if t.endswith("*")]
    print(eng, "ok",o.ok,"tok",len(o.tokens),"len %.2f"%o.route_len_m,"stars",stars,"pivots",sum('PIVOT' in t for t in o.tokens),"second",getattr(o,'second_stop_added',None), "shoot_stops",getattr(o,'shoot_stops',None))
    if o.ok:
        g = MT.check_planned_route(o.tokens, raw, cfg)
        print("  gate", g.ok, "rc", g.route_check_rc, "valerr", len(g.validate_errors), "valwarn", len(g.validate_warns), "note", g.summary[:160])
        g2 = MT.check_planned_route(o.tokens, raw, cfg.override("planner.footprint_gate","error"))
        print("  gate error-sev", g2.ok)
