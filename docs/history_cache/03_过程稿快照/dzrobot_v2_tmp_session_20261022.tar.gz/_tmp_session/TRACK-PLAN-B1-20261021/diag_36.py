import sys, json, pathlib
sys.path.insert(0, r"D:\\User\\Desktop\\比赛存档\\v1\\dzrobot_v2\\src\\dzbrain")
from dzbrain.route import planner as PL
C = pathlib.Path(r"D:\\User\\Desktop\\比赛存档\\v1\\dzrobot_v2")
FIELDS = json.loads((C / "_tmp_session" / "p1_hybrid" / "stress_fields.json").read_text(encoding="utf-8"))
rec = [r for r in FIELDS if r["index"] == 36][0]
f = rec["field"]
raw = {"map": {"name": "s36", "start": "N10", "end": "N5", "barrier_col_from": "D",
               "barrier_row_hi": 6, "barrier_row_lo": 7, "mines": f["mines"],
               "obstacles": f["obstacles"], "targets": f["targets"], "bridges": f["bridges"]}}
spec = PL.load_map(raw)
print("start", PL._cell(spec.start), "end", PL._cell(spec.end))
for r in (7, 8, 9, 10, 11):
    g = PL.Grid(spec, bridge_rows=(r, 3), allow_reverse=False)
    print("lr", r, "passable N5", g.passable(5, 13), "N10", g.passable(10, 13))
    dist, came, act, settled, rank = PL.flood(g, (10, 13, 0))
    vals = [PL._flood_value(dist, (5, 13, h), rank) for h in range(4)]
    print("   end vals", [round(v, 2) for v in vals], "states", len(dist))
    cells = sorted({(k[0], k[1]) for k in dist})
    print("   reachable cells:", len(cells))
    print("   rows7-11:", [ (r,c) for (r,c) in cells if 7 <= r <= 11 ])
    print("   rows1-6:", len([1 for (r,c) in cells if 1 <= r <= 6]))
