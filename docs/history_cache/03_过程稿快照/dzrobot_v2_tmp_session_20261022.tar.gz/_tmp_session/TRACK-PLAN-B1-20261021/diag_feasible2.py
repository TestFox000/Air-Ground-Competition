"""可行性上界 2：允许任意 K 行穿洞（5 下 × 6 上）时 64 图的 start→end / 雷可达。"""
import sys, json, pathlib, itertools
sys.path.insert(0, r"D:\\User\\Desktop\\比赛存档\\v1\\dzrobot_v2\\src\\dzbrain")
from dzbrain.route import planner as PL
C = pathlib.Path(r"D:\\User\\Desktop\\比赛存档\\v1\\dzrobot_v2")
W = C.parent
FIELDS = json.loads((C / "_tmp_session" / "p1_hybrid" / "stress_fields.json").read_text(encoding="utf-8"))
out = []
for rec in FIELDS:
    field = rec.get("field") or {}
    raw = {"map": {"name": "stress%d" % rec["index"], "start": "N10", "end": "N5",
                   "barrier_col_from": "D", "barrier_row_hi": 6, "barrier_row_lo": 7,
                   "mines": field.get("mines") or [], "obstacles": field.get("obstacles") or [],
                   "targets": field.get("targets") or [], "bridges": field.get("bridges") or []}}
    spec = PL.load_map(raw)
    start = PL._cell(spec.start); end = PL._cell(spec.end)
    best = None
    for lr in range(7, 12):
        for ur in range(1, 7):
            try:
                g = PL.Grid(spec, bridge_rows=(lr, ur), allow_reverse=False)
            except Exception:
                continue
            if not g.passable(*start) or not g.passable(*end):
                continue
            dist, came, act, settled, rank = PL.flood(g, (start[0], start[1], 0))
            end_ok = any(PL._flood_value(dist, (end[0], end[1], h), rank) < float("inf") for h in range(4))
            if not end_ok:
                continue
            mine_ok = sum(1 for m in spec.mines
                          if any(PL._flood_value(dist, (PL._cell(m)[0], PL._cell(m)[1], h), rank) < float("inf")
                                 for h in range(4)))
            cand = (mine_ok, -abs(lr - 9) - abs(ur - 3))
            if best is None or cand > best[0]:
                best = (cand, lr, ur)
    out.append({"index": rec["index"], "end_ok": best is not None,
                "mines_reach": best[0][0] if best else 0, "mines_n": len(spec.mines),
                "pick": [best[1], best[2]] if best else None})
full = sum(1 for r in out if r["end_ok"] and r["mines_reach"] == r["mines_n"])
print(json.dumps({"n": len(out), "end_ok": sum(1 for r in out if r["end_ok"]),
                  "full_reach": full,
                  "no_end": [r["index"] for r in out if not r["end_ok"]],
                  "partial": [r["index"] for r in out if r["end_ok"] and r["mines_reach"] < r["mines_n"]]},
                 ensure_ascii=False))
