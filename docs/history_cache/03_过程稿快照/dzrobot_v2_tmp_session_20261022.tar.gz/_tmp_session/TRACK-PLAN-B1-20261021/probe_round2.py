import json, subprocess, sys, pathlib
C = pathlib.Path(r"D:\\User\\Desktop\\比赛存档\\v1\\dzrobot_v2")
W = C.parent
MAPS = W / "_tmp_session" / "B1_work" / "maps"

def run(map_path, objective=None):
    cmd = [sys.executable, str(C/"tools"/"plan_route.py"), "--config", str(C/"config"/"robot.yaml"),
           "--map", str(map_path), "--emit", "json", "--check", "--quiet", "--engine", "tour"]
    if objective:
        cmd += ["--objective", objective]
    p = subprocess.run(cmd, cwd=str(C), capture_output=True, text=True, encoding="utf-8", errors="replace")
    i = p.stdout.find("{")
    payload = json.loads(p.stdout[i:]) if i >= 0 else None
    plan = payload["plans"][0] if payload and payload.get("plans") else {}
    chk = payload.get("route_check", [{}])[0] if payload else {}
    return {"exit": p.returncode, "n": len(plan.get("tokens", [])),
            "degraded": plan.get("degraded"), "reason": plan.get("degraded_reason"),
            "tasks": plan.get("tasks"), "stars": [t for t in plan.get("tokens", []) if "*" in t],
            "stops": plan.get("shoot_stops"), "added": plan.get("second_stop_added"),
            "check": chk.get("exit"), "ms": plan.get("elapsed_ms")}

res = {"current_legacy": run(C/"config"/"map.yaml")}
res["map7_legacy"] = run(C/"_tmp_session"/"t35"/"map7_t24.yaml")
for idx in (1, 18, 34, 36, 54):
    res["s%d_tasks" % idx] = run(MAPS/("stress%d.yaml" % idx), "tasks")
print(json.dumps(res, ensure_ascii=False, indent=1))
