"""TRACK-PLAN-B1-20261021 · 64 图压测（基线/新口径共用；不改 p1 原件）。

口径与 _tmp_session/p1_hybrid/stress_compare.py 同源：
  仿真台 stressbench.generateMap（seed=20261018, index 0..63）导出的 stress_fields.json；
  每图跑 tools/plan_route.py --emit json --check --quiet --engine tour；
4 worker 并发。新增输出：逐图 planned/degraded/reason/tasks/耗时，供 A 验收对照。

用法：
  python stress64.py --tag before                    # 基线（旧代码，无 --objective）
  python stress64.py --tag after --objective tasks   # 新口径（代码落地后）

产物：W/_tmp_session/B1_work/stress_<tag>.json（子进程只对仓外目录有写权限）
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import yaml

HERE = Path(__file__).resolve().parent
WS = HERE.parents[1]                      # dzrobot_v2
FIELDS = WS / "_tmp_session" / "p1_hybrid" / "stress_fields.json"
CONFIG = str(WS / "config" / "robot.yaml")
CLI = str(WS / "tools" / "plan_route.py")
OUT_DIR = Path(os.environ.get("B1_WORK", str(WS.parent / "_tmp_session" / "B1_work")))
MAPS = OUT_DIR / "maps"
MAPS.mkdir(parents=True, exist_ok=True)

ENV = dict(os.environ)
ENV["PYTHONIOENCODING"] = "utf-8"
ENV["PYTHONUTF8"] = "1"
ENV["PYTHONDONTWRITEBYTECODE"] = "1"


def make_maps():
    raw = json.loads(FIELDS.read_text(encoding="utf-8"))
    out = []
    for rec in raw:
        field = rec.get("field") or {}
        section = {
            "name": "stress%d" % rec["index"],
            "start": "N10", "end": "N5",
            "barrier_col_from": "D", "barrier_row_hi": 6, "barrier_row_lo": 7,
            "mines": list(field.get("mines") or []),
            "obstacles": list(field.get("obstacles") or []),
            "targets": list(field.get("targets") or []),
            "bridges": list(field.get("bridges") or []),
        }
        path = MAPS / ("stress%d.yaml" % rec["index"])
        path.write_text(yaml.safe_dump({"map": section}, allow_unicode=True,
                                       sort_keys=False), encoding="utf-8")
        out.append({"index": rec["index"], "gen_ok": bool(rec.get("ok")),
                    "gen_error": rec.get("error", ""), "map_path": str(path),
                    "section": section})
    return out


def blocks(tokens):
    out = []
    for tok in tokens or ():
        t = str(tok).strip()
        if t.startswith("R:"):
            t = t[2:]
        t = t.split(",")[0]
        t = t.replace("*", "").replace(":PIVOT", "")
        out.append(t.strip().upper())
    return out


def run_cli(map_path, tag, objective):
    cmd = [sys.executable, CLI, "--config", CONFIG, "--map", map_path,
           "--emit", "json", "--check", "--quiet", "--engine", "tour"]
    if objective:
        cmd += ["--objective", objective]
    t0 = time.perf_counter()
    try:
        p = subprocess.run(cmd, cwd=str(WS), capture_output=True, text=True,
                           timeout=180, encoding="utf-8", errors="replace", env=ENV)
    except subprocess.TimeoutExpired:
        return {"status": "plan-failed", "error": "timeout", "wall_ms": 180000,
                "tokens": []}
    wall_ms = round((time.perf_counter() - t0) * 1000, 1)
    text = (p.stdout or "").strip()
    payload = None
    start = text.find("{")
    if start >= 0:
        try:
            payload = json.loads(text[start:])
        except Exception:
            payload = None
    plan = (payload or {}).get("plans", [{}])[0] if payload else {}
    checks = (payload or {}).get("route_check", []) if payload else []
    tokens = list(plan.get("tokens") or [])
    planned = bool(tokens) and p.returncode in (0, 1)
    err = ""
    if not planned:
        fails = (payload or {}).get("failures", []) if payload else []
        if fails:
            f0 = fails[0]
            err = str(f0.get("error") or f0.get("message") or f0) if isinstance(f0, dict) else str(f0)
        if not err:
            tail = (p.stderr or p.stdout or "").strip().splitlines()
            err = tail[-1] if tail else ("exit=%s" % p.returncode)
    chk = checks[0] if checks else {}
    return {
        "status": "planned" if planned else "plan-failed",
        "exit_code": p.returncode, "wall_ms": wall_ms,
        "plan_ms": plan.get("elapsed_ms"), "tokens": tokens, "n_tokens": len(tokens),
        "polyline_m": plan.get("polylength_m"),
        "pivots": sum(1 for t in tokens if ":PIVOT" in str(t)),
        "crossing": plan.get("crossing"),
        "shoot_stops": plan.get("shoot_stops") or [],
        "second_stop_added": plan.get("second_stop_added") or "",
        "degraded": plan.get("degraded"),
        "degraded_reason": plan.get("degraded_reason") or "",
        "tasks_mines": plan.get("tasks_mines"),
        "tasks_stops": plan.get("tasks_stops"),
        "check_exit": chk.get("exit"), "check_errors": chk.get("errors") or [],
        "warnings": plan.get("warnings") or [],
        "error": err,
    }


def classify(row):
    """full=全任务覆盖（route_check 0 error 且非降级）；degraded=可执行但有缺任务。"""
    r = row["result"]
    if r["status"] != "planned":
        return "plan-failed"
    if r.get("degraded"):
        return "degraded"
    if r.get("check_exit") == 0:
        return "full"
    return "degraded"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--tag", required=True)
    ap.add_argument("--objective", default=None,
                    help="新口径开关（tasks）；缺省 = 旧行为")
    args = ap.parse_args()
    maps = make_maps()
    rows = []

    def work(m):
        r = run_cli(m["map_path"], args.tag, args.objective)
        section = m["section"]
        covered = blocks(r.get("tokens"))
        mines = [str(x).upper() for x in (section.get("mines") or [])]
        hit = [mm for mm in mines if mm in covered]
        stars = [t for t in (r.get("tokens") or []) if str(t).rstrip().endswith("*")
                 or "*" in str(t)]
        return {"index": m["index"], "gen_ok": m["gen_ok"], "gen_error": m["gen_error"],
                "field": section, "result": r,
                "tasks": {"mines_total": len(mines), "mines_hit": len(hit),
                          "mines_missed": [mm for mm in mines if mm not in covered],
                          "shoot_stars": len(stars), "stops": stars}}

    t0 = time.perf_counter()
    with ThreadPoolExecutor(max_workers=4) as pool:
        for fut in as_completed([pool.submit(work, m) for m in maps]):
            rows.append(fut.result())
    rows.sort(key=lambda r: r["index"])
    for row in rows:
        row["class"] = classify(row)

    def pct(n):
        return round(n / len(rows) * 100, 2) if rows else None

    reasonable = [r for r in rows if r["result"]["status"] == "planned"]
    ms = [float(r["result"].get("plan_ms") or 0.0) for r in reasonable]
    wall = [float(r["result"].get("wall_ms") or 0.0) for r in reasonable]
    errs = {}
    for r in rows:
        if r["class"] == "plan-failed":
            msg = (r["result"].get("error") or "unknown").strip().splitlines()[-1][:160]
            errs[msg] = errs.get(msg, 0) + 1
    summary = {
        "tag": args.tag, "objective": args.objective,
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "elapsed_s": round(time.perf_counter() - t0, 1), "n": len(rows),
        "planned": len(reasonable),
        "planned_pct": pct(len(reasonable)),
        "full": sum(1 for r in rows if r["class"] == "full"),
        "full_pct": pct(sum(1 for r in rows if r["class"] == "full")),
        "degraded": sum(1 for r in rows if r["class"] == "degraded"),
        "plan_failed": sum(1 for r in rows if r["class"] == "plan-failed"),
        "plan_ms_avg": round(sum(ms) / len(ms), 2) if ms else None,
        "plan_ms_max": round(max(ms), 2) if ms else None,
        "wall_ms_avg": round(sum(wall) / len(wall), 1) if wall else None,
        "top_fail_reasons": sorted(errs.items(), key=lambda kv: -kv[1])[:8],
        "out": str(OUT_DIR / ("stress_%s.json" % args.tag)),
    }
    payload = {"summary": summary, "records": rows}
    Path(summary["out"]).write_text(json.dumps(payload, ensure_ascii=False, indent=1),
                                    encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=1))
    print("classes:", json.dumps({k: [r["index"] for r in rows if r["class"] == k]
                                  for k in ("full", "degraded", "plan-failed")}))
    return 0


if __name__ == "__main__":
    sys.exit(main())
