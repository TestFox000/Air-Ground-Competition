import sys, yaml, pathlib, time
sys.path.insert(0, r"D:\\User\\Desktop\\比赛存档\\v1\\dzrobot_v2\\src\\dzbrain")
from dzbrain.core.config import Config
from dzbrain.route import planner as PL

orig = PL.check_route_structure
def wrapped(*a, **k):
    t = time.perf_counter()
    probs = orig(*a, **k)
    print("check allow_no_stop=", k.get("allow_no_stop"), "problems=", probs[:3], "ms=", round((time.perf_counter()-t)*1000,1))
    return probs
PL.check_route_structure = wrapped
m = yaml.safe_load(pathlib.Path(r"D:\\User\\Desktop\\比赛存档\\v1\\_tmp_session\\B1_work\\maps\\stress54.yaml").read_text(encoding="utf-8"))
c = Config.load(str(pathlib.Path(r"D:\\User\\Desktop\\比赛存档\\v1\\dzrobot_v2")/"config"/"robot.yaml"))
t0 = time.perf_counter()
r = PL.plan_route(m, c, allow_reverse=False, max_seconds=10.0, objective="tasks")
print("total ms", round((time.perf_counter()-t0)*1000,1), "degraded", r.degraded, r.degraded_reason)
