"""64 图可行性上界（只读）：选择 bridge 组合后 start→end、各雷是否可达。"""
import sys, json, pathlib, itertools
sys.path.insert(0, r"D:\\User\\Desktop\\比赛存档\\v1\\dzrobot_v2\\src\\dzbrain")
from dzbrain.route import planner as PL
from dzbrain.core import config as CFG

WS = pathlib.Path(r"D:\\User\\Desktop\\比赛存档\\v1")
C = WS / "dzrobot_v2"
FIELDS = json.loads((C / "_tmp_session" / "p1_hybrid" / "stress_fields.json").read_text(encoding="utf-8"))
cfg = CFG.Config.load(str(C / "config" / "robot.yaml"))
out = []
for rec in FIELDS:
    field = rec.get("field") or {}
    raw = {"map": {"name": "stress%d" % rec["index"], "start": "N10", "end": "N5",
                   "barrier_col_from": "D", "barrier_row_hi": 6, "barrier_row_lo": 7,
                   "mines": field.get("mines") or [], "obstacles": field.get("obstacles") or [],
                   "targets": field.get("targets") or [], "bridges": field.get("bridges") or []}}
    spec = PL.load_map(raw)
    lower, upper = [], []
    for b in spec.bridges:
        r, c = PL.geo.block_to_index(b)
        if c != 10:
            continue
        (lower if r + 1 >= 7 else upper).append(r + 1)
    start = PL._cell(spec.start); end = PL._cell(spec.end)
    best = None
    for lr, ur in itertools.product(lower or [None], upper or [None]):
        rows = tuple(x for x in (lr, ur) if x)
        if len(rows) < 2:
            continue
        try:
            g = PL.Grid(spec, bridge_rows=rows, allow_reverse=False)
        except Exception:
            continue
        if not g.passable(*start) or not g.passable(*end):
            continue
        dist, came, act, settled, rank = PL.flood(g, (start[0], start[1], 0))
        end_ok = any(PL._flood_value(dist, (end[0], end[1], h), rank) < float("inf") for h in range(4))
        mine_ok = 0
        for m in spec.mines:
            rc = PL._cell(m)
            if any(PL._flood_value(dist, (rc[0], rc[1], h), rank) < float("inf") for h in range(4)):
                mine_ok += 1
        cand = (int(end_ok), mine_ok)
        if best is None or cand > best:
            best = cand
    out.append({"index": rec["index"], "end_ok": bool(best and best[0]),
                "mines_reach": best[1] if best else 0, "mines_n": len(spec.mines),
                "full_reach": bool(best and best[0] and best[1] == len(spec.mines)),
                "bridges": list(spec.bridges)})
summary = {"full_reach": sum(1 for r in out if r["full_reach"]),
           "end_ok": sum(1 for r in out if r["end_ok"]),
           "full_indices": [r["index"] for r in out if r["full_reach"]],
           "no_end": [r["index"] for r in out if not r["end_ok"]],
           "detail": out}
outpath = WS / "_tmp_session" / "B1_work" / "feasible.json"
outpath.parent.mkdir(parents=True, exist_ok=True)
outpath.write_text(json.dumps(summary, ensure_ascii=False, indent=1), encoding="utf-8")
print(json.dumps({k: summary[k] for k in ("full_reach", "end_ok", "no_end")}, ensure_ascii=False))
