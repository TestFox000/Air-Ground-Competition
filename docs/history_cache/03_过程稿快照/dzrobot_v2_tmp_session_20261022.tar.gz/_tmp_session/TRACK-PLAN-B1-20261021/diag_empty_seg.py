"""诊断：为什么某些图编译期出现空段（无解：X -> Y）。只读，不改源码。"""
import sys, json, pathlib, traceback
sys.path.insert(0, r"D:\\User\\Desktop\\比赛存档\\v1\\dzrobot_v2\\src\\dzbrain")
from dzbrain.core.config import Config
from dzbrain.route import planner as PL

MAP = pathlib.Path(r"D:\\User\\Desktop\\比赛存档\\v1\\_tmp_session\\B1_work\\maps\\stress1.yaml")
CFG = r"D:\\User\\Desktop\\比赛存档\\v1\\dzrobot_v2\\config\\robot.yaml"

orig_path = PL._Tour.path
misses = []

def path(self, a, b, ha, hb):
    p, c = orig_path(self, a, b, ha, hb)
    if not p:
        misses.append((a, b, ha, hb, round(c, 3)))
    return p, c

PL._Tour.path = path
cfg = Config.load(CFG)
map_cfg = PL.load_map(PL.map_section(__import__("yaml").safe_load(MAP.read_text(encoding="utf-8"))))
try:
    res = PL.plan_route(map_cfg, cfg, allow_reverse=False, max_seconds=10.0)
    print("PLANNED", len(res.tokens), res.polyline_m)
except Exception as exc:
    print("ERROR:", type(exc).__name__, exc)
print("empty-pair calls:", len(misses))
for m in misses[-12:]:
    a, b, ha, hb = m[0], m[1], m[2], m[3]
    print("  ", PL.geo.index_to_block(a[0]-1, a[1]), "->", PL.geo.index_to_block(b[0]-1, b[1]), "heads", ha, hb, "cost", m[4])
