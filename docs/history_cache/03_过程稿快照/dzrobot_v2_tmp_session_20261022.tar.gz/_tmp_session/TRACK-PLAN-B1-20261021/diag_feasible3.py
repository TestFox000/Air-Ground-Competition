"""可行性上界 3：与 _cross_pools 同口径（每半场：有 bridges 用 bridges，空则整列 K 行段）。"""
import sys, json, pathlib, itertools
sys.path.insert(0, r"D:\\User\\Desktop\\比赛存档\\v1\\dzrobot_v2\\src\\dzbrain")
from dzbrain.route import planner as PL
C = pathlib.Path(r"D:\\User\\Desktop\\比赛存档\\v1\\dzrobot_v2")
FIELDS = json.loads((C / "_tmp_session" / "p1_hybrid" / "stress_fields.json").read_text(encoding="utf-8"))
out = []
for rec in FIELDS:
    field = rec.get("field") or {}
    raw = {"map": {"name": "stress%d" % rec["index"], "start": "N10", "end": "N5",
                   "barrier_col_from": "D", "barrier_row_hi": 6, "barrier_row_lo": 7,
                   "mines": field.get("mines") or [], "obstacles": field.get("obstacles") or [],
                   "targets": field.get("targets") or [], "bridges": field.get("bridges") or []}}
    spec = PL.load_map(raw)
    lower, upper = [], []
    for b in spec.bridges:
        r, c = PL.geo.block_to_index(b)
        if c != 10:
            continue
        (lower if r + 1 >= 7 else upper).append(r + 1)
    lower = lower or list(range(7, 12))
    upper = upper or list(range(1, 7))
    start = PL._cell(spec.start); end = PL._cell(spec.end)
    best = None
    for lr, ur in itertools.product(lower, upper):
        try:
            g = PL.Grid(spec, bridge_rows=(lr, ur), allow_reverse=False)
        except Exception:
            continue
        if not g.passable(*start) or not g.passable(*end):
            continue
        dist, came, act, settled, rank = PL.flood(g, (start[0], start[1], 0))
        end_ok = any(PL._flood_value(dist, (end[0], end[1], h), rank) < float("inf") for h in range(4))
        if not end_ok:
            continue
        mine_ok = 0
        for m in spec.mines:
            rc = PL._cell(m)
            if any(PL._flood_value(dist, (rc[0], rc[1], h), rank) < float("inf") for h in range(4)):
                mine_ok += 1
        cand = (mine_ok, lr, -ur)
        if best is None or cand > best[0]:
            best = (cand, lr, ur)
    out.append({"index": rec["index"], "end_ok": best is not None,
                "mines_reach": best[0][0] if best else 0, "mines_n": len(spec.mines)})
full = [r["index"] for r in out if r["end_ok"] and r["mines_reach"] == r["mines_n"]]
print(json.dumps({"full": len(full), "full_indices": full,
                  "no_end": [r["index"] for r in out if not r["end_ok"]],
                  "partial": [r["index"] for r in out if r["end_ok"] and r["mines_reach"] < r["mines_n"]]},
                 ensure_ascii=False))
