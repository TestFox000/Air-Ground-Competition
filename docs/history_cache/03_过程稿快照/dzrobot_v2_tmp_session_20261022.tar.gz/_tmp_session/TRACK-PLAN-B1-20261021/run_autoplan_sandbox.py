"""在受限沙箱里跑 test_autoplan 的包装器（仅基线复现用）。

原因：本机文件沙箱允许写"工作区内已存在目录"，但拒绝向 tempfile.mkdtemp() 新建的
临时目录写文件（PermissionError）。为了不改被测文件就能复现基线，这里只在内存里把
tempfile.mkdtemp 替换成"工作区内普通 mkdir 目录"，其余逐字运行原测试。
"""
import os
import pathlib
import runpy
import sys
import tempfile

BASE = pathlib.Path(r"D:\User\Desktop\比赛存档\v1\_tmp_session\B1_work\fixtures")
BASE.mkdir(parents=True, exist_ok=True)
_n = [0]


def _mkdtemp(prefix=None, suffix=None, dir=None):
    _n[0] += 1
    d = BASE / ("%s%d_%d" % (prefix or "tmp", os.getpid(), _n[0]))
    d.mkdir(parents=True, exist_ok=True)
    return str(d)


tempfile.mkdtemp = _mkdtemp
TEST = r"D:\User\Desktop\比赛存档\v1\dzrobot_v2\src\dzbrain\tests\test_autoplan.py"
sys.argv = [TEST]
runpy.run_path(TEST, run_name="__main__")
