import sys, json, pathlib, itertools
sys.path.insert(0, r"D:\\User\\Desktop\\比赛存档\\v1\\dzrobot_v2\\src\\dzbrain")
from dzbrain.route import planner as PL
from dzbrain.core.config import Config
C = pathlib.Path(r"D:\\User\\Desktop\\比赛存档\\v1\\dzrobot_v2")
FIELDS = json.loads((C / "_tmp_session" / "p1_hybrid" / "stress_fields.json").read_text(encoding="utf-8"))
cfg = Config.load(str(C / "config" / "robot.yaml"))
acc = PL._shoot_accept(cfg)
rows = []
for rec in FIELDS:
    f = rec.get("field") or {}
    raw = {"map": {"name": "s%d" % rec["index"], "start": "N10", "end": "N5",
                   "barrier_col_from": "D", "barrier_row_hi": 6, "barrier_row_lo": 7,
                   "mines": f.get("mines") or [], "obstacles": f.get("obstacles") or [],
                   "targets": f.get("targets") or [], "bridges": f.get("bridges") or []}}
    spec = PL.load_map(raw)
    g = PL.Grid(spec, allow_reverse=False)
    pool = PL.shoot_candidates(spec, g, acc) if spec.targets else []
    cov = PL.covering_stops(spec, pool, acc) if pool else {}
    full_stops = [b for b in pool if len(cov.get(b, ())) == len(spec.targets)]
    second = []
    if full_stops:
        sec = PL.second_shoot_stop(spec, g, full_stops[0], acc)
        second = [sec] if sec else []
    rows.append({"index": rec["index"], "targets": spec.targets, "pool": len(pool),
                 "full_stops": full_stops[:3], "second": second,
                 "dual": bool(full_stops and second)})
no_stop = [r["index"] for r in rows if not r["full_stops"]]
dual = [r["index"] for r in rows if r["dual"]]
print("maps without any full-cover shoot stop:", len(no_stop), no_stop)
print("maps with dual-side stop possible:", len(dual))
print("single-stop full possible:", len(rows) - len(no_stop))
