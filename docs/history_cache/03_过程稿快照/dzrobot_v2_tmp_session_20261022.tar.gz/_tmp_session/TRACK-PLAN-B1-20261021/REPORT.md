# TRACK-PLAN-B1-20261021 · T-B1 规划器目标函数换口径（任务优先 + 降级标记 + 第七图双停站）

> 角色：implementer（唯一生产写者） · 车仓 C=`dzrobot_v2` · 卡目录 R=`_tmp_session/TRACK-PLAN-B1-20261021`
> 时间：2026-10-21 21:0x–21:3x · 状态：**本地离线实现与验收完成；未 commit、未部署、未上车**

## 0. 一句话结论

tour 引擎新增**可显式开启**的任务优先口径 `objective=tasks`：64 图压测从 **28/64（43.75%）** 提升到 **47/64 全任务（73.44%，≥45 达标）**，且 **64/64 都出可执行 token（无解=0）**；默认 `legacy` 口径在 64 图上的**求解集合与改前逐图一致（28/64）**；第七图 t24 在默认 tour 下产出 **C9* + C5*** 双停站；`test_autoplan` **171/171（改前 148/171，23 红）**；`tools/wf/check.py` **GREEN**；单次规划 tasks 口径 **avg 387 ms / max 761 ms（≤1.5 s）**。

## 1. 改动摘要（只改卡上写域）

| 文件 | 改动 | 行数（相对回滚点） | 改后 SHA256 |
|---|---|---:|---|
| `src/dzbrain/dzbrain/route/planner.py` | 新增 `objective` 开关与任务优先辅助函数；PlanResult 增任务向量/降级字段；tour 规划期插入第二停站普通航点；降级兜底 | +501 / −20 | `c7f237b4c49d22fcc9504b2a15ae2b1075004bd82909f18a939247ed95021adb` |
| `tools/plan_route.py` | 新增 `--objective {legacy,tasks}`（默认 legacy）；JSON/report 带任务/降级；降级解在 `--check` 下不再打红退出码（JSON 保留真实 rc） | +22 / −3 | `df856f6903d847af93d235abaa45d8c0e4b42bc1e762e13b727bcb9c7f87519b` |
| `src/dzbrain/tests/test_autoplan.py` | §10/§12 换到第七图 t24 夹具；6 条真缺陷断言保持并由代码转绿；夹具目录改到工作区外层可写路径 | +83 / −38 | `3448fcd58402c6d9a9a43e812f0fcc807c62b374cf7ffa0fefadb94aa05cc236` |

- **默认行为**：`plan_route(objective=OBJECTIVE_LEGACY)`、CLI `--objective legacy`；**新口径必须显式开启**。legacy 不追加新顺序候选，保持旧三候选 + 旧失败语义；实测 64 图 full 集合与改前**完全相同**（见 §6）。
- **复用**：未新建规划器/未引 OR-Tools/hybrid；只复用既有 `_Tour`、`flood`、`shoot_candidates`、`second_shoot_stop`、`ensure_second_shoot_stop`、`check_route_structure`。

## 2. 验收逐条（命令 + 结果 + 证据）

命令均在 `dzrobot_v2` 下执行，环境 `PYTHONPATH=src\dzbrain`、`PYTHONIOENCODING=utf-8`、`PYTHONDONTWRITEBYTECODE=1`。

### A. 64 图压测（任务优先口径）

    python _tmp_session\TRACK-PLAN-B1-20261021\stress64.py --tag after --objective tasks

| 指标 | 改前（旧代码实测） | 改后（tasks） |
|---|---:|---:|
| 全任务覆盖 planned（雷 8/8 + 停站可达，route_check 0 error） | **28/64 = 43.75%** | **47/64 = 73.44%** ✅ |
| 出 token（含降级，无解=0） | 29/64（1 张有 token 但 rc≠0） | **64/64 = 100%** ✅ |
| plan-failed | 35（旧口径把 index54 有 token 也算失败 ⇒ Lead 基线的 36） | **0** ✅ |
| 降级 | 0 | 17（15 结构不可达 + 2 缺停站） |
| plan_ms avg / max | 519.4 / 723.6 ms | **386.7 / 760.5 ms** ✅ |
| 失败主因 | 穿洞 2 次 11、无停站 4、下穿洞 2 次 3、上穿洞 3 次 3、下穿洞 3 次 2、空段/无停站 12 | 无（全部出串） |

- 新增全任务图 19 张：`2,9,13,16,19,21,22,26,30,32,37,43,44,47,49,51,53,56,63`。
- 逐图 JSON 含 `planned/degraded/degraded_reason/tasks/tokens/elapsed_ms`：`R/stress_after.json`。
- 降级 17 张：15 张 `结构（终点不可达）`（`1,5,7,11,12,18,20,24,27,36,39,42,46,57,61`）+ 2 张 `缺停站`（`34,54`）。**这不是算法没修好，是随机图物理上无合法通路/无合法停站**，见 §4。
- 原始输出：`R/logs/A_stress64_after_stdout.txt`；改前基线：`R/stress_before.json`。

### B. 第七图双停站（默认 tour）

    python tools\plan_route.py --config config\robot.yaml --map _tmp_session\t35\map7_t24.yaml --emit json --check --engine tour

- 结果：**66 token / 23.45 m / 星号 C9*、C5* / route_check exit 0 / degraded=false / elapsed 487 ms** ✅
- `shoot_stops=["C9","C5"]`、`second_stop_added="C5"`（引擎规划期已把 C5 作为普通航点纳入，收口只补星）。
- 原始输出：`R/logs/B_map7_stdout.txt`。
- 参考：tracker-safe（只作参考、非现役回退）在 t24 上 **64 token / 22.05 m / C9+C5 / 门禁 rc=0**，与 t35 复核同值。

### C. test_autoplan

    python src\dzbrain\tests\test_autoplan.py

- 改前：**148/171 通过，23 失败**（与 t35/D-028 口径一致；证据 `R/logs/C_test_autoplan_before_utf8.txt`）
- 改后：**171/171 全部通过，exit 0** ✅（证据 `R/logs/C_test_autoplan_stdout.txt`）
- §12 六条真缺陷（12.3/12.4/12.7/12.8/12.9/12.10）**全部由代码转绿，不是改断言掩盖**：
  - 代码：tour 规划阶段把对侧第二停站（t24=C5）作为**普通航点**插入顺序（`_insert_second_sided`），收口 `ensure_second_shoot_stop` 只把那颗 `*` 补上 ⇒ 同时满足"引擎路线含 C5"与"收口零路径改动（66=66 token）"。
  - 12.3 裸 tour 路线含 C5（普通点）、12.4 收口后只多一个星号、12.7 上车执行 `["C9","C5"]`、12.8 遥测同源、12.9 台账 `shoot:2/end:1`、12.10 横幅 22:C9 / 38:C5 / 63:N5。

### D. 单次规划耗时（≤1.5 s，D-013）

- tasks 口径 64 图：**avg 386.7 ms / max 760.5 ms** ✅
- legacy 默认口径 64 图（含失败重试）：**avg 481.7 ms / max 648.3 ms** ✅
- 注意：`stress64.py` 的 `plan_ms` 是规划器 `elapsed_ms`，不含 route_check 子进程；wall_ms 另计（avg 911 ms）。

### E. 收口门禁

    python tools\wf\check.py

- 结果：**GREEN**（冻结区 `planner.py` 已由 Lead 登记 TRACK-PLAN-B1-20261021；链接 81/0 broken；复用 0 新增未登记；tracker.py 登记失效 WARN 属 R1 遗留）✅
- 证据：`R/logs/E_check_stdout.txt`。

## 3. §10 / §12 重钉表（旧期望 → 新期望 → 依据）

**换图依据**：t35 复核已实测——tracker-safe 在现役第六图结构性无解（D-012），第七图 t24 才是能同时验证双引擎的夹具（tracker-safe 64/22.05/C9+C5；tour 旧为 62/22.05/C9 单停站）。故 §10/§12 的 `MAP` 改为 `MAP7 = _FIX/map7_t24.yaml`（内容与 `_tmp_session/t35/map7_t24.yaml` 逐字一致）。

### 3.1 §10（14 条红项）

| 断言 | 旧期望 | 新期望 | 依据 |
|---|---|---|---|
| 10.10 tracker-safe 成功 | 第六图成功（实际 PlannerError） | t24 成功 ok=True | t35 §3：第六图 tracker-safe 无解是 D-012 已裁决事实 |
| 10.11 无 PIVOT | 空路线退化为真 | t24 0 处 PIVOT | t35 实测 |
| 10.12 长度 | 15.05 m（第五图旧值） | **22.05 m** | t35 t24 tracker-safe 实测 |
| 10.13 有星号 | 空路线退化 | C9*/C5* | 同上 |
| 10.14 门禁 0 error | 空路线连带 | rc=0 / validate 0-0 | t24 实测 |
| 10.15 门禁日志 | 规划失败无门禁行 | 有"规划门禁[tracker-safe]" | 同上 |
| 10.16 rc=0 | 空路线 rc=1 | rc=0 | 同上 |
| 10.17 跳过 rc 退化 | 连带红 | ok + notes | 同上 |
| 10.19 门禁不串味 | 连带红 | 两次 ok | 同上 |
| 10.21 执行==规划 | 规划 0 点 vs 68 点回退 | 64 点 == 64 点 | t24 tracker-safe 实跑 |
| 10.22 横幅引擎/门禁 | 规划失败无横幅 | "引擎 tracker-safe / 门禁✅通过" | 同上 |
| 10.26 失败三件套 | PlannerError 而非注入门禁 | 注入门禁报文+证据+回退 | 换图后规划成功，才走得到门禁分支 |
| 10.27 失败遥测 | plan-fail（gate=True） | gate_ok=False + "未过门禁" | 同上 |
| 10.37 严重级 warn/error | 空路线两 False | warn.ok=True / error.ok=False | t24 有效路线 |

### 3.2 §12（3 条换图 + 6 条改代码）

| 断言 | 旧期望 | 新期望 | 依据/处置 |
|---|---|---|---|
| 12.1 | D3*+G3* | **C9*+C5*** | 换图（t24 实测） |
| 12.2 | ('D3','G3') / added='' | **('C9','C5') / added=''** | 换图（引擎自带） |
| 12.5 | 关收口只剩 D3* | 关收口只剩 **C9*** | 换图（反证逻辑不变） |
| 12.3 | tour 也要 G3* | tour 也要 **C5*** | **改代码**：tour 规划期插入第二停站普通航点 |
| 12.4 | 补标 G3、68==68（旧第六图） | 补标 **C5**、**66==66**、块名逐位相同 | **改代码**，仍保持"只加星、零路径改动" |
| 12.7 | 执行双停站 D3/G3 | **C9/C5** | **改代码** + 换图 |
| 12.8 | 遥测 D3,G3 / G3 | **C9,C5 / C5** | 同上 |
| 12.9 | 台账 D3,G3,N5 | **C9,C5,N5**（shoot:2/end:1） | 同上 |
| 12.10 | 横幅 29/32/43 | **22/38/63** | 同上（tracker-safe t24 路线索引） |

> 另：10.8/10.9/10.20/10.24/10.25/10.28 的 `map_path` 一并换到 MAP7——否则 tracker-safe 在第六图仍无解，门禁/回退路径测不到。10.25 回退目标仍是现役 `route.tokens`（68 点，逐字节一致）。

## 4. 降级语义定义（新口径）

`PlanResult` 新增：`tasks_mines`（实际覆盖雷格，按路线序）、`tasks_stops`（实际星号格）、`tasks_mines_total`、`degraded`、`degraded_reason`；`as_dict()` 同时给 `tasks={mines_covered,mines_total,stops,full}`、`degraded`、`degraded_reason`。

| degraded_reason | 触发条件 | 路线形态 | 处置 |
|---|---|---|---|
| `缺雷 <格名…>` | 雷格被障碍覆盖，或从起点连通块不可达 | 去掉不可达雷，其余全走 | 显式警告 + 计数 |
| `缺停站` | 窗口内无候选 / 无"同时覆盖全部靶格"的停站 / 唯一候选是起点或终点 | 路线照走，0 个 `*` | 显式警告 |
| `超时` | 规划循环超 `max_seconds` | 已有顺序的最优兜底 | 当前 64 图 0 例（max 678 ms） |
| `结构（终点不可达）` | 该图任意候选桥洞组合下 `start→end` 均无合法通路（随机图靶板/障碍封死桥洞） | **沿真实可通行路径**尽量压可达雷，停在离终点最近的可行格 | route_check 如实红；**不是完整任务路线** |
| `结构（无可行顺序）` | 4 个顺序候选均未过结构自检 | 同上兜底 | 同上 |

- **CLI 退出码**：`degraded=True` 时 `--check` 不再把退出码打红（这是"显式降级"不是"无解"）；JSON 里 `route_check[].exit` 保留真实值，透明可查。full 路线仍 rc=0 才 exit 0。
- **为什么 15 张图不判无解也不硬编**：t24 之外的随机图里，靶板格与障碍格是实体（不可压过），桥洞列只有 K 列且按行判；15 张图从起点连通块**物理上到不了终点**（实测任意 5×6 桥洞组合都不可达，只有 index36 即使用非桥洞行也到不了上半场）。对这类图输出"真实可通行但到不了终点"的降级串，并明示 `结构（终点不可达）`；**没有**发明穿障碍/穿桥墩的段，也没有把 route_check 改成假绿。

## 5. 第七图双停站与靶物理（按用户 2026-10-21 21:29 口径）

- 靶 = **1:1 圆面 + 35×70 跨格板**，沿 **0.70 m 轨道水平横移、1 m/s、不旋转、不翻面**；必须打蓝面。`config/robot.yaml` 的 `target_speed_mps=0.04` 是**旧值**，本卡**没有**用它算提前量/窗口。
- 规划口径：`route.shoot_distance_m=0.90`、`tol=0.12` ⇒ 板心窗口 `[0.78,1.02] m`；每个停站必须同时覆盖 D7/E7 两个格位（`covering_stops` 要求覆盖全部 targets）。0.70 m/1 m/s = 0.7 s 的行程是"停站切换/开火时序"的物理背景，**路径规划不建模时序**，只保证两个格位都有可打停站。
- t24 结果：**C9*（板面一侧）+ C5*（另一侧）**，两者都落在窗口内、都覆盖两格靶；与用户/Lead 给定的"两格各一个停车点"一致。

## 6. 默认行为与回滚

- **默认 legacy**：64 图 full 集合与改前**逐图完全一致**（28/64，集合相同）；当前第六图默认 tour 输出 **68 token / 24.85 m / B4***（与改前一致）；map7 裸 tour 输出 66 token（含 C5 普通航点）/ C9* 单星，收口后 C9*+C5*。
- 回滚点（改前原件，已落卡目录 `R/backups/`）：
  - `planner.py` `e6f0e4b704e30d4d2b596c94a1d6f7ca4388aefdb33eca21a2d1804bbb96efda`（249,842 B）
  - `plan_route.py` `2708d607e2be0a63972cc520397cd4427eab888242c7c69886e892f3cf89c0fa`（22,331 B）
  - `test_autoplan.py` `ca1ab7b37e54267629a4ae948c98561bb0a6b962763305a842dc7df213da208a`（78,222 B，CRLF）
- 回滚方式：用上述三份原件覆盖回去 + 重跑 `test_autoplan` 应回到 148/171；**不要 git reset**（HEAD `eddc377` 是 Lead 21:17 的工作区快照，已含本卡中间态；本卡自身未 commit）。

## 7. 未解项 / 边界（如实报）

1. **15 张随机图物理上不可达终点**（`1,5,7,11,12,18,20,24,27,36,39,42,46,57,61`）：只能出降级串，route_check 会红；这是随机图布设（靶板/障碍封死桥洞）的固有性质，不是规划器可修复项。要 64/64 全任务必须改地图生成器或允许穿靶/穿桥墩（本卡不做）。
2. **2 张图无合法停站**：index34（没有任何单停站能同时覆盖 A4/A5 两格靶）、index54（窗口内唯一候选是终点 N5，不能当停站）。均按 `缺停站` 降级。
3. **`mission.PlanOutcome` 在写域外**：卡面要求的"PlanOutcome 增加任务/降级字段"实际类在 `src/dzbrain/dzbrain/tasks/mission.py`，不属本卡写域；本卡把字段落在 `route/planner.PlanResult` 并透出到 CLI JSON/report。**车端遥测目前仍只有 `shoot_stops/second_stop_added`，没有 degraded 字段**；若需要进遥测，须另开卡改 mission.py。
4. **时间目标用路线长度/代价代理**：规划器不建模 180 s 赛时、1 m/s 平移或驻留时间；"再最小化时间"以里程/顺序代价近似。停站切换/开火时序不在本卡范围。
5. tracker-safe 在 t24 的 64/22.05 只作**夹具参考**，不作现役回退（D-012 保持不变）；planner 默认仍是 tour。
6. 测试夹具目录从 `tempfile.mkdtemp` 改到 `W/_tmp_session/test_autoplan_fixtures`：本机文件沙箱拒绝对 mkdtemp 新建目录写文件（实测 PermissionError），这是环境适配、不是放宽断言；断言内容未因此变松。

## 8. 证据文件清单（均在 R）

| 文件 | 内容 |
|---|---|
| `stress64.py` | 64 图压测脚本（复制 p1 口径改造，含 tasks/legacy 开关） |
| `stress_before.json` | 改前基线 28/64、逐图 tokens/耗时 |
| `stress_after.json` | 改后 tasks 47/64、64/64 出串、逐图 degraded/tasks/耗时 |
| `stress_legacy_after2.json` | 默认 legacy 复测（28/64，full 集合与改前一致） |
| `logs/A_stress64_after_stdout.txt` | A 原始 stdout |
| `logs/B_map7_stdout.txt` | B 原始 JSON（C9*/C5*、rc0） |
| `logs/C_test_autoplan_stdout.txt` | C 改后 171/171 原始输出 |
| `logs/C_test_autoplan_before_utf8.txt` | C 改前 148/171 原始输出（UTF-16→UTF-8） |
| `logs/E_check_stdout.txt` | E 门禁原始输出（GREEN） |
| `logs/default_legacy_check.txt` | 默认 legacy 关键读数（68/B4*、map7 裸 tour 66/C9*） |
| `backups/` | 三份改前原件（回滚点） |

## 9. 声明

**未部署、未上车、未 commit、未 push、未 SSH、未动 config/**；本卡只改 `planner.py`、`plan_route.py`、`test_autoplan.py` 与 `_tmp_session/TRACK-PLAN-B1-20261021/**`。冻结区 `planner.py` 的 in_flight 由 Lead 登记，本卡未改 `frozen.json`。
