import json, subprocess, sys, pathlib
C = pathlib.Path(r"D:\\User\\Desktop\\比赛存档\\v1\\dzrobot_v2")
W = C.parent
MAPS = W / "_tmp_session" / "B1_work" / "maps"
out = {}
for idx in (0, 1, 2, 9, 18, 34, 36, 54, 60):
    map_path = MAPS / ("stress%d.yaml" % idx)
    cmd = [sys.executable, str(C/"tools"/"plan_route.py"), "--config", str(C/"config"/"robot.yaml"),
           "--map", str(map_path), "--emit", "json", "--check", "--quiet", "--engine", "tour",
           "--objective", "tasks"]
    p = subprocess.run(cmd, cwd=str(C), capture_output=True, text=True, encoding="utf-8", errors="replace")
    i = p.stdout.find("{")
    payload = json.loads(p.stdout[i:]) if i >= 0 else None
    plan = payload["plans"][0] if payload else {}
    chk = payload.get("route_check", [{}])[0] if payload else {}
    stars = [t for t in plan.get("tokens", []) if "*" in t]
    out[idx] = {"exit": p.returncode, "n": len(plan.get("tokens", [])),
                "degraded": plan.get("degraded"), "reason": plan.get("degraded_reason"),
                "tasks": plan.get("tasks"), "stars": stars,
                "check": chk.get("exit"), "ms": plan.get("elapsed_ms"),
                "warn": (plan.get("warnings") or [])[-2:]}
print(json.dumps(out, ensure_ascii=False, indent=1))
