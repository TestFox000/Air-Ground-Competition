"""T-B1 验收统一复跑：A/C/E + B 原始输出全部落 B1_work（UTF-8 无 BOM）。"""
import json
import os
import subprocess
import sys
import pathlib

C = pathlib.Path(r"D:\\User\\Desktop\\比赛存档\\v1\\dzrobot_v2")
W = C.parent
WORK = W / "_tmp_session" / "B1_work"
WORK.mkdir(parents=True, exist_ok=True)
ENV = dict(os.environ)
ENV.update({"PYTHONPATH": str(C/"src"/"dzbrain"), "PYTHONIOENCODING": "utf-8",
            "PYTHONUTF8": "1", "PYTHONDONTWRITEBYTECODE": "1"})
results = {}


def run(tag, cmd):
    p = subprocess.run(cmd, cwd=str(C), capture_output=True, text=True,
                       encoding="utf-8", errors="replace", env=ENV)
    text = (p.stdout or "") + (p.stderr or "")
    (WORK / ("%s_stdout.txt" % tag)).write_text(text, encoding="utf-8")
    results[tag] = {"exit": p.returncode, "lines": len(text.splitlines())}
    print("[%s] exit=%s lines=%d" % (tag, p.returncode, len(text.splitlines())))
    return p.returncode, text


# A: 64 图（tasks 口径）
code, text = run("A_stress64_after", [sys.executable, str(C/"_tmp_session"/"TRACK-PLAN-B1-20261021"/"stress64.py"),
                                      "--tag", "after", "--objective", "tasks"])
# C: test_autoplan
run("C_test_autoplan", [sys.executable, str(C/"src"/"dzbrain"/"tests"/"test_autoplan.py")])
# E: 收口门禁
run("E_check", [sys.executable, str(C/"tools"/"wf"/"check.py")])
# B: 第七图原始输出
code_b, text_b = run("B_map7", [sys.executable, str(C/"tools"/"plan_route.py"),
                               "--config", str(C/"config"/"robot.yaml"),
                               "--map", str(C/"_tmp_session"/"t35"/"map7_t24.yaml"),
                               "--emit", "json", "--check", "--engine", "tour"])
# 基线日志（PowerShell *> 是 UTF-16）转 UTF-8，供报告引用
for src, dst in (("test_autoplan_before.txt", "C_test_autoplan_before_utf8.txt"),):
    path = WORK / src
    if path.is_file():
        raw = path.read_bytes()
        try:
            txt = raw.decode("utf-16")
        except UnicodeDecodeError:
            txt = raw.decode("utf-8", errors="replace")
        (WORK / dst).write_text(txt, encoding="utf-8")
        print("[baseline] converted", src, "->", dst, len(txt.splitlines()), "lines")
(WORK / "acceptance_summary.json").write_text(
    json.dumps(results, ensure_ascii=False, indent=1), encoding="utf-8")
print(json.dumps(results, ensure_ascii=False))
