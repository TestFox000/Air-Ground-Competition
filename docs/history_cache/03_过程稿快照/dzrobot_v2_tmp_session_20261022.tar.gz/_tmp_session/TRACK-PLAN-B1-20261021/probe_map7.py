import json, subprocess, sys, pathlib, os
C = pathlib.Path(r"D:\\User\\Desktop\\比赛存档\\v1\\dzrobot_v2")
out = {}
for obj in ("legacy", "tasks"):
    cmd = [sys.executable, str(C/"tools"/"plan_route.py"), "--config", str(C/"config"/"robot.yaml"),
           "--map", str(C/"_tmp_session"/"t35"/"map7_t24.yaml"), "--emit", "json",
           "--check", "--quiet", "--engine", "tour"] + ([] if obj == "legacy" else ["--objective", obj])
    p = subprocess.run(cmd, cwd=str(C), capture_output=True, text=True, encoding="utf-8", errors="replace")
    text = p.stdout
    i = text.find("{")
    payload = json.loads(text[i:]) if i >= 0 else None
    plan = payload["plans"][0] if payload else {}
    chk = payload.get("route_check", [{}])[0] if payload else {}
    stars = [t for t in plan.get("tokens", []) if "*" in t]
    out[obj] = {"exit": p.returncode, "n_tokens": len(plan.get("tokens", [])),
                "m": plan.get("polylength_m"), "stars": stars,
                "shoot_stops": plan.get("shoot_stops"), "added": plan.get("second_stop_added"),
                "degraded": plan.get("degraded"), "reason": plan.get("degraded_reason"),
                "tasks": plan.get("tasks"), "check_exit": chk.get("exit"),
                "crossing": plan.get("crossing"), "elapsed_ms": plan.get("elapsed_ms"),
                "err": (p.stderr or "")[:300]}
print(json.dumps(out, ensure_ascii=False, indent=1))
