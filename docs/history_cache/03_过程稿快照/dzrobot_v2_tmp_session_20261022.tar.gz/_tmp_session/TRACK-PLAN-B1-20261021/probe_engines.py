import sys, json, pathlib, yaml
C = pathlib.Path(r"D:\\User\\Desktop\\比赛存档\\v1\\dzrobot_v2")
sys.path.insert(0, str(C/"src"/"dzbrain"))
from dzbrain.core.config import Config
from dzbrain.route import planner as PL
from dzbrain.tasks import mission as MT
from dzbrain.route.parser import parse_token

MAP7 = C/"_tmp_session"/"t35"/"map7_t24.yaml"
raw = yaml.safe_load(MAP7.read_text(encoding="utf-8"))
cfg = Config.load(str(C/"config"/"robot.yaml"))

def stars(tokens):
    return [t for t in tokens if parse_token(t)["shoot"]]

out = {}
# raw tour
r0 = PL.plan_route(raw, cfg, allow_reverse=False, max_seconds=10.0)
out["raw_tour"] = {"n": len(r0.tokens), "m": round(r0.polyline_m, 3), "stars": stars(r0.tokens),
                   "blocks": [parse_token(t)["block"] for t in r0.tokens], "tokens": r0.tokens}
# tour via mission closure
cfg_tour = cfg.override("planner.engine", "tour").override("planner.auto_plan_enabled", True).override("planner.map_path", str(MAP7))
o = MT.plan_route_from_config(cfg_tour, log=lambda s: None)
out["tour"] = {"ok": o.ok, "n": len(o.tokens), "m": round(o.route_len_m, 3),
               "stars": stars(o.tokens), "shoot_stops": list(o.shoot_stops),
               "added": o.second_stop_added, "err": o.error}
# tracker-safe
cfg_ts = cfg.override("planner.engine", "tracker-safe").override("planner.auto_plan_enabled", True).override("planner.map_path", str(MAP7))
o2 = MT.plan_route_from_config(cfg_ts, log=lambda s: None)
out["ts"] = {"ok": o2.ok, "n": len(o2.tokens), "m": round(o2.route_len_m, 3),
             "stars": stars(o2.tokens), "shoot_stops": list(o2.shoot_stops),
             "added": o2.second_stop_added, "err": o2.error, "gate": o2.gate_detail}
# stop ledger indices from tokens
for key, ob in (("tour", o), ("ts", o2)):
    toks = ob.tokens
    stops = []
    for i, t in enumerate(toks):
        info = parse_token(t)
        if info["shoot"] or i == len(toks) - 1:
            stops.append({"idx": i + 1, "block": info["block"], "shoot": info["shoot"]})
    out[key]["ledger"] = stops
print(json.dumps(out, ensure_ascii=False, indent=1))
