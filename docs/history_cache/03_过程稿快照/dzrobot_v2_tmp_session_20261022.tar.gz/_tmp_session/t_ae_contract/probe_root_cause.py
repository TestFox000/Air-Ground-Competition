# -*- coding: utf-8 -*-
"""T-AE 根因探针："布局模式收不到 odom" 到底发生在哪一层（bench/FakeBridge，无 ROS）。

四层逐一验证（顺序 = 从代码到中间件）：
  L1 装配顺序：RoBridge 只构造一次、Localization 拿同一实例、注入 odom 能写 P_POSE
  L2 装配缺失：本节点没建 /odom/localization 订阅（subscription_topics 缺）→ 契约红
  L3 图不匹配：我们的订阅在、对端发布方 0（域/RMW/对端未起）→ 契约红
  L4 数据不来：双方端点都在、但 pose 一直没有（QoS/传输/发布异常）→ 契约绿、位姿门红

输出：每层 PASS/FAIL 与判定；结论 = 现场事故只能由 L2/L3/L4 之一造成，L1 在当前 HEAD 已排除。
"""
import pathlib
import sys

WS = pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0, str(WS / 'src' / 'dzbrain'))
sys.path.insert(0, str(WS / 'src' / 'dzbrain' / 'tests'))

from dzbrain import main as M                                    # noqa: E402
from dzbrain.core import geometry as geo                          # noqa: E402
from dzbrain.core.blackboard import (Blackboard, P_POSE, P_POSE_RAW,  # noqa: E402
                                     P_SAFETY)
from dzbrain.core.config import Config                             # noqa: E402
from dzbrain.core.events import EventBus                            # noqa: E402
from dzbrain.core.state import SafetyState                          # noqa: E402
from dzbrain.io import ros_io as RIO                                # noqa: E402
from dzbrain.tasks.localization import LocalizationTask             # noqa: E402
from fakes import FakeBridge, FakeClock                             # noqa: E402


def cfg():
    return Config.from_dict({'mission': {'auto_start': False, 'reset': 'N10,y'},
                             'step': {'pose_ready_wait_s': 0.2, 'layout_ttl_s': 10.0}})


class AssemblyBridge(FakeBridge):
    """真桥的装配契约替身：订阅清单 + 逐话题端点计数（可控制缺失层）。"""

    def __init__(self, clock=None, *, created=None, endpoints=None):
        super().__init__(clock)
        self._created = list(created if created is not None
                             else RIO.required_subscription_topics().values())
        self._endpoints = dict(endpoints or {})

    def subscription_topics(self):
        return list(self._created)

    def endpoint_counts(self, topic):
        return self._endpoints.get(topic, (1, 1))

    def topic_counts(self):
        return {'odom': {'publishers': 1, 'subscribers': 1}}


def layer1():
    """装配顺序：同一 bridge 注入一帧 odom → LocalizationTask 真的写 P_POSE。"""
    clock = FakeClock()
    bridge = AssemblyBridge(clock)
    bb, bus = Blackboard(), EventBus()
    bb.set(P_SAFETY, SafetyState(ok=True), 'probe')
    seed = geo.Pose(*geo.block_to_meters('N10'), geo.HEADING_Y)
    bb.set(P_POSE, seed, 'probe')
    bridge.set_pose_at_block('N10', yaw=0.0)          # 注入一帧 odom（yaw=0）
    loc = LocalizationTask(bridge, bb, bus, cfg(), log=lambda s: None)
    loc.setup()
    loc.tick()
    pose = bb.get(P_POSE)
    ok = (isinstance(pose, geo.Pose) and abs(pose.yaw) < 1e-9
          and bb.get(P_POSE_RAW) is not None)
    return ok, f'P_POSE yaw 90.0 -> {geo.deg(pose.yaw) if isinstance(pose, geo.Pose) else None}'


def layer1_counterfactual():
    """反事实：如果任务拿到的是另一个 bridge（二次构造），odom 永远进不来。"""
    clock = FakeClock()
    worker = AssemblyBridge(clock)          # 任务实际用的桥（没喂过 odom）
    feeder = AssemblyBridge(clock)          # 另一个桥在收 odom（旧桥）
    feeder.set_pose_at_block('N10', yaw=0.0)
    bb, bus = Blackboard(), EventBus()
    bb.set(P_SAFETY, SafetyState(ok=True), 'probe')
    bb.set(P_POSE, geo.Pose(*geo.block_to_meters('N10'), geo.HEADING_Y), 'probe')
    loc = LocalizationTask(worker, bb, bus, cfg(), log=lambda s: None)
    loc.setup()
    loc.tick()
    pose = bb.get(P_POSE)
    stuck = isinstance(pose, geo.Pose) and abs(pose.yaw - geo.HEADING_Y) < 1e-9
    return stuck, '二次构造时 P_POSE 保持种子（yaw=90°），复现现场症状'


def contract_layer(*, created=None, endpoints=None):
    bridge = AssemblyBridge(endpoints=endpoints, created=created)
    ok, rows = M.startup_contract(bridge, 'live')
    bad = [r for r in rows if not r['ok']]
    return ok, rows, bad


def pose_gate_layer():
    """端点都在（契约绿）但一帧 odom 都没有：位姿门应 False。"""
    bridge = AssemblyBridge(FakeClock())
    logs = []
    ok = M._wait_for_pose_ready(bridge, cfg(), stop_flag={'stop': False},
                                log=logs.append, sleep=lambda s: None)
    return ok, logs


def main():
    print('=' * 78)
    print('T-AE 根因探针：布局模式"收不到 odom"的四层判定（bench / FakeBridge / 无 ROS）')
    print('=' * 78)
    l1, l1note = layer1()
    print(f'[L1 装配顺序]      {"PASS" if l1 else "FAIL"}  {l1note}')
    l1c, l1cnote = layer1_counterfactual()
    print(f'[L1 反事实]        {"复现" if l1c else "未复现"}  {l1cnote}')
    l2ok, l2rows, l2bad = contract_layer(created=['/odom/localization'][:0])
    print(f'[L2 装配缺订阅]    contract_ok={l2ok}  红行={[r["key"] for r in l2bad]}'
          f'  note={[r["note"] for r in l2bad][:1]}')
    l3ok, l3rows, l3bad = contract_layer(
        endpoints={'/odom/localization': (0, 1)})
    print(f'[L3 图不匹配]      contract_ok={l3ok}  红行={[r["key"] for r in l3bad]}'
          f'  note={[r["note"] for r in l3bad][:1]}')
    l4ok, l4rows, l4bad = contract_layer()
    gate_ok, gate_logs = pose_gate_layer()
    print(f'[L4 数据不来]      contract_ok={l4ok}（端点齐）  pose_gate_ok={gate_ok}'
          f'  诊断={[s for s in gate_logs if "超时" in s][:1]}')
    env_err, env_warn = RIO.env_problems({'ROS_DOMAIN_ID': '0', 'DZ_ROS_DOMAIN': '118'})
    print(f'[env 域号分叉]     errors={len(env_err)}  {env_err[:1]}')
    print('-' * 78)
    print('结论：L1（装配顺序/同一 bridge）在当前 HEAD 为 PASS ⇒ 现场事故不是它；')
    print('      只剩 L2/L3/L4 三种可解释路径，且各有独立判据（契约 6 / env 5 / 位姿门 5）。')
    verdict = (l1 and l1c and l2ok is False and l3ok is False
               and l4ok is True and gate_ok is False and env_err)
    print(f'探针整体判定：{"PASS" if verdict else "FAIL"}（四层判据互斥、可分层定位）')
    return 0 if verdict else 1


if __name__ == '__main__':
    raise SystemExit(main())