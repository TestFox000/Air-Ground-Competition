# T-AE（缺口 A/E）根因 + 启动契约 + 布局新鲜度 · 交付报告

> 卡：启动契约 + odom 回归根因 + 布局新鲜度（Lead 派卡，2026-10-19）。范围：`src/dzbrain/dzbrain/main.py`、`src/dzbrain/tests/test_stepper.py`。**未 commit、未部署、未上车**。
> 冻结区登记：`tools/wf/frozen.json` 已由 Lead 登记 `main.py`（owner=car-stepper，expires 2026-10-26）；本卡未改动该文件。

## 1. 根因结论（含证据）

**结论：现场"布局模式收不到 odom"不是当前 HEAD 的装配顺序缺陷；它是"图上端点/数据没有到达决策层"这一层的问题，而旧代码没有任何自检把它显式化。**

证据一（bench 四层探针 `_tmp_session/t_ae_contract/probe_root_cause.py`，NO-ROS）：

| 层 | 场景 | 探针结果 | 判据（本卡新增） |
|---|---|---|---|
| L1 装配顺序 | 同一 bridge → LocalizationTask 注入一帧 odom | **PASS**：P_POSE yaw 90°→0° | `startup_contract` 订阅清单 + `test_stepper` 13.2/13.3/13.4 |
| L1 反事实 | 任务拿到另一个 bridge（二次构造） | **复现**：P_POSE 停在种子 90° | 同上（说明"二次构造"确实能造出现场症状） |
| L2 装配缺订阅 | 本节点没建 `/odom/localization` 订阅 | **契约红**：note=本节点未创建订阅（装配/代码问题） | exit 6 |
| L3 图不匹配 | 订阅在、对端发布方 0（域/RMW/对端未起） | **契约红**：note=发布方 0（对端未起/域不同） | exit 6 |
| L4 数据不来 | 双方端点都在、却一帧 pose 都没到 | **契约绿 + 位姿门红** | exit 5（`_wait_for_pose_ready`） |
| env | ROS_DOMAIN_ID=0 vs DZ_ROS_DOMAIN=118 | **env 自检 error** | exit 5（`_startup_self_check`） |

探针整体判定 **PASS**（四层判据互斥、可分层定位）；原始输出见 `probe_output.txt`。

证据二（代码事实）：
- `RosBridge` 全仓仅 `main.py:1667` 一处构造；`io/ros_io.py` 在 `RosBridge.__init__` 里一次建全部订阅（`_create_subs`），`spin_async` 在 `main.py:1714/1770` 各模式各一次；`build_tasks(...)`（`main.py:1748` → `add()` `main.py:1345`）把**同一实例**传给每个任务。
- 因此"订阅没建"只能来自代码/装配（L2）或"建了但对不上图"（L3/L4）；**L1 在当前 HEAD 已排除**（也可能旧构建的装配问题已被后续重构修掉，与卡里判断一致）。
- 现场**无法离线证死**是 L2/L3/L4 哪一层：需按 §6 在车上采 `/proc/<pid>/environ` + `ros2 topic info -v`。当前代码已让这三层各自给出不同退出码（6 / 5 / 5+诊断），下次现场一次就能定位。

### 与 D-015 的口径冲突（必须由 Lead 裁决）

`docs/决策台账.md` **D-015②**（有效）写的是"段边界等新 layout ≤10 s，**超时用最后一份完整 layout 继续**"；本卡 spec 要求"规划前 now-rx > ttl ⇒ WAIT_INFO(layout_stale)，**不规划**" —— 两者对"旧 layout 能不能用"结论相反。本卡**按 spec 实现**（新卡优先），并保留 `step.layout_ttl_s=0` 开关：置 0 即完全回到 D-015 的"继续用最后一份"行为。建议 Lead 在台账补一条 supersede（或明确 TTL 门只适用于"未知格占比高/增量版本"的赛时模式）。

## 2. 启动契约（缺口 A）

新增 `startup_contract(bridge, mode='live', *, log=None) -> (ok, rows)`（main.py，纯离线可测）：
- 声明表 `_CONTRACT_ROWS`：sub = odom / drone_in / imu / offset_center / aim_status / shoot_count / manual_override / manual_gimbal / waypoint_cmd / referee_hp；pub = pursuit_angle / fire_gate / fire_ready / scan_request / motion_state / voice_switch / aim_lead / drone_out。
  （contract.py 里**没有 refuel 话题**；弹药/命中真源是 `referee_hp = /HpAndHitmsg`，已按此登记。）
- 分级（减少赛时门禁）：`required`（odom、pursuit_angle）赛时就卡；`race`（drone_in）只在步进赛时卡；`advisory` 只在 `mode=prepare` 卡。
- 对账：优先 `bridge.node.count_publishers/count_subscribers`，替身退 `endpoint_counts(topic)` / `topic_counts()`；**读不到（未知）不阻断**，只有"明确读到 0"或"本节点确实没建这条订阅"判红。
- 失败 → 打印整张 ✅/❌/⚠️ 表 + **exit 6**（与 env/位姿的 exit 5 分开定位）；`DZ_SKIP_CONTRACT=1` 或 `mode=bench` 整体跳过（bench/离线联调用）。
- 集成：`run_live` 启动自检里跑 `mode=live`（等布局之前）；进入 v2 步进模式后追加 `mode=race-step`（drone_in 升级为阻断）。env 检查（`_startup_self_check`）原样保留、仍 exit 5。
- "赛时只验 token"不变：契约只在启动自检跑一次，不进每段规划；`mode=prepare` 供赛前 prepare 复用同一张表。

表样例（正常车）：`启动契约（mode=live）：18 项 / 失败 0 / 阻断 0 / 通过`，逐行 `✅  sub odom /odom/localization pubs=1 subs=1 [required]`。

## 3. 布局新鲜度门（缺口 E）

- `StepLoop` 记录收到**当前版本**布局的 monotonic 时刻（`_layout_rx_at`）；`_layout_sender_ts` 只作诊断（机/车时钟不同步，**不参与门控**）。
- 规划前 `now - rx > step.layout_ttl_s`（`cfg.get` 缺省 **10 s**，0=关；未改 config 默认值/未加 SCHEMA）⇒ `WAIT_INFO(reason=layout_stale：布局已 X s 未更新…)`，**不规划**；`_planned_version` 已写当前版本 ⇒ 不会每拍重规划；新 version 到达即清零并恢复规划。
- 只挡"新规划"：DRIVING 中布局变旧不影响已下发段的执行（14.8 钉住）。
- `status()` 新增 `layout_ttl_s` / `layout_age_s` / `layout_stale`（遥测/测试同源）。

## 4. diff 摘要

| 文件 | 改动 |
|---|---|
| `src/dzbrain/dzbrain/main.py` | +252：`_CONTRACT_ROWS`/`_CONTRACT_BLOCKING`/`CONTRACT_SKIP_ENV`/`_contract_skip_requested`/`_endpoint_counts`/`_subscription_topics_of`/`startup_contract`/`_format_contract_table`；`run_live` 接入 live+race-step 契约（exit 6）；StepLoop `_layout_ttl_s/_layout_rx_at/_layout_sender_ts`、`_layout_ts_of/_layout_is_stale/_layout_stale_reason`、`status()` 三字段、`start/_poll_layout/_plan` 接线；退出码文档补 6 |
| `src/dzbrain/tests/test_stepper.py` | +154：13.11 改为契约 exit 6、13.12 新增位姿门 exit 5、13.13 原正常路径；新增 §14 八条（契约 ok/缺 pub/缺本节点订阅/DZ_SKIP_CONTRACT/ttl 过期 WAIT/新布局恢复/ttl=0 关闭/只挡新规划） |
| `tools/wf/frozen.json` | **未改**（Lead 已登记 main.py in_flight） |

## 5. 验收输出（本机实跑）

```
$ python src\dzbrain\tests\test_stepper.py
结果：101/101 全部通过 ✅            exit=0

$ python -m dzbrain.main --bench --seconds 3
BENCH exit=0（7 个任务 STOPPED，errors=0）

$ python tools\wf\check.py
冻结区脏文件: 1  [OK ] src/dzbrain/dzbrain/main.py
结果: GREEN                          exit=0
```

原始日志：`accept_stepper.log` / `accept_bench.log` / `accept_check.log`。另：`test_drone.py` 174/174 全绿（布局门 exit 3/4/0 语义未变）。

## 6. 现场采集命令（下次跑车顺手采，用于把 L2/L3/L4 钉死）

```bash
for p in $(pgrep -f dz); do echo "== $p $(tr '\0' ' ' < /proc/$p/cmdline | cut -c1-70)"; tr '\0' '\n' < /proc/$p/environ | grep -E 'ROS_DOMAIN_ID|DZ_ROS_DOMAIN|RMW_IMPLEMENTATION|ROS_LOCALHOST_ONLY'; done
ros2 topic info /odom/localization -v | head -40   # 看 Node name / Reliability 是否匹配
ros2 topic info /pursuitAngle -v | head -20       # 底盘有没有订阅
```

## 7. 未做项 / 说明

1. **D 不搞**（段规划不接 `check_planned_route`）——按用户裁决。
2. 未改 `config/robot.yaml`/SCHEMA 默认值；`step.layout_ttl_s` 走 `cfg.get` 缺省 10，`=0` 即回退。
3. 未跑全量 33 套回归：本卡只跑验收三条 + `test_drone`（174/174）；其余改动面仅 main.py 启动路径/StepLoop。
4. `--bench` 不跑契约（`DZ_SKIP_CONTRACT` 开关已留；契约在 `run_live` 启动路径）。
5. 现场若已存在旧构建的装配顺序问题，本卡无法回溯验证；但当前 HEAD 的 L1 已用探针 + 测试证伪。