#!/bin/bash
echo "=== 车端：段完成/回报/复位 相关 ==="
grep -aE "段完成|SEGMENT|回报|复位|段规划|下发|WAIT_INFO|已复位" ~/robot_logs/9_steploop_layout.log | tail -25
echo
echo "=== 无人机：最近 30 行 ==="
sshpass -p duzhong ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null duzhong@192.168.137.52 'tail -30 $(ls -t ~/dzlink_tools/logs/layout_*.log | head -1)' 2>/dev/null
